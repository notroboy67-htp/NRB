# NRB Panel V2

Rebranded build based on the supplied HVM 5.1 project.

## Start

```bash
cd /root/NRB_PANEL_V1
chmod +x install.sh start.sh
./install.sh
./start.sh
```

The application entry point is `nrb.py` and the database is `nrb.db`.

## Notes

- Internal server-management routes and database tables are retained for compatibility.
- User-facing branding is NRB Panel V2.
- User-facing "VPS" labels were changed to "Server".
- The original project database was preserved and its branding settings were updated.


## NRB Panel V2 Docker Runtime

NRB Panel V2 uses Docker as its local VPS runtime. LXD/LXC and `lxd init` are not required.

- VPS creation automatically pulls the selected Docker image when needed.
- RAM and CPU limits are applied at container creation.
- VPS containers use `restart=unless-stopped`.
- Start/stop/restart/freeze/unfreeze/delete are Docker operations.
- Console commands use `docker exec`.
- File Manager uses a Docker-backed filesystem adapter; it does not require SSH/SFTP or port 22.
- The installer/start script installs and starts Docker automatically on Ubuntu when Docker is missing.

Default VPS images should be Docker-compatible images such as `ubuntu:24.04`, `ubuntu:22.04`, or another image available from the configured registry.
