# NRB VPS Hosting — Start Guide

## Quick start

```bash
chmod +x start.sh
./start.sh
```

Open `http://YOUR_VPS_IP:5000`.

## Production service

After the first successful start:

```bash
./install-service.sh
journalctl -u nrb -f
```

## Important

- The main application entry point is `nrb.py`.
- `app.py` is a WSGI compatibility entry point.
- `api.py` is a standalone compatibility blueprint and does not import `nrb.py`.
- The default per-user VPS limit is 5.
- Replace the generated `SECRET_KEY` if you migrate the installation to another environment.
- Do not put real AI/provider API keys into the ZIP. Configure them on the VPS only if the AI feature is required.
