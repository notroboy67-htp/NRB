# NRB VPS Hosting

This build uses the working AVM project structure as the functional base, with the panel identity changed to NRB VPS Hosting.

## Start

```bash
cd /path/to/NRB
bash start.sh
```

The application listens on `0.0.0.0:5000` by default.

## Important

- `nrb.py` is the main Flask application.
- `templates/base.html` contains the shared theme/background system.
- `templates/errors/500.html` is the 500 error page.
- `nrb.db` is the included database.
