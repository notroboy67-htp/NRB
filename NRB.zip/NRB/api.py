#!/usr/bin/env python3
"""Optional compatibility API for NRB.

The main NRB application and its authenticated API routes live in nrb.py.
This module deliberately does not import nrb.py, preventing circular imports.
"""
from flask import Blueprint, jsonify

api_bp = Blueprint("api_compat", __name__, url_prefix="/api/v1")

@api_bp.get("/health")
def health():
    return jsonify({"success": True, "status": "ok", "service": "NRB"})

@api_bp.get("/info")
def info():
    return jsonify({"success": True, "name": "NRB VPS Hosting", "version": "3.0"})

application = api_bp

if __name__ == "__main__":
    from flask import Flask
    app = Flask(__name__)
    app.register_blueprint(api_bp)
    app.run(host="0.0.0.0", port=5001, debug=False)
