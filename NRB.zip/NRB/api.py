#!/usr/bin/env python3
"""Small standalone API entrypoint for the NRB VPS Hosting panel."""
from app import app

application = app

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
