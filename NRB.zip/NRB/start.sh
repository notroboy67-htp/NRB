#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$(readlink -f "$0")")"
command -v python3 >/dev/null || { echo 'Python 3 is required.'; exit 1; }
python3 -m venv venv 2>/dev/null || true
source venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
mkdir -p static/uploads/profiles static/uploads/settings static/uploads/os_icons static/img backups templates/admin templates/errors
exec python nrb.py
