#!/usr/bin/env python3
import os, secrets, sqlite3, time, json
from datetime import datetime
from functools import wraps
from pathlib import Path
import requests
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session, abort
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from dotenv import load_dotenv

BASE=Path(__file__).resolve().parent
load_dotenv(BASE/'.env')
NAME=os.getenv('NRB_NAME','NRB VPS Hosting')
POWERED=os.getenv('NRB_POWERED_BY','NutroBoy')
DB=Path(os.getenv('DATABASE_PATH',str(BASE/'nrb_vps.db')))
if not DB.is_absolute(): DB=BASE/DB
SECRET=os.getenv('SECRET_KEY') or secrets.token_hex(32)
ALLOW_SIM=os.getenv('ALLOW_SIMULATION','true').lower()=='true'

app=Flask(__name__)
app.config.update(SECRET_KEY=SECRET, MAX_CONTENT_LENGTH=32*1024*1024)
login=LoginManager(app); login.login_view='login'

class User(UserMixin):
    def __init__(self,row): self.id=row['id']; self.username=row['username']; self.email=row['email']; self.is_admin=bool(row['is_admin']); self.active=bool(row['active'])
    def get_id(self): return str(self.id)


def db():
    c=sqlite3.connect(DB, timeout=30); c.row_factory=sqlite3.Row
    c.execute('PRAGMA foreign_keys=ON'); return c

def now(): return datetime.utcnow().isoformat(timespec='seconds')+'Z'

def init_db():
    with db() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, is_admin INTEGER NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS plans(id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, vcpu INTEGER NOT NULL, ram_mb INTEGER NOT NULL, storage_gb INTEGER NOT NULL, price REAL NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1);
        CREATE TABLE IF NOT EXISTS nodes(id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, url TEXT NOT NULL, api_key TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'offline', last_seen TEXT, created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS vps(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, node_id INTEGER REFERENCES nodes(id) ON DELETE SET NULL, plan_id INTEGER REFERENCES plans(id) ON DELETE SET NULL, name TEXT NOT NULL, hostname TEXT NOT NULL, os TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'provisioning', node_vps_id TEXT, ipv4 TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS activity(id INTEGER PRIMARY KEY, user_id INTEGER, action TEXT NOT NULL, detail TEXT, created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
        """)
        if not c.execute('SELECT 1 FROM users LIMIT 1').fetchone():
            c.execute('INSERT INTO users(username,email,password_hash,is_admin,created_at) VALUES(?,?,?,?,?)', (os.getenv('ADMIN_USERNAME','admin'),os.getenv('ADMIN_EMAIL','admin@nrb.local'),generate_password_hash(os.getenv('ADMIN_PASSWORD','admin')),1,now()))
        if not c.execute('SELECT 1 FROM plans LIMIT 1').fetchone():
            c.executemany('INSERT INTO plans(name,vcpu,ram_mb,storage_gb,price) VALUES(?,?,?,?,?)', [('NRB Starter',1,1024,20,199),('NRB Pro',2,4096,60,499),('NRB Business',4,8192,120,999)])

@login.user_loader
def load(uid):
    with db() as c: r=c.execute('SELECT * FROM users WHERE id=?',(uid,)).fetchone()
    return User(r) if r else None

def admin_required(fn):
    @wraps(fn)
    def w(*a,**k):
        if not current_user.is_authenticated or not current_user.is_admin: abort(403)
        return fn(*a,**k)
    return w

def log(action,detail=''):
    if current_user.is_authenticated:
        with db() as c: c.execute('INSERT INTO activity(user_id,action,detail,created_at) VALUES(?,?,?,?)',(current_user.id,action,detail,now()))

def row(sql,args=()):
    with db() as c: return c.execute(sql,args).fetchone()

def rows(sql,args=()):
    with db() as c: return c.execute(sql,args).fetchall()

def node_call(n,method,path,payload=None):
    try:
        r=requests.request(method, n['url'].rstrip('/')+path, json=payload, headers={'Authorization':'Bearer '+n['api_key']}, timeout=int(os.getenv('NODE_TIMEOUT','10')))
        if r.ok:
            with db() as c: c.execute('UPDATE nodes SET status=?,last_seen=? WHERE id=?',('online',now(),n['id']))
            return r.json()
        with db() as c: c.execute('UPDATE nodes SET status=? WHERE id=?',('error',n['id']))
    except Exception:
        with db() as c: c.execute('UPDATE nodes SET status=? WHERE id=?',('offline',n['id']))
    return None

@app.context_processor
def inject(): return {'NRB_NAME':NAME,'POWERED_BY':POWERED}

@app.route('/')
def index(): return render_template('index.html')

@app.route('/login',methods=['GET','POST'])
def login_route():
    if request.method=='POST':
        u=request.form.get('username','').strip(); p=request.form.get('password','')
        r=row('SELECT * FROM users WHERE username=? OR email=?',(u,u))
        if r and r['active'] and check_password_hash(r['password_hash'],p): login_user(User(r)); log('login'); return redirect(request.args.get('next') or url_for('dashboard'))
        flash('Invalid username or password.','error')
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout(): log('logout'); logout_user(); return redirect(url_for('index'))

@app.route('/register',methods=['GET','POST'])
def register():
    if request.method=='POST':
        username=request.form.get('username','').strip(); email=request.form.get('email','').strip().lower(); password=request.form.get('password','')
        if not username or not email or len(password)<6: flash('Enter username, email and a password of at least 6 characters.','error')
        else:
            try:
                with db() as c: c.execute('INSERT INTO users(username,email,password_hash,created_at) VALUES(?,?,?,?)',(username,email,generate_password_hash(password),now()))
                flash('Account created. You can log in now.','success'); return redirect(url_for('login_route'))
            except sqlite3.IntegrityError: flash('Username or email is already in use.','error')
    return render_template('register.html')

@app.route('/dashboard')
@login_required
def dashboard():
    mine=rows('SELECT v.*,p.name plan_name,n.name node_name FROM vps v LEFT JOIN plans p ON p.id=v.plan_id LEFT JOIN nodes n ON n.id=v.node_id WHERE v.user_id=? ORDER BY v.id DESC',(current_user.id,))
    stats={'vps':len(mine),'running':sum(x['status']=='running' for x in mine),'plans':len(rows('SELECT * FROM plans WHERE active=1'))}
    if current_user.is_admin: stats.update(users=row('SELECT COUNT(*) n FROM users')['n'],nodes=row('SELECT COUNT(*) n FROM nodes')['n'])
    return render_template('dashboard.html',vps=mine,stats=stats)

@app.route('/vps')
@login_required
def vps_list(): return render_template('vps_list.html',vps=rows('SELECT v.*,p.name plan_name,n.name node_name FROM vps v LEFT JOIN plans p ON p.id=v.plan_id LEFT JOIN nodes n ON n.id=v.node_id WHERE v.user_id=? ORDER BY v.id DESC',(current_user.id,)), plans=rows('SELECT * FROM plans WHERE active=1 ORDER BY id'), nodes=rows('SELECT id,name,status FROM nodes ORDER BY status DESC,id'))

@app.route('/vps/<int:vps_id>')
@login_required
def vps_detail(vps_id):
    v=row('SELECT v.*,p.name plan_name,p.vcpu,p.ram_mb,p.storage_gb,n.name node_name FROM vps v LEFT JOIN plans p ON p.id=v.plan_id LEFT JOIN nodes n ON n.id=v.node_id WHERE v.id=?',(vps_id,))
    if not v or (v['user_id']!=current_user.id and not current_user.is_admin): abort(404)
    return render_template('vps_detail.html',vps=v)

@app.post('/vps/create')
@login_required
def create_vps():
    plan=row('SELECT * FROM plans WHERE id=? AND active=1',(request.form.get('plan_id'),)); node=row('SELECT * FROM nodes WHERE id=?',(request.form.get('node_id'),)) if request.form.get('node_id') else row('SELECT * FROM nodes ORDER BY status DESC,id LIMIT 1')
    name=request.form.get('name','').strip(); hostname=request.form.get('hostname',name).strip() or name; os_name=request.form.get('os','ubuntu:24.04')
    if not plan or not name: flash('Select a plan and enter a VPS name.','error'); return redirect(url_for('vps_list'))
    with db() as c:
        cur=c.execute('INSERT INTO vps(user_id,node_id,plan_id,name,hostname,os,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)',(current_user.id,node['id'] if node else None,plan['id'],name,hostname,os_name,'provisioning',now(),now())); vid=cur.lastrowid
    if node:
        result=node_call(node,'POST','/v1/vps',{'name':name,'hostname':hostname,'os':os_name,'ram_mb':plan['ram_mb'],'vcpu':plan['vcpu'],'storage_gb':plan['storage_gb']})
        if result and result.get('success'):
            with db() as c: c.execute('UPDATE vps SET status=?,node_vps_id=?,ipv4=?,updated_at=? WHERE id=?',('running',result.get('id'),result.get('ipv4',''),now(),vid))
        else:
            with db() as c: c.execute('UPDATE vps SET status=?,updated_at=? WHERE id=?',('error',now(),vid))
    elif ALLOW_SIM:
        with db() as c: c.execute('UPDATE vps SET status=?,node_vps_id=?,updated_at=? WHERE id=?',('running','sim-'+str(vid),now(),vid))
    log('create_vps',name); flash('VPS created.','success'); return redirect(url_for('vps_detail',vps_id=vid))

@app.post('/vps/<int:vps_id>/control/<action>')
@login_required
def control(vps_id,action):
    v=row('SELECT * FROM vps WHERE id=?',(vps_id,));
    if not v or (v['user_id']!=current_user.id and not current_user.is_admin): abort(404)
    if action not in {'start','stop','restart','delete'}: abort(400)
    n=row('SELECT * FROM nodes WHERE id=?',(v['node_id'],)) if v['node_id'] else None
    ok=False
    if n and v['node_vps_id']:
        res=node_call(n,'POST',f"/v1/vps/{v['node_vps_id']}/{action}"); ok=bool(res and res.get('success'))
    elif ALLOW_SIM: ok=True
    if ok:
        if action=='delete':
            with db() as c: c.execute('DELETE FROM vps WHERE id=?',(vps_id,))
            flash('VPS deleted.','success'); return redirect(url_for('vps_list'))
        status={'start':'running','stop':'stopped','restart':'running'}[action]
        with db() as c: c.execute('UPDATE vps SET status=?,updated_at=? WHERE id=?',(status,now(),vps_id))
        flash(f'VPS {action} completed.','success')
    else: flash('Node operation failed. Check the node agent and API key.','error')
    return redirect(url_for('vps_detail',vps_id=vps_id))

@app.route('/profile',methods=['GET','POST'])
@login_required
def profile():
    if request.method=='POST':
        email=request.form.get('email','').strip().lower()
        if email:
            with db() as c: c.execute('UPDATE users SET email=? WHERE id=?',(email,current_user.id)); flash('Profile updated.','success')
    return render_template('profile.html')

@app.route('/notifications')
@login_required
def notifications(): return render_template('notifications.html',items=[])
@app.route('/ports')
@login_required
def ports(): return render_template('ports.html',ports=[])

@app.route('/admin')
@login_required
@admin_required
def admin_dashboard():
    stats={'users':row('SELECT COUNT(*) n FROM users')['n'],'vps':row('SELECT COUNT(*) n FROM vps')['n'],'nodes':row('SELECT COUNT(*) n FROM nodes')['n'],'plans':row('SELECT COUNT(*) n FROM plans WHERE active=1')['n']}
    return render_template('admin/dashboard.html',stats=stats)

@app.route('/admin/users')
@login_required
@admin_required
def admin_users(): return render_template('admin/users.html',users=rows('SELECT * FROM users ORDER BY id DESC'))

@app.post('/admin/users/<int:user_id>/delete')
@login_required
@admin_required
def admin_user_delete(user_id):
    if user_id==current_user.id: flash('You cannot delete your own account.','error')
    else:
        with db() as c: c.execute('DELETE FROM users WHERE id=?',(user_id,)); flash('User deleted.','success')
    return redirect(url_for('admin_users'))

@app.route('/admin/nodes',methods=['GET','POST'])
@login_required
@admin_required
def admin_nodes():
    if request.method=='POST':
        name=request.form.get('name','').strip(); url=request.form.get('url','').strip(); key=request.form.get('api_key','').strip() or secrets.token_urlsafe(32)
        try:
            with db() as c: c.execute('INSERT INTO nodes(name,url,api_key,created_at) VALUES(?,?,?,?)',(name,url,key,now()))
            flash('Node added.','success')
        except sqlite3.IntegrityError: flash('Node name already exists.','error')
    return render_template('admin/nodes.html',nodes=rows('SELECT * FROM nodes ORDER BY id DESC'))

@app.post('/admin/nodes/<int:node_id>/test')
@login_required
@admin_required
def test_node(node_id):
    n=row('SELECT * FROM nodes WHERE id=?',(node_id,)); res=node_call(n,'GET','/health') if n else None; flash('Node is online.' if res else 'Node test failed.','success' if res else 'error'); return redirect(url_for('admin_nodes'))

@app.route('/admin/plans',methods=['GET','POST'])
@login_required
@admin_required
def admin_plans():
    if request.method=='POST':
        with db() as c: c.execute('INSERT INTO plans(name,vcpu,ram_mb,storage_gb,price) VALUES(?,?,?,?,?)',(request.form['name'],int(request.form['vcpu']),int(request.form['ram_mb']),int(request.form['storage_gb']),float(request.form.get('price',0))))
        flash('Plan created.','success')
    return render_template('admin/plans.html',plans=rows('SELECT * FROM plans ORDER BY id'))

@app.route('/admin/vps')
@login_required
@admin_required
def admin_vps(): return render_template('admin/vps.html',vps=rows('SELECT v.*,u.username,p.name plan_name,n.name node_name FROM vps v JOIN users u ON u.id=v.user_id LEFT JOIN plans p ON p.id=v.plan_id LEFT JOIN nodes n ON n.id=v.node_id ORDER BY v.id DESC'))

@app.route('/api/health')
def health(): return jsonify(success=True,name=NAME,time=now())

@app.route('/api/v1/me')
@login_required
def me(): return jsonify(id=current_user.id,username=current_user.username,email=current_user.email,is_admin=current_user.is_admin)

@app.route('/api/v1/nodes',methods=['GET','POST'])
@login_required
@admin_required
def nodes_api():
    if request.method=='POST':
        d=request.get_json(force=True); key=d.get('api_key') or secrets.token_urlsafe(32)
        with db() as c: cur=c.execute('INSERT INTO nodes(name,url,api_key,created_at) VALUES(?,?,?,?)',(d['name'],d['url'].rstrip('/'),key,now()))
        return jsonify(success=True,id=cur.lastrowid,api_key=key),201
    return jsonify([dict(x) for x in rows('SELECT id,name,url,status,last_seen,created_at FROM nodes')])

@app.route('/api/v1/plans')
def plans_api(): return jsonify([dict(x) for x in rows('SELECT id,name,vcpu,ram_mb,storage_gb,price FROM plans WHERE active=1')])

@app.errorhandler(403)
def e403(e): return render_template('error.html',code=403,message='Access denied'),403
@app.errorhandler(404)
def e404(e): return render_template('error.html',code=404,message='Page not found'),404

init_db()
if __name__=='__main__': app.run(host=os.getenv('HOST','0.0.0.0'),port=int(os.getenv('PORT','5000')),debug=False)
