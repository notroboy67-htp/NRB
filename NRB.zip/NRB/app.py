#!/usr/bin/env python3
"""WSGI entry point for the NRB panel."""
from nrb import app

application = app
