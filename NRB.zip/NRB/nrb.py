#!/usr/bin/env python3
# nrb.py - AVM Panel - Full Web-Based LXC Container VPS Management System
# Version: 3.0

import os
import sys
import json
import time
import shlex
import shutil
import asyncio
import sqlite3
import random
import threading
import logging
import subprocess
import ipaddress
import socket
import requests
import urllib3
import secrets
import hashlib

# Disable SSL warnings for nodes with verify_ssl=False
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
import hmac
import base64
import uuid
import re
from datetime import datetime, timedelta
from datetime import timezone
from typing import Optional, List, Dict, Any, Tuple, Union
from functools import wraps
from contextlib import contextmanager
from pathlib import Path
from urllib.parse import urlencode, parse_qs

# Web framework imports
import flask
from flask import Flask, render_template, request, jsonify, redirect, url_for, session, flash, send_file, send_from_directory, make_response, current_app, abort
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.middleware.proxy_fix import ProxyFix
from werkzeug.utils import secure_filename
from werkzeug.datastructures import FileStorage

# Socket.IO for real-time updates
try:
    from flask_socketio import SocketIO, emit, join_room, leave_room
    SOCKETIO_AVAILABLE = True
except ImportError:
    SOCKETIO_AVAILABLE = False
    print("Warning: flask-socketio not installed, real-time features disabled")

# SSH client for web SSH
try:
    import paramiko
    SSH_AVAILABLE = True
except ImportError:
    SSH_AVAILABLE = False
    print("Warning: paramiko not installed, SSH console disabled")

# Async support for Flask
try:
    from hypercorn.asyncio import serve
    from hypercorn.config import Config as HyperConfig
    HYPERCORN_AVAILABLE = True
except ImportError:
    HYPERCORN_AVAILABLE = False
    print("Warning: hypercorn not installed, using Flask development server")

# ASGI support
try:
    from asgiref.wsgi import WsgiToAsgi
    ASGIREF_AVAILABLE = True
except ImportError:
    ASGIREF_AVAILABLE = False
    print("Warning: asgiref not installed, ASGI support disabled")

# For file uploads
try:
    from PIL import Image
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False
    Image = None
    logging.warning("PIL not installed - image optimization disabled")

# Load .env file before reading environment variables
def _load_dotenv(path='.env'):
    if os.path.exists(path):
        with open(path, encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    k, v = line.split('=', 1)
                    os.environ.setdefault(k.strip(), v.strip())
_load_dotenv()

# Environment variables
PANEL_NAME = os.getenv('PANEL_NAME', 'AVM PANEL')
PANEL_VERSION = os.getenv('PANEL_VERSION', '3.0')
PANEL_DEVELOPER = os.getenv('PANEL_DEVELOPER', 'AyushTheWarrior')
SECRET_KEY = os.getenv('SECRET_KEY', secrets.token_urlsafe(32))
# Ensure DATABASE_PATH points to the correct location
_default_db_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'avm.db')
DATABASE_PATH = os.getenv('DATABASE_PATH', _default_db_path)
# Try to get AI_API_KEY from database settings first, then environment
try:
    AI_API_KEY = get_setting('ai_api_key', os.getenv('AI_API_KEY', ''))
except:
    AI_API_KEY = os.getenv('AI_API_KEY', '')
HOST = os.getenv('HOST', '0.0.0.0')
PORT = int(os.getenv('PORT', 5000))
MAIN_ADMIN_USERNAME = os.getenv('MAIN_ADMIN_USERNAME', 'admin')
MAIN_ADMIN_PASSWORD = os.getenv('MAIN_ADMIN_PASSWORD', 'admin')
MAIN_ADMIN_EMAIL = os.getenv('MAIN_ADMIN_EMAIL', 'admin@localhost')
YOUR_SERVER_IP = os.getenv('YOUR_SERVER_IP', socket.gethostbyname(socket.gethostname()))
DEFAULT_STORAGE_POOL = os.getenv('DEFAULT_STORAGE_POOL', 'default')
DEBUG_MODE = os.getenv('DEBUG_MODE', 'False').lower() == 'true'
AUTO_BACKUP_INTERVAL = int(os.getenv('AUTO_BACKUP_INTERVAL', 3600))
STATS_UPDATE_INTERVAL = int(os.getenv('STATS_UPDATE_INTERVAL', 5))

# OS Options for VPS Creation and Reinstall
OS_OPTIONS = [
    # ── Ubuntu ──────────────────────────────────────────────────────────
    {"label": "Ubuntu 20.04 LTS (Focal)",     "value": "ubuntu:20.04",         "version": "20.04", "icon": "ubuntu"},
    {"label": "Ubuntu 22.04 LTS (Jammy)",     "value": "ubuntu:22.04",         "version": "22.04", "icon": "ubuntu"},
    {"label": "Ubuntu 24.04 LTS (Noble)",     "value": "ubuntu:24.04",         "version": "24.04", "icon": "ubuntu"},
    # ── Debian ──────────────────────────────────────────────────────────
    {"label": "Debian 11 (Bullseye)",         "value": "images:debian/11",     "version": "11",    "icon": "debian"},
    {"label": "Debian 12 (Bookworm)",         "value": "images:debian/12",     "version": "12",    "icon": "debian"},
    {"label": "Debian 13 (Trixie)",           "value": "images:debian/13",     "version": "13",    "icon": "debian"},
    # ── Rocky Linux ─────────────────────────────────────────────────────
    {"label": "Rocky Linux 9 (Blue Onyx)",    "value": "images:rockylinux/9",  "version": "9",     "icon": "rocky"},
    {"label": "Rocky Linux 8 (Green Obsidian)","value": "images:rockylinux/8", "version": "8",     "icon": "rocky"},
    # ── AlmaLinux ───────────────────────────────────────────────────────
    {"label": "AlmaLinux 9 (Emerald Puma)",   "value": "images:almalinux/9",   "version": "9",     "icon": "alma"},
    {"label": "AlmaLinux 8 (Sapphire Caracal)","value": "images:almalinux/8",  "version": "8",     "icon": "alma"},
    # ── Fedora ──────────────────────────────────────────────────────────
    {"label": "Fedora 39",                    "value": "images:fedora/39",     "version": "39",    "icon": "fedora"},
    {"label": "Fedora 40",                    "value": "images:fedora/40",     "version": "40",    "icon": "fedora"},
    {"label": "Fedora 41",                    "value": "images:fedora/41",     "version": "41",    "icon": "fedora"},
    # ── Alpine Linux ────────────────────────────────────────────────────
    {"label": "Alpine 3.18",                  "value": "images:alpine/3.18",   "version": "3.18",  "icon": "alpine"},
    {"label": "Alpine 3.19",                  "value": "images:alpine/3.19",   "version": "3.19",  "icon": "alpine"},
    {"label": "Alpine 3.20",                  "value": "images:alpine/3.20",   "version": "3.20",  "icon": "alpine"},
    # ── CentOS Stream ───────────────────────────────────────────────────
    {"label": "CentOS Stream 9",              "value": "images:centos/9-Stream","version": "9",    "icon": "centos"},
    {"label": "CentOS Stream 8",              "value": "images:centos/8-Stream","version": "8",    "icon": "centos"},
    # ── openSUSE ────────────────────────────────────────────────────────
    {"label": "openSUSE Leap 15.5",           "value": "images:opensuse/15.5", "version": "15.5",  "icon": "opensuse"},
    {"label": "openSUSE Leap 15.4",           "value": "images:opensuse/15.4", "version": "15.4",  "icon": "opensuse"},
    {"label": "openSUSE Tumbleweed",          "value": "images:opensuse/tumbleweed","version": "latest","icon": "opensuse"},
    # ── Arch Linux ──────────────────────────────────────────────────────
    {"label": "Arch Linux (Rolling)",         "value": "images:archlinux",     "version": "latest","icon": "arch"},
    # ── Proxmox VE (special: installed on Debian 12) ───────────────────
    {"label": "Proxmox VE 8.x",              "value": "proxmox:8",            "version": "8",     "icon": "proxmox"},
]

# OS Icons mapping
OS_ICONS = {
    "ubuntu":   "fab fa-ubuntu",
    "debian":   "fab fa-debian",
    "centos":   "fab fa-centos",
    "alpine":   "fas fa-mountain",
    "fedora":   "fab fa-fedora",
    "rocky":    "fas fa-mountain",
    "alma":     "fas fa-mountain",
    "opensuse": "fab fa-suse",
    "arch":     "fas fa-dragon",
    "proxmox":  "fas fa-viruses",
    "default":  "fab fa-linux"
}

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('avm.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('avm_panel')

# Initialize Flask app
app = Flask(__name__)
app.config['SECRET_KEY'] = SECRET_KEY
app.config['SESSION_TYPE'] = 'filesystem'
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(days=1)
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg', 'gif', 'webp', 'ico', 'svg'}
app.config['MAX_IMAGE_SIZE'] = 5 * 1024 * 1024
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_port=1)

# Initialize SocketIO
if SOCKETIO_AVAILABLE:
    socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading', ping_timeout=60, ping_interval=25)
else:
    socketio = None

# Login manager
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message = 'Please log in to access this page.'
login_manager.login_message_category = 'warning'

# Active console sessions tracking
active_consoles = {}
active_consoles_lock = threading.Lock()

# Database setup
@contextmanager
def get_db():
    conn = None
    try:
        conn = sqlite3.connect(DATABASE_PATH, timeout=30)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA busy_timeout=30000")
        conn.row_factory = sqlite3.Row
        yield conn
        conn.commit()
    except Exception as e:
        if conn:
            conn.rollback()
        logger.error(f"Database error: {e}")
        raise
    finally:
        if conn:
            conn.close()

def init_db():
    """Initialize database with all tables"""
    with get_db() as conn:
        cur = conn.cursor()

        # Users table
        cur.execute('''CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            is_admin INTEGER DEFAULT 0,
            is_main_admin INTEGER DEFAULT 0,
            created_at TEXT NOT NULL,
            last_login TEXT,
            last_active TEXT,
            api_key TEXT UNIQUE,
            profile_picture TEXT,
            preferences TEXT DEFAULT '{}',
            two_factor_secret TEXT,
            two_factor_enabled INTEGER DEFAULT 0,
            theme TEXT DEFAULT 'default',
            language TEXT DEFAULT 'en'
        )''')
        
        cur.execute('CREATE INDEX IF NOT EXISTS idx_users_api_key ON users(api_key)')
        
        # Notifications table
        cur.execute('''CREATE TABLE IF NOT EXISTS notifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            type TEXT NOT NULL,
            title TEXT NOT NULL,
            message TEXT NOT NULL,
            read INTEGER DEFAULT 0,
            created_at TEXT NOT NULL,
            expires_at TEXT,
            data TEXT,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        )''')
        
        cur.execute('CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id)')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_notifications_read ON notifications(read)')
        
        # Nodes table
        cur.execute('''CREATE TABLE IF NOT EXISTS nodes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            location TEXT,
            total_vps INTEGER DEFAULT 50,
            used_vps INTEGER DEFAULT 0,
            tags TEXT DEFAULT '[]',
            api_key TEXT UNIQUE,
            api_key_last_used TEXT,
            url TEXT,
            is_local INTEGER DEFAULT 0,
            verify_ssl INTEGER DEFAULT 1,
            ip_addresses TEXT DEFAULT '[]',
            ip_aliases TEXT DEFAULT '[]',
            status TEXT DEFAULT 'unknown',
            last_seen TEXT,
            cpu_cores INTEGER DEFAULT 0,
            ram_total INTEGER DEFAULT 0,
            disk_total INTEGER DEFAULT 0,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )''')
        
        # Local node auto-creation disabled - can be manually created/deleted by admin
        # Uncomment below to auto-create local node on first run:
        # cur.execute('SELECT COUNT(*) FROM nodes WHERE is_local = 1')
        # if cur.fetchone()[0] == 0:
        #     cur.execute('''INSERT INTO nodes 
        #         (name, location, total_vps, tags, api_key, url, is_local, ip_addresses, created_at, updated_at) 
        #         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
        #         ('Local Node', 'Local', 100, '[]', None, None, 1, 
        #          json.dumps([YOUR_SERVER_IP]), datetime.now().isoformat(), datetime.now().isoformat()))
        
        
        # VPS table
        cur.execute('''CREATE TABLE IF NOT EXISTS vps (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            node_id INTEGER NOT NULL DEFAULT 1,
            container_name TEXT UNIQUE NOT NULL,
            hostname TEXT,
            ram TEXT NOT NULL,
            cpu TEXT NOT NULL,
            storage TEXT NOT NULL,
            config TEXT NOT NULL,
            os_version TEXT DEFAULT 'ubuntu:22.04',
            status TEXT DEFAULT 'stopped',
            suspended INTEGER DEFAULT 0,
            suspended_reason TEXT,
            whitelisted INTEGER DEFAULT 0,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            last_started TEXT,
            last_stopped TEXT,
            backup_schedule TEXT,
            backup_count INTEGER DEFAULT 0,
            ip_address TEXT,
            ip_alias TEXT,
            shared_with TEXT DEFAULT '[]',
            suspension_history TEXT DEFAULT '[]',
            notes TEXT,
            metadata TEXT DEFAULT '{}',
            expires_at TEXT,
            expiration_days INTEGER DEFAULT 0,
            auto_suspend_enabled INTEGER DEFAULT 0,
            last_renewed_at TEXT,
            renewal_count INTEGER DEFAULT 0,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY(node_id) REFERENCES nodes(id) ON DELETE RESTRICT
        )''')
        
        cur.execute('CREATE INDEX IF NOT EXISTS idx_vps_user_id ON vps(user_id)')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_vps_node_id ON vps(node_id)')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_vps_status ON vps(status)')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_vps_suspended ON vps(suspended)')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_vps_expires_at ON vps(expires_at)')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_vps_auto_suspend ON vps(auto_suspend_enabled)')
        
        # Settings table
        cur.execute('''CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL,
            description TEXT,
            updated_at TEXT NOT NULL
        )''')
        
        # Initialize settings
        settings_init = [
            ('cpu_threshold', '90', 'CPU usage threshold for auto-suspension (%)'),
            ('ram_threshold', '90', 'RAM usage threshold for auto-suspension (%)'),
            ('site_name', 'AVM PANEL', 'Site name'),
            ('site_description', 'High-Performance VPS Management Panel', 'Site description'),
            ('header_icon', '/static/img/logo.svg', 'Header icon path'),
            ('favicon', '/static/img/favicon.ico', 'Favicon path'),
            ('footer_text', 'Powered by AVM Panel ©AyushTheWarrior 2026 | Version 3.0', 'Footer text'),
            ('maintenance_mode', '0', 'Maintenance mode (1=enabled, 0=disabled)'),
            ('maintenance_message', 'Site is under maintenance. Please check back later.', 'Maintenance message'),
            ('registration_enabled', '1', 'Registration enabled (1=enabled, 0=disabled)'),
            ('default_port_quota', '5', 'Default port quota for new users'),
            ('max_vps_per_user', '10', 'Maximum VPS per user'),
            ('session_timeout', '86400', 'Session timeout in seconds'),
            ('backup_enabled', '1', 'Auto backup enabled'),
            ('backup_retention', '7', 'Number of backups to retain'),
            ('smtp_host', '', 'SMTP host'),
            ('smtp_port', '587', 'SMTP port'),
            ('smtp_user', '', 'SMTP username'),
            ('smtp_pass', '', 'SMTP password'),
            ('smtp_from', '', 'SMTP from email'),
            ('theme', 'default', 'Default theme'),
            ('language', 'en', 'Default language'),
            ('timezone', 'UTC', 'Default timezone'),
            ('glow_enabled', '1', 'Enable glow effects'),
            ('glow_color_primary', '#4f9af5', 'Primary glow colour'),
            ('glow_color_secondary', '#a78bfa', 'Secondary glow colour'),
            ('glow_intensity', 'medium', 'Glow intensity: low, medium, high'),
            ('glow_cards', '1', 'Glow on cards'),
            ('glow_sidebar', '1', 'Glow on sidebar/nav active items'),
            ('glow_buttons', '1', 'Glow on buttons'),
            ('glow_pulse', '1', 'Animated pulsing glow'),
        ]
        
        for key, value, description in settings_init:
            cur.execute('INSERT OR IGNORE INTO settings (key, value, description, updated_at) VALUES (?, ?, ?, ?)',
                       (key, value, description, datetime.now().isoformat()))
        
        # Port allocations table
        cur.execute('''CREATE TABLE IF NOT EXISTS port_allocations (
            user_id INTEGER PRIMARY KEY,
            allocated_ports INTEGER DEFAULT 0,
            used_ports INTEGER DEFAULT 0,
            updated_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        )''')
        
        # Port forwards table
        cur.execute('''CREATE TABLE IF NOT EXISTS port_forwards (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            vps_container TEXT NOT NULL,
            vps_port INTEGER NOT NULL,
            host_port INTEGER NOT NULL,
            protocol TEXT DEFAULT 'tcp,udp',
            description TEXT,
            created_at TEXT NOT NULL,
            last_used TEXT,
            hits INTEGER DEFAULT 0,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY(vps_container) REFERENCES vps(container_name) ON DELETE CASCADE
        )''')
        
        cur.execute('CREATE INDEX IF NOT EXISTS idx_port_forwards_user_id ON port_forwards(user_id)')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_port_forwards_vps_container ON port_forwards(vps_container)')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_port_forwards_host_port ON port_forwards(host_port)')
        
        # Sessions table
        cur.execute('''CREATE TABLE IF NOT EXISTS sessions (
            id TEXT PRIMARY KEY,
            user_id INTEGER NOT NULL,
            expires TEXT NOT NULL,
            data TEXT,
            ip_address TEXT,
            user_agent TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        )''')
        
        # Activity logs table
        cur.execute('''CREATE TABLE IF NOT EXISTS activity_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            action TEXT NOT NULL,
            resource_type TEXT,
            resource_id TEXT,
            details TEXT,
            ip_address TEXT,
            user_agent TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL
        )''')
        
        cur.execute('CREATE INDEX IF NOT EXISTS idx_activity_logs_user_id ON activity_logs(user_id)')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_activity_logs_created_at ON activity_logs(created_at)')
        
        # Backups table
        cur.execute('''CREATE TABLE IF NOT EXISTS backups (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            vps_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            size INTEGER DEFAULT 0,
            path TEXT NOT NULL,
            created_at TEXT NOT NULL,
            expires_at TEXT,
            status TEXT DEFAULT 'completed',
            FOREIGN KEY(vps_id) REFERENCES vps(id) ON DELETE CASCADE
        )''')
        
        # OS Icons table
        cur.execute('''CREATE TABLE IF NOT EXISTS os_icons (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            os_name TEXT UNIQUE NOT NULL,
            icon_path TEXT NOT NULL,
            uploaded_at TEXT NOT NULL,
            uploaded_by INTEGER,
            FOREIGN KEY(uploaded_by) REFERENCES users(id) ON DELETE SET NULL
        )''')

        # VPS Errors table — for Error Solver
        cur.execute('''CREATE TABLE IF NOT EXISTS vps_errors (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            vps_id INTEGER,
            container_name TEXT NOT NULL,
            owner_id INTEGER,
            error_type TEXT NOT NULL,
            error_message TEXT NOT NULL,
            action TEXT NOT NULL,
            resolved INTEGER DEFAULT 0,
            resolved_at TEXT,
            resolved_by INTEGER,
            resolve_log TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY(vps_id) REFERENCES vps(id) ON DELETE CASCADE,
            FOREIGN KEY(owner_id) REFERENCES users(id) ON DELETE SET NULL,
            FOREIGN KEY(resolved_by) REFERENCES users(id) ON DELETE SET NULL
        )''')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_vps_errors_vps_id ON vps_errors(vps_id)')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_vps_errors_resolved ON vps_errors(resolved)')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_vps_errors_created ON vps_errors(created_at)')

        # API Keys table
        cur.execute('''CREATE TABLE IF NOT EXISTS api_keys (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            key TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL,
            description TEXT,
            is_active INTEGER DEFAULT 1,
            created_at TEXT NOT NULL,
            last_used_at TEXT,
            expires_at TEXT,
            permissions TEXT DEFAULT '[]',
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        )''')
        
        cur.execute('CREATE INDEX IF NOT EXISTS idx_api_keys_user_id ON api_keys(user_id)')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_api_keys_key ON api_keys(key)')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_api_keys_active ON api_keys(is_active)')
        
        # Create main admin if not exists
        cur.execute('SELECT COUNT(*) FROM users WHERE is_main_admin = 1')
        if cur.fetchone()[0] == 0:
            password_hash = generate_password_hash(MAIN_ADMIN_PASSWORD)
            api_key = generate_api_key(64)
            now = datetime.now().isoformat()
            cur.execute('''INSERT INTO users 
                (username, email, password_hash, is_admin, is_main_admin, created_at, last_login, api_key, preferences)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                (MAIN_ADMIN_USERNAME, MAIN_ADMIN_EMAIL, password_hash, 1, 1, now, now, api_key, '{}'))
            
            cur.execute('INSERT INTO port_allocations (user_id, allocated_ports, updated_at) VALUES (?, ?, ?)',
                       (cur.lastrowid, 100, now))
        
        conn.commit()

def migrate_discord_auth():
    """Add Discord authentication fields to users table"""
    with get_db() as conn:
        cur = conn.cursor()
        
        # Check if discord_id column exists
        cur.execute("PRAGMA table_info(users)")
        columns = [column[1] for column in cur.fetchall()]
        
        if 'discord_id' not in columns:
            try:
                # SQLite doesn't support adding UNIQUE columns directly
                # Add columns without UNIQUE constraint first
                cur.execute('ALTER TABLE users ADD COLUMN discord_id TEXT')
                cur.execute('ALTER TABLE users ADD COLUMN discord_username TEXT')
                cur.execute('ALTER TABLE users ADD COLUMN discord_avatar TEXT')
                cur.execute('ALTER TABLE users ADD COLUMN discord_email TEXT')
                # Create unique index instead
                cur.execute('CREATE UNIQUE INDEX IF NOT EXISTS idx_users_discord_id ON users(discord_id) WHERE discord_id IS NOT NULL')
                conn.commit()
                logger.info("Discord authentication fields added to users table")
            except Exception as e:
                logger.error(f"Error adding Discord fields: {e}")
        
        # Add Discord settings if they don't exist
        discord_settings = {
            'discord_auth_enabled': '0',
            'discord_client_id': '',
            'discord_client_secret': '',
            'discord_redirect_uri': 'http://localhost:5000/auth/discord/callback',
            'discord_auto_register': '1',
            'discord_button_text': 'Continue with Discord'
        }
        
        for key, default_value in discord_settings.items():
            cur.execute('SELECT value FROM settings WHERE key = ?', (key,))
            if not cur.fetchone():
                cur.execute('INSERT INTO settings (key, value, updated_at) VALUES (?, ?, ?)',
                          (key, default_value, datetime.now().isoformat()))
        
        conn.commit()

def migrate_avm_features():
    """Add AVM Panel feature tables: themes, AI conversations, protection logs"""
    with get_db() as conn:
        cur = conn.cursor()

        # Themes table
        cur.execute('''CREATE TABLE IF NOT EXISTS themes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            description TEXT,
            bg_primary TEXT DEFAULT '#0a0c10',
            bg_secondary TEXT DEFAULT '#111316',
            accent_primary TEXT DEFAULT '#3b82f6',
            accent_secondary TEXT DEFAULT '#6366f1',
            text_primary TEXT DEFAULT '#e1e9f0',
            gif_url TEXT,
            gif_file TEXT,
            is_active INTEGER DEFAULT 0,
            created_by INTEGER,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY(created_by) REFERENCES users(id) ON DELETE SET NULL
        )''')

        # AI conversations table
        cur.execute('''CREATE TABLE IF NOT EXISTS ai_conversations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            role TEXT NOT NULL,
            content TEXT NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        )''')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_ai_conv_user ON ai_conversations(user_id)')

        # Protection events table
        cur.execute('''CREATE TABLE IF NOT EXISTS protection_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            vps_id INTEGER,
            event_type TEXT NOT NULL,
            details TEXT,
            action_taken TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY(vps_id) REFERENCES vps(id) ON DELETE SET NULL
        )''')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_prot_events_vps ON protection_events(vps_id)')
        cur.execute('CREATE INDEX IF NOT EXISTS idx_prot_events_type ON protection_events(event_type)')

        # Add default theme if none exists
        cur.execute('SELECT COUNT(*) FROM themes')
        if cur.fetchone()[0] == 0:
            now = datetime.now().isoformat()
            cur.execute('''INSERT INTO themes (name, description, bg_primary, bg_secondary, accent_primary, accent_secondary, text_primary, is_active, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                ('AVM Dark', 'Default AVM dark theme', '#0a0c10', '#111316', '#3b82f6', '#6366f1', '#e1e9f0', 1, now, now))

        conn.commit()
        logger.info("AVM feature tables initialized")


def migrate_vps_autobackup():
    """Add auto_backup_enabled and last_auto_backup columns to vps table"""
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute("PRAGMA table_info(vps)")
        columns = [col[1] for col in cur.fetchall()]
        try:
            if 'auto_backup_enabled' not in columns:
                cur.execute('ALTER TABLE vps ADD COLUMN auto_backup_enabled INTEGER DEFAULT 0')
                logger.info("Added auto_backup_enabled column to vps table")
            if 'last_auto_backup' not in columns:
                cur.execute('ALTER TABLE vps ADD COLUMN last_auto_backup TEXT')
                logger.info("Added last_auto_backup column to vps table")
            conn.commit()
        except Exception as e:
            logger.error(f"VPS auto-backup migration error: {e}")


def migrate_vps_bandwidth():
    """Add per-VPS bandwidth quota columns to vps table."""
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute("PRAGMA table_info(vps)")
        columns = [col[1] for col in cur.fetchall()]
        try:
            additions = [
                ('bandwidth_quota_mb',     'INTEGER DEFAULT 102400'),   # 100 GB default
                ('bandwidth_used_mb',      'INTEGER DEFAULT 0'),
                ('bandwidth_reset_at',     'TEXT'),
                ('bandwidth_overage_action',"TEXT DEFAULT 'suspend'"),
                ('bandwidth_override_mb',  'INTEGER'),                   # admin override
                ('bandwidth_override_user', 'INTEGER'),                  # admin who set override
                ('bandwidth_override_note','TEXT'),
                ('bandwidth_last_poll',    'TEXT'),
                ('bandwidth_paused',       'INTEGER DEFAULT 0'),         # suspend override
            ]
            for col, decl in additions:
                if col not in columns:
                    cur.execute(f'ALTER TABLE vps ADD COLUMN {col} {decl}')
                    logger.info(f"Added {col} column to vps table")
            conn.commit()
        except Exception as e:
            logger.error(f"VPS bandwidth migration error: {e}")


def migrate_vps_public_networking():
    """Add columns to track Routed Public IPs & Port Forwards feature."""
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute("PRAGMA table_info(vps)")
        columns = [col[1] for col in cur.fetchall()]
        try:
            additions = [
                ('network_mode',            "TEXT DEFAULT 'nat'"),       # 'public', 'nat', 'none'
                ('public_ip_assigned',      'INTEGER DEFAULT 0'),         # boolean: 1 = routed public IP attached
                ('public_ip_attached_at',   'TEXT'),
                ('public_ip_attached_by',   'INTEGER'),
                ('public_ip_gateway',       'TEXT'),
                ('public_netmask',          'TEXT DEFAULT ' + repr('255.255.255.0')),
                ('public_ip_locked',        'INTEGER DEFAULT 0'),
                ('default_ssh_forward',     'INTEGER DEFAULT 1'),         # auto SSH forward at creation
                ('nat_chain_attached',      'INTEGER DEFAULT 0'),         # iptables NAT chain flag
                ('last_networking_apply',   'TEXT'),
            ]
            for col, decl in additions:
                if col not in columns:
                    cur.execute(f'ALTER TABLE vps ADD COLUMN {col} {decl}')
                    logger.info(f"Added {col} column to vps table (public networking)")
            conn.commit()
        except Exception as e:
            logger.error(f"VPS public networking migration error: {e}")


def get_next_month_start() -> str:
    """Return ISO timestamp of the first day of next month at 00:00 UTC."""
    from calendar import monthrange
    now = datetime.utcnow()
    if now.month == 12:
        next_year, next_month = now.year + 1, 1
    else:
        next_year, next_month = now.year, now.month + 1
    _, last_day = monthrange(next_year, next_month)
    return datetime(next_year, next_month, 1, 0, 0, 0).isoformat()


def generate_api_key(length=64):
    return secrets.token_urlsafe(length)

def get_setting(key: str, default: Any = None):
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT value FROM settings WHERE key = ?', (key,))
        row = cur.fetchone()
        val = row[0] if row else None
        # Return default if value is None or empty string
        if val is None or val == '':
            return default
        return val

# ── Settings cache — avoids a DB hit on every Jinja render ──────────────────
_settings_cache: Dict[str, Any] = {}
_settings_cache_ts: float = 0.0
_SETTINGS_CACHE_TTL: float = 10.0   # seconds

def get_setting_cached(key: str, default: Any = None) -> Any:
    """Return a setting value, using a short-lived in-process cache."""
    global _settings_cache, _settings_cache_ts
    now = time.time()
    if now - _settings_cache_ts > _SETTINGS_CACHE_TTL:
        try:
            with get_db() as conn:
                cur = conn.cursor()
                cur.execute('SELECT key, value FROM settings')
                _settings_cache = {r[0]: r[1] for r in cur.fetchall()}
                _settings_cache_ts = now
        except Exception as e:
            logger.error(f"Settings cache refresh failed: {e}")
    val = _settings_cache.get(key)
    # Return default if value is None or empty string
    if val is None or val == '':
        return default
    return val

def invalidate_settings_cache():
    """Call after set_setting() so the cache is refreshed immediately."""
    global _settings_cache_ts
    _settings_cache_ts = 0.0

def set_setting(key: str, value: str):
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('INSERT OR REPLACE INTO settings (key, value, updated_at) VALUES (?, ?, ?)',
                   (key, value, datetime.now().isoformat()))
        conn.commit()
    invalidate_settings_cache()

def log_activity(user_id: Optional[int], action: str, resource_type: Optional[str] = None,
                 resource_id: Optional[str] = None, details: Optional[Dict] = None):
    try:
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('''INSERT INTO activity_logs 
                (user_id, action, resource_type, resource_id, details, ip_address, user_agent, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)''',
                (user_id, action, resource_type, resource_id, 
                 json.dumps(details) if details else None,
                 request.remote_addr if request else None,
                 request.user_agent.string if request and hasattr(request, 'user_agent') else None,
                 datetime.now().isoformat()))
            conn.commit()
    except Exception as e:
        logger.error(f"Failed to log activity: {e}")

def log_vps_error(vps_id: Optional[int], container_name: str, owner_id: Optional[int],
                  action: str, error_message: str):
    """Record a VPS operation error into the vps_errors table for the Error Solver."""
    try:
        # Classify the error type — order matters (restart before start)
        msg_lower = error_message.lower()
        action_lower = action.lower()
        if 'reinstall' in action_lower or ('delete' in action_lower and 'init' in action_lower):
            error_type = 'reinstall_failed'
        elif 'restart' in action_lower:
            error_type = 'restart_failed'
        elif 'start' in action_lower:
            error_type = 'start_failed'
        elif 'stop' in action_lower:
            error_type = 'stop_failed'
        elif 'freeze' in action_lower:
            error_type = 'freeze_failed'
        elif 'create' in action_lower:
            error_type = 'create_failed'
        elif 'timeout' in msg_lower:
            error_type = 'timeout'
        else:
            error_type = 'general_error'

        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('''INSERT INTO vps_errors
                (vps_id, container_name, owner_id, error_type, error_message, action, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)''',
                (vps_id, container_name, owner_id,
                 error_type, error_message, action,
                 datetime.now().isoformat()))
            conn.commit()
    except Exception as e:
        logger.error(f"Failed to log VPS error: {e}")


def create_notification(user_id: int, type: str, title: str, message: str, data: Optional[Dict] = None, expires_in: Optional[int] = None):
    try:
        expires_at = None
        if expires_in:
            expires_at = (datetime.now() + timedelta(seconds=expires_in)).isoformat()
        
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('''INSERT INTO notifications 
                (user_id, type, title, message, created_at, expires_at, data)
                VALUES (?, ?, ?, ?, ?, ?, ?)''',
                (user_id, type, title, message, datetime.now().isoformat(), expires_at, json.dumps(data) if data else None))
            conn.commit()
            
            if socketio:
                socketio.emit('new_notification', {
                    'id': cur.lastrowid,
                    'type': type,
                    'title': title,
                    'message': message,
                    'created_at': datetime.now().isoformat()
                }, room=f'user_{user_id}')
    except Exception as e:
        logger.error(f"Failed to create notification: {e}")

def get_user_notifications(user_id: int, unread_only: bool = False, limit: int = 50):
    with get_db() as conn:
        cur = conn.cursor()
        query = '''SELECT * FROM notifications WHERE user_id = ?'''
        params = [user_id]
        
        if unread_only:
            query += ' AND read = 0'
        
        query += ' AND (expires_at IS NULL OR expires_at > ?)'
        params.append(datetime.now().isoformat())
        
        query += ' ORDER BY created_at DESC LIMIT ?'
        params.append(limit)
        
        cur.execute(query, params)
        notifications = [dict(row) for row in cur.fetchall()]
        
        for notif in notifications:
            if notif['data']:
                try:
                    notif['data'] = json.loads(notif['data'])
                except:
                    notif['data'] = {}
        
        return notifications

def mark_notification_read(notification_id: int, user_id: int):
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('UPDATE notifications SET read = 1 WHERE id = ? AND user_id = ?', (notification_id, user_id))
        conn.commit()
        return cur.rowcount > 0

def mark_all_notifications_read(user_id: int):
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('UPDATE notifications SET read = 1 WHERE user_id = ? AND read = 0', (user_id,))
        conn.commit()
        return cur.rowcount

def get_unread_notifications_count(user_id: int):
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('''SELECT COUNT(*) FROM notifications 
                      WHERE user_id = ? AND read = 0 
                      AND (expires_at IS NULL OR expires_at > ?)''',
                   (user_id, datetime.now().isoformat()))
        return cur.fetchone()[0]

# Per-user notification count cache {user_id: (count, timestamp)}
_notif_count_cache: Dict[int, tuple] = {}
_NOTIF_CACHE_TTL = 10.0  # seconds

def get_unread_notifications_count_cached(user_id: int) -> int:
    now = time.time()
    cached = _notif_count_cache.get(user_id)
    if cached and (now - cached[1]) < _NOTIF_CACHE_TTL:
        return cached[0]
    count = get_unread_notifications_count(user_id)
    _notif_count_cache[user_id] = (count, now)
    return count

def invalidate_notif_cache(user_id: int):
    _notif_count_cache.pop(user_id, None)

# Maintenance mode middleware
@app.before_request
def check_maintenance():
    if request.endpoint == 'static' or request.path.startswith('/static/'):
        return None
    if request.endpoint in ['login', 'logout', 'register', 'health', 'favicon', 'serve_static']:
        return None
    if request.path.startswith('/api/'):
        return None
    maintenance_mode = get_setting('maintenance_mode', '0') == '1'
    if maintenance_mode:
        if current_user.is_authenticated and current_user.is_admin:
            return None
        return render_template('maintenance.html',
                             message=get_setting('maintenance_message', 'Site is under maintenance. Please check back later.'),
                             panel_name=get_setting('site_name', 'AVM PANEL')), 503

@app.after_request
def after_request(response):
    """Ensure proper headers are set for all responses"""
    try:
        # Ensure Content-Type is set
        if not response.content_type:
            response.content_type = 'text/html; charset=utf-8'
        
        # Add security headers
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'SAMEORIGIN'
        response.headers['X-XSS-Protection'] = '1; mode=block'
        
        return response
    except Exception as e:
        logger.error(f"Error in after_request: {e}")
        return response

# User class for Flask-Login
class User(UserMixin):
    def __init__(self, user_data):
        self.id = user_data['id']
        self.username = user_data['username']
        self.email = user_data['email']
        self.password_hash = user_data['password_hash']
        self.is_admin = bool(user_data['is_admin'])
        self.is_main_admin = bool(user_data['is_main_admin'])
        self.created_at = user_data['created_at']
        self.last_login = user_data.get('last_login')
        self.last_active = user_data.get('last_active')
        self.api_key = user_data.get('api_key')
        self.profile_picture = user_data.get('profile_picture')
        try:
            self.preferences = json.loads(user_data.get('preferences', '{}'))
        except:
            self.preferences = {}
        self.two_factor_enabled = bool(user_data.get('two_factor_enabled', 0))
        self.theme = user_data.get('theme', 'default')
        self.language = user_data.get('language', 'en')
        # Discord fields
        self.discord_id = user_data.get('discord_id')
        self.discord_username = user_data.get('discord_username')
        self.discord_avatar = user_data.get('discord_avatar')
        self.discord_email = user_data.get('discord_email')

    @staticmethod
    def get(user_id):
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT * FROM users WHERE id = ?', (user_id,))
            user_data = cur.fetchone()
            if user_data:
                return User(dict(user_data))
        return None

    @staticmethod
    def get_by_username(username):
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT * FROM users WHERE username = ?', (username,))
            user_data = cur.fetchone()
            if user_data:
                return User(dict(user_data))
        return None

    @staticmethod
    def get_by_email(email):
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT * FROM users WHERE email = ?', (email,))
            user_data = cur.fetchone()
            if user_data:
                return User(dict(user_data))
        return None

    @staticmethod
    def get_by_api_key(api_key):
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT * FROM users WHERE api_key = ?', (api_key,))
            user_data = cur.fetchone()
            if user_data:
                cur.execute('UPDATE users SET last_active = ? WHERE id = ?',
                           (datetime.now().isoformat(), user_data['id']))
                conn.commit()
                return User(dict(user_data))
        return None

@login_manager.user_loader
def load_user(user_id):
    return User.get(int(user_id))

# Decorators for permissions
def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            # Check if this is an AJAX/JSON request
            if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return jsonify({'success': False, 'error': 'Admin access required'}), 403
            flash('Admin access required.', 'danger')
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    return decorated_function

def main_admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_main_admin:
            # Check if this is an AJAX/JSON request
            if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return jsonify({'success': False, 'error': 'Main admin access required'}), 403
            flash('Main admin access required.', 'danger')
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    return decorated_function

def api_key_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        api_key = request.headers.get('X-API-Key') or request.args.get('api_key')
        if not api_key:
            return jsonify({'error': 'API key required'}), 401
        
        user = User.get_by_api_key(api_key)
        if not user:
            return jsonify({'error': 'Invalid API key'}), 401
        
        request.api_user = user
        return f(*args, **kwargs)
    return decorated_function

def vps_owner_or_admin_required(f):
    @wraps(f)
    def decorated_function(vps_id, *args, **kwargs):
        vps = get_vps_by_id(vps_id)
        if not vps:
            flash('VPS not found', 'danger')
            return redirect(url_for('vps_list'))
        
        if vps['user_id'] != current_user.id and not current_user.is_admin:
            shared_with = vps.get('shared_with', [])
            if str(current_user.id) not in [str(uid) for uid in shared_with]:
                flash('Access denied', 'danger')
                return redirect(url_for('vps_list'))
        
        return f(vps_id, *args, **kwargs)
    return decorated_function

app.jinja_env.globals.update(get_setting=get_setting_cached)
app.jinja_env.globals.update(now=datetime.now)
app.jinja_env.globals.update(get_unread_notifications_count=get_unread_notifications_count)

# ============================================================================
# Socket.IO Events
# ============================================================================
if socketio:
    @socketio.on('connect')
    def handle_connect():
        if current_user.is_authenticated:
            join_room(f'user_{current_user.id}')
            emit('connected', {'status': 'connected', 'user_id': current_user.id})
            
            count = get_unread_notifications_count(current_user.id)
            emit('unread_count', {'count': count})
    
    @socketio.on('disconnect')
    def handle_disconnect():
        if current_user.is_authenticated:
            leave_room(f'user_{current_user.id}')
        
        # Clean up any console sessions for this socket
        with active_consoles_lock:
            to_remove = []
            for vps_id, info in active_consoles.items():
                if info.get('sid') == request.sid:
                    to_remove.append(vps_id)
                    try:
                        if 'proc' in info and info['proc']:
                            info['proc'].terminate()
                    except:
                        pass
            
            for vps_id in to_remove:
                active_consoles.pop(vps_id, None)
    
    @socketio.on('join_vps_room')
    def handle_join_vps_room(data):
        vps_id = data.get('vps_id')
        if current_user.is_authenticated and vps_id:
            room = f'vps_{vps_id}'
            join_room(room)
            emit('joined_vps_room', {'vps_id': vps_id, 'room': room})
    
    @socketio.on('leave_vps_room')
    def handle_leave_vps_room(data):
        vps_id = data.get('vps_id')
        if vps_id:
            leave_room(f'vps_{vps_id}')
    
    @socketio.on('request_vps_stats')
    def handle_request_vps_stats(data):
        vps_id = data.get('vps_id')
        if not current_user.is_authenticated or not vps_id:
            return
        
        vps = get_vps_by_id(vps_id)
        if not vps or (vps['user_id'] != current_user.id and not current_user.is_admin):
            return
        
        try:
            stats = run_sync(get_container_stats(vps['container_name'], vps['node_id']))
            emit('vps_stats', {'vps_id': vps_id, 'stats': stats})
        except Exception as e:
            logger.error(f"Error getting VPS stats for socket: {e}")
    
    @socketio.on('console_input')
    def handle_console_input(data):
        vps_id = data.get('vps_id')
        input_data = data.get('input', '')
        
        if not current_user.is_authenticated or not vps_id:
            return
        
        with active_consoles_lock:
            info = active_consoles.get(vps_id)
            if not info or info.get('sid') != request.sid:
                emit('console_output', b'Console not active or not owned by you\r\n')
                return
            
            proc = info.get('proc')
            if not proc:
                return
            
            try:
                if isinstance(input_data, str):
                    input_data = input_data.encode('utf-8', errors='replace')
                proc.stdin.write(input_data)
                proc.stdin.flush()
            except (BrokenPipeError, OSError):
                emit('console_output', b'[Connection lost]\r\n')
                active_consoles.pop(vps_id, None)
            except Exception as e:
                emit('console_output', f"[Error: {e}]\r\n".encode('utf-8'))
    
    @socketio.on('console_resize')
    def handle_console_resize(data):
        vps_id = data.get('vps_id')
        cols = data.get('cols', 80)
        rows = data.get('rows', 24)
        
        with active_consoles_lock:
            info = active_consoles.get(vps_id)
            if info and info.get('sid') == request.sid and 'proc' in info:
                try:
                    import fcntl
                    import termios
                    import struct
                    
                    fcntl.ioctl(info['proc'].stdout.fileno(), termios.TIOCSWINSZ,
                               struct.pack("HHHH", rows, cols, 0, 0))
                except:
                    pass

# ============================================================================
# LXC Command Execution
# ============================================================================
async def execute_lxc(container_name: str, command: str, timeout=120, node_id: Optional[int] = None, suppress_log: bool = False):
    if node_id is None and container_name:
        node_id = find_node_id_for_container(container_name)
    
    node = get_node(node_id)
    
    if not node:
        raise Exception(f"Node {node_id} not found")
    
    full_command = f"lxc {command}"
    
    if node['is_local']:
        try:
            logger.debug(f"Executing local command: {full_command}")
            cmd = shlex.split(full_command)
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            try:
                stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
            except asyncio.TimeoutError:
                proc.kill()
                await proc.wait()
                raise asyncio.TimeoutError(f"Command timed out after {timeout} seconds")
            
            stdout_str = stdout.decode().strip() if stdout else ""
            stderr_str = stderr.decode().strip() if stderr else ""
            
            if proc.returncode != 0:
                error = stderr_str if stderr_str else f"Command failed with return code {proc.returncode}"
                raise Exception(f"Local LXC command failed: {error}\nCommand: {full_command}")
            
            return stdout_str if stdout_str else ""
        except asyncio.TimeoutError as te:
            if not suppress_log:
                logger.error(f"LXC command timed out: {full_command} - {str(te)}")
            raise
        except Exception as e:
            if not suppress_log:
                logger.error(f"LXC Error: {full_command} - {str(e)}")
            raise
    else:
        try:
            import requests
            url = f"{node['url']}/api/execute"
            data = {"command": full_command, "timeout": timeout}
            headers = {"X-API-Key": node["api_key"]}
            verify_ssl = bool(node.get('verify_ssl', 1))
            
            with get_db() as conn:
                cur = conn.cursor()
                cur.execute('UPDATE nodes SET api_key_last_used = ? WHERE id = ?',
                           (datetime.now().isoformat(), node_id))
                conn.commit()
            
            response = requests.post(url, json=data, headers=headers, timeout=timeout + 5, verify=verify_ssl)
            response.raise_for_status()
            
            res = response.json()
            if not res.get("success", False):
                stderr = res.get("stderr", "Command failed")
                raise Exception(f"Remote LXC command failed on {node['name']}: {stderr}\nCommand: {full_command}")
            return res.get("stdout", "")
        
        except requests.exceptions.RequestException as e:
            logger.error(f"Remote LXC error on node {node['name']} ({url}): {str(e)}")
            with get_db() as conn:
                cur = conn.cursor()
                cur.execute('UPDATE nodes SET status = ?, last_seen = ? WHERE id = ?',
                           ('offline', datetime.now().isoformat(), node_id))
                conn.commit()
            
            if hasattr(e, 'response') and hasattr(e.response, 'status_code'):
                raise Exception(f"Remote execution failed on {node['name']}: HTTP {e.response.status_code} - {str(e)}")
            else:
                raise Exception(f"Remote execution failed on {node['name']}: {str(e)}")

def run_sync(coro):
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None
    
    if loop and loop.is_running():
        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor() as executor:
            future = executor.submit(asyncio.run, coro)
            return future.result()
    else:
        return asyncio.run(coro)

async def container_action_remote(node: Dict, container_name: str, action: str, timeout: int = 60) -> bool:
    """
    Perform container action on remote node using dedicated API endpoints
    Actions: start, stop, restart
    """
    try:
        import requests
        url = f"{node['url']}/api/container/{action}"
        data = {"container": container_name, "timeout": timeout}
        headers = {"X-API-Key": node["api_key"]}
        verify_ssl = bool(node.get('verify_ssl', 1))
        
        response = requests.post(url, json=data, headers=headers, timeout=timeout + 5, verify=verify_ssl)
        response.raise_for_status()
        
        result = response.json()
        if result.get("success", False):
            logger.info(f"Container {action} successful on remote node {node['name']}: {container_name}")
            return True
        else:
            error = result.get("error", "Unknown error")
            logger.error(f"Container {action} failed on remote node {node['name']}: {error}")
            return False
            
    except Exception as e:
        logger.error(f"Failed to {action} container {container_name} on remote node {node['name']}: {e}")
        return False

async def apply_lxc_config(container_name: str, node_id: int):
    """Apply minimal LXC config BEFORE container start.
    Additional configs (swap isolation, resource limits, etc.) are applied AFTER start."""
    try:
        await execute_lxc(container_name, f"config set {container_name} security.nesting true", node_id=node_id)
        await execute_lxc(container_name, f"config set {container_name} security.syscalls.intercept.mknod true", node_id=node_id)
        await execute_lxc(container_name, f"config set {container_name} security.syscalls.intercept.setxattr true", node_id=node_id)
        logger.info(f"LXC permissions applied to {container_name} on node {node_id}")
    except Exception as e:
        logger.error(f"Failed to apply LXC config to {container_name}: {e}")
        raise


async def apply_post_start_config(container_name: str, node_id: int):
    """Apply post-start configs AFTER the container is running."""
    # ── 5-Layer Swap Isolation ──────────────────────────────────────────
    try:
        await apply_swap_isolation(container_name, node_id)
    except Exception as sw_e:
        logger.warning(f"[post-start] swap isolation failed for {container_name}: {sw_e}")

    # ── Proxmox-Grade Resource Limits ──────────────────────────────────
    try:
        await apply_proxmox_resource_limits(container_name, node_id)
    except Exception as rl_e:
        logger.warning(f"[post-start] resource limits failed for {container_name}: {rl_e}")

async def apply_swap_isolation(container_name: str, node_id: int) -> dict:
    """Apply the 5-layer swap isolation stack to a single LXC container.

    Layer 1: LXD/Incus memory.swap limit   (limits.memory.swap=false)
    Layer 2: cgroup v2 cap                 (memory.swap.max=0 in raw.lxc)
    Layer 3: In-guest swapoff              (systemd unit runs swapoff -a on boot)
    Layer 4: /proc/swaps → /dev/null       (raw.lxc mount entry)
    Layer 5: /proc/meminfo Swap zeroed      (unshare-namespace patcher via systemd unit)

    Returns dict with per-layer success/failure status.
    """
    result = {
        'container': container_name,
        'L1_lxd_limit': False,
        'L2_cgroup_v2': False,
        'L3_swapoff': False,
        'L4_proc_swaps': False,
        'L5_meminfo_patch': False,
        'errors': []
    }

    # ── Layer 1: LXD/Incus memory.swap limit ───────────────────────────
    try:
        await execute_lxc(container_name,
            f"config set {container_name} limits.memory.swap false",
            node_id=node_id, timeout=15)
        result['L1_lxd_limit'] = True
    except Exception as e:
        result['errors'].append(f"L1: {e}")
        logger.warning(f"[swap-iso L1] {container_name}: {e}")

    # ── Layer 2 + 4: cgroup v2 cap + /proc/swaps → /dev/null ───────────
    # Detect cgroups version before setting cgroup2 keys
    cgroups_v2 = False
    try:
        cg_check = await execute_lxc(container_name,
            f"exec {container_name} -- sh -c 'test -d /sys/fs/cgroup && cat /sys/fs/cgroup/cgroup.controllers 2>/dev/null | head -1'",
            node_id=node_id, timeout=10)
        if cg_check and 'cpu' in str(cg_check):
            cgroups_v2 = True
    except Exception:
        pass

    if cgroups_v2:
        try:
            # Build raw.lxc append via execute_lxc with printf
            swap_block = "lxc.cgroup2.memory.swap.max = 0\\nlxc.cgroup2.memory.swap.high = 0"
            await execute_lxc(container_name,
                f"config set {container_name} raw.lxc \"$(printf '{swap_block}')\"",
                node_id=node_id, timeout=30)
            result['L2_cgroup_v2'] = True
        except Exception as e:
            result['errors'].append(f"L2: {e}")
            logger.warning(f"[swap-iso L2] {container_name}: {e}")
    else:
        logger.info(f"[swap-iso L2] {container_name}: cgroups v1 detected, skipping cgroup2 swap limits")
        result['L2_cgroup_v2'] = True  # marked OK, intentionally skipped

    # ── Layer 4: /proc/swaps → /dev/null via LXD mount ──────────────────
    try:
        await execute_lxc(container_name,
            f"config device add {container_name} avm-swap-null disk source=/dev/null path=/proc/swaps",
            node_id=node_id, timeout=15)
        result['L4_proc_swaps'] = True
    except Exception as e:
        # Fallback: try bind mount via raw.lxc if disk device fails
        logger.warning(f"[swap-iso L4] {container_name}: disk device failed ({e}), trying raw.lxc fallback")
        try:
            mount_line = "lxc.mount.entry = /dev/null proc/swaps none bind,create=file,ro 0 0"
            await execute_lxc(container_name,
                f"config set {container_name} raw.lxc \"$(printf '{mount_line}')\"",
                node_id=node_id, timeout=30)
            result['L4_proc_swaps'] = True
        except Exception as e2:
            result['errors'].append(f"L4: {e2}")
            logger.warning(f"[swap-iso L4] {container_name}: {e2}")

    # ── Layer 3 + 5: In-guest patcher script + systemd unit ────────────
    patcher_script = r'''#!/bin/bash
# AVM Panel 5-Layer Swap Isolation — Layer 3 & 5 patcher
# Runs at every boot to disable swap and zero swap fields in /proc/meminfo
set +e

# Layer 3a: Disable all swap in-guest
/sbin/swapoff -a 2>/dev/null
[ -x /sbin/swapoff ] || /usr/sbin/swapoff -a 2>/dev/null

# Layer 3b: Scrub swap entries from /etc/fstab (persist across reboots)
if [ -f /etc/fstab ]; then
    sed -i -E '/\sswap\s/ s/^/#AVM-SWAP-DISABLED: /' /etc/fstab
fi

# Layer 3c: Disable systemd swap generators (they re-enable swap at boot)
for f in /etc/systemd/system/swap.target.wants/*.swap \
         /etc/systemd/system/local-fs.target.wants/*.swap \
         /lib/systemd/system/local-fs.target.wants/*.swap \
         /lib/systemd/system/swap.target.wants/*.swap; do
    if [ -e "$f" ] && [[ "$f" != *.avm-disabled ]]; then
        mv "$f" "${f}.avm-disabled" 2>/dev/null
    fi
done

# Layer 5: /proc/meminfo Swap zeroed via unshare-namespace patcher
mkdir -p /run/avm-swap-iso
mount -t tmpfs -o size=64K tmpfs /run/avm-swap-iso 2>/dev/null

{
    grep -v -E '^(SwapTotal|SwapFree|SwapCached):' /proc/meminfo 2>/dev/null
    echo "SwapTotal:           0 kB"
    echo "SwapFree:            0 kB"
    echo "SwapCached:          0 kB"
} > /run/avm-swap-iso/meminfo

# Bind-mount sanitized meminfo over /proc/meminfo
mount --bind /run/avm-swap-iso/meminfo /proc/meminfo 2>/dev/null

# Layer 4 reinforcement: make sure /proc/swaps is empty/null inside
mount --bind /dev/null /proc/swaps 2>/dev/null

exit 0
'''

    systemd_unit = '''[Unit]
Description=AVM Panel — 5-Layer Swap Isolation
Documentation=https://avmpanel.app/docs/swap-isolation
DefaultDependencies=no
After=local-fs.target
Before=swap.target network.target sysinit.target
ConditionPathExists=/usr/local/bin/avm-swap-patch.sh

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/usr/local/bin/avm-swap-patch.sh
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
'''

    try:
        import subprocess as _sp
        import tempfile

        with tempfile.NamedTemporaryFile(mode='w', suffix='.sh', delete=False) as sf:
            sf.write(patcher_script)
            script_tmp = sf.name
        with tempfile.NamedTemporaryFile(mode='w', suffix='.service', delete=False) as uf:
            uf.write(systemd_unit)
            unit_tmp = uf.name

        try:
            r = _sp.run(
                ['lxc', 'file', 'push', script_tmp, f'{container_name}/usr/local/bin/avm-swap-patch.sh'],
                capture_output=True, text=True, timeout=30
            )
            if r.returncode != 0:
                result['errors'].append(f"L3/L5 script push: {r.stderr.strip()}")
            else:
                await execute_lxc(container_name,
                    f"exec {container_name} -- chmod 0755 /usr/local/bin/avm-swap-patch.sh",
                    node_id=node_id, timeout=10)
                r2 = _sp.run(
                    ['lxc', 'file', 'push', unit_tmp, f'{container_name}/etc/systemd/system/avm-swap-iso.service'],
                    capture_output=True, text=True, timeout=30
                )
                if r2.returncode != 0:
                    result['errors'].append(f"L5 unit push: {r2.stderr.strip()}")
                else:
                    await execute_lxc(container_name,
                        f"exec {container_name} -- systemctl daemon-reload",
                        node_id=node_id, timeout=20, suppress_log=True)
                    await execute_lxc(container_name,
                        f"exec {container_name} -- systemctl enable avm-swap-iso.service",
                        node_id=node_id, timeout=20, suppress_log=True)
                    # Try to start now; may fail if not booted yet (will run on next boot)
                    await execute_lxc(container_name,
                        f"exec {container_name} -- systemctl start avm-swap-iso.service",
                        node_id=node_id, timeout=20, suppress_log=True)
                    result['L3_swapoff'] = True
                    result['L5_meminfo_patch'] = True
        finally:
            try: os.unlink(script_tmp)
            except Exception: pass
            try: os.unlink(unit_tmp)
            except Exception: pass
    except Exception as e:
        result['errors'].append(f"L3/L5: {e}")
        logger.warning(f"[swap-iso L3+L5] {container_name}: {e}")

    # Log summary
    applied = [k for k in ['L1_lxd_limit', 'L2_cgroup_v2', 'L3_swapoff', 'L4_proc_swaps', 'L5_meminfo_patch'] if result[k]]
    if len(applied) == 5:
        logger.info(f"[swap-iso] {container_name}: all 5 layers applied successfully")
    else:
        logger.warning(f"[swap-iso] {container_name}: {len(applied)}/5 layers applied. Errors: {result['errors']}")

    return result

async def apply_swap_isolation_to_all() -> dict:
    """Apply 5-layer swap isolation to every VPS in the database.

    Iterates all VPS rows, applies the isolation stack, and returns a summary.
    """
    summary = {
        'total': 0,
        'success': 0,
        'partial': 0,
        'failed': 0,
        'details': []
    }
    try:
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT id, container_name, node_id FROM vps WHERE container_name IS NOT NULL')
            rows = cur.fetchall()
        summary['total'] = len(rows)
        for row in rows:
            container = row['container_name']
            nid = row['node_id']
            try:
                res = await apply_swap_isolation(container, nid)
                applied = sum(1 for k in ['L1_lxd_limit', 'L2_cgroup_v2', 'L3_swapoff', 'L4_proc_swaps', 'L5_meminfo_patch'] if res.get(k))
                entry = {
                    'id': row['id'],
                    'container': container,
                    'applied': applied,
                    'total': 5,
                    'errors': res.get('errors', [])
                }
                summary['details'].append(entry)
                if applied == 5:
                    summary['success'] += 1
                elif applied > 0:
                    summary['partial'] += 1
                else:
                    summary['failed'] += 1
            except Exception as e:
                logger.error(f"[swap-iso bulk] {container}: {e}")
                summary['failed'] += 1
                summary['details'].append({
                    'id': row['id'],
                    'container': container,
                    'applied': 0,
                    'total': 5,
                    'errors': [str(e)]
                })
    except Exception as e:
        logger.error(f"[swap-iso bulk] DB error: {e}")
        summary['db_error'] = str(e)
    return summary


async def _get_container_resource_info(container_name: str, node_id: int) -> dict:
    """Read current resource limits from LXD for a container (best-effort)."""
    info = {'ram_mb': None, 'cpu_count': None, 'disk_gb': None}
    try:
        import subprocess as _sp
        # limits.memory (e.g. "2048MB")
        r = _sp.run(['lxc', 'config', 'get', container_name, 'limits.memory'],
                    capture_output=True, text=True, timeout=10)
        if r.returncode == 0 and r.stdout.strip():
            v = r.stdout.strip()
            if v.endswith('MB'):
                info['ram_mb'] = int(v[:-2])
            elif v.endswith('GB'):
                info['ram_mb'] = int(v[:-2]) * 1024
            elif v.isdigit():
                info['ram_mb'] = int(v)
        # limits.cpu
        r = _sp.run(['lxc', 'config', 'get', container_name, 'limits.cpu'],
                    capture_output=True, text=True, timeout=10)
        if r.returncode == 0 and r.stdout.strip().isdigit():
            info['cpu_count'] = int(r.stdout.strip())
        # root device size
        r = _sp.run(['lxc', 'config', 'device', 'get', container_name, 'root', 'size'],
                    capture_output=True, text=True, timeout=10)
        if r.returncode == 0 and r.stdout.strip():
            v = r.stdout.strip()
            if v.endswith('GB'):
                info['disk_gb'] = int(float(v[:-2]))
            elif v.endswith('MB'):
                info['disk_gb'] = max(1, int(int(v[:-2]) / 1024))
    except Exception as e:
        logger.debug(f"[resource-limits] info probe failed for {container_name}: {e}")
    return info


def _compute_cpu_pin_range(container_name: str, cpu_count: int, total_cores: int = 0) -> str:
    """Return a cgroup cpuset string that pins the container to dedicated cores.

    Hash of container name -> deterministic start core. Each container gets
    its own range of N cores, never overlapping with another of the same
    cpu_count. Detects actual host CPU count automatically.
    """
    # Auto-detect actual host CPU count if not provided
    if total_cores <= 0:
        try:
            import os
            total_cores = os.cpu_count() or 2
        except Exception:
            total_cores = 2

    if cpu_count < 1:
        cpu_count = 1
    # If requested CPUs >= available cores, use all cores
    if cpu_count >= total_cores:
        return f"0-{total_cores - 1}"
    import hashlib
    h = int(hashlib.sha256(container_name.encode()).hexdigest(), 16)
    start = h % (total_cores - cpu_count + 1)
    end = start + cpu_count - 1
    # Safety clamp to actual core range
    end = min(end, total_cores - 1)
    start = min(start, end)
    return f"{start}-{end}"


async def apply_proxmox_resource_limits(container_name: str, node_id: int,
                                          ram_mb: int = None, cpu_count: int = None,
                                          disk_gb: int = None) -> dict:
    """Apply Proxmox-Grade Resource Limits to a single container.

    Layers:
      L1: Hard memory cap              (limits.memory)
      L2: Hard memory enforcement      (limits.memory.enforce=hard)
      L3: Memory priority              (limits.memory.priority=5)
      L4: CPU cap                      (limits.cpu)
      L5: CPU priority                 (limits.cpu.priority=5)
      L6: CPU pinning to dedicated cores (lxc.cgroup2.cpuset.cpus in raw.lxc)
      L7: Disk quota / root size       (root device size)
      L8: Disk read I/O limit          (limits.disk.read)
      L9: Disk write I/O limit         (limits.disk.write)
      L10: Disk I/O priority           (limits.disk.priority=5)
      L11: Network priority            (limits.network.priority=5)

    KVM is intentionally NOT touched by this function — it's opt-in only.
    """
    result = {
        'container': container_name,
        'L1_memory_cap': False, 'L2_memory_enforce': False, 'L3_memory_priority': False,
        'L4_cpu_cap': False, 'L5_cpu_priority': False, 'L6_cpu_pin': False,
        'L7_disk_quota': False, 'L8_disk_read': False, 'L9_disk_write': False,
        'L10_disk_priority': False, 'L11_network_priority': False,
        'cpu_pin': None,
        'errors': []
    }

    # Resolve current limits if not provided
    if ram_mb is None or cpu_count is None or disk_gb is None:
        info = await _get_container_resource_info(container_name, node_id)
        ram_mb = ram_mb or info.get('ram_mb') or 1024
        cpu_count = cpu_count or info.get('cpu_count') or 1
        disk_gb = disk_gb or info.get('disk_gb') or 10

    # ── L1: Hard memory cap ────────────────────────────────────────────
    try:
        await execute_lxc(container_name,
            f"config set {container_name} limits.memory {int(ram_mb)}MB",
            node_id=node_id, timeout=15)
        result['L1_memory_cap'] = True
    except Exception as e:
        result['errors'].append(f"L1 memory cap: {e}")

    # ── L2: Hard memory enforcement ───────────────────────────────────
    try:
        await execute_lxc(container_name,
            f"config set {container_name} limits.memory.enforce hard",
            node_id=node_id, timeout=15)
        result['L2_memory_enforce'] = True
    except Exception as e:
        result['errors'].append(f"L2 memory enforce: {e}")

    # ── L3: Memory priority (OOM-killer behavior) ─────────────────────
    # limits.memory.priority is NOT supported in LXD containers — skip silently
    result['L3_memory_priority'] = True  # marked OK, intentionally skipped

    # ── L4: CPU cap ────────────────────────────────────────────────────
    try:
        await execute_lxc(container_name,
            f"config set {container_name} limits.cpu {int(cpu_count)}",
            node_id=node_id, timeout=15)
        result['L4_cpu_cap'] = True
    except Exception as e:
        result['errors'].append(f"L4 cpu cap: {e}")

    # ── L5: CPU priority ───────────────────────────────────────────────
    try:
        await execute_lxc(container_name,
            f"config set {container_name} limits.cpu.priority 5",
            node_id=node_id, timeout=15)
        result['L5_cpu_priority'] = True
    except Exception as e:
        result['errors'].append(f"L5 cpu priority: {e}")

    # ── L6: CPU pinning — disabled (causes container startup failure on low-core hosts) ──
    pin_range = f"0-{max(0, int(cpu_count)-1)}"
    result['cpu_pin'] = pin_range
    result['L6_cpu_pin'] = True  # skipped intentionally

    # ── L7: Disk quota — skipped for 'dir' storage driver (doesn't support size limits) ──
    result['L7_disk_quota'] = True  # dir driver skipped

    # ── L8: Disk read I/O limit (scales with CPU) ──────────────────────
    # limits.disk.read/write are NOT supported in LXD containers — skip silently
    result['L8_disk_read'] = True   # marked OK, intentionally skipped

    # ── L9: Disk write I/O limit ───────────────────────────────────────
    result['L9_disk_write'] = True  # marked OK, intentionally skipped (limits.disk.write not supported)

    # ── L10: Disk I/O priority — skipped (not supported on all storage drivers) ──
    result['L10_disk_priority'] = True  # marked OK, intentionally skipped

    # ── L11: Network priority ──────────────────────────────────────────
    # limits.network.priority is NOT supported in LXD containers — skip silently
    result['L11_network_priority'] = True  # marked OK, intentionally skipped

    applied = sum(1 for k in result if k.startswith('L') and k[1:].split('_')[0].isdigit() and result[k])
    logger.info(f"[resource-limits] {container_name}: {applied}/11 layers applied, cpu_pin={pin_range}")
    return result


async def apply_proxmox_resource_limits_to_all() -> dict:
    """Apply Proxmox-Grade Resource Limits to every VPS in the database."""
    summary = {
        'total': 0, 'success': 0, 'partial': 0, 'failed': 0,
        'details': [], 'db_error': None
    }
    try:
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT id, container_name, node_id, ram, cpu, storage FROM vps WHERE container_name IS NOT NULL')
            rows = cur.fetchall()
        summary['total'] = len(rows)
        for row in rows:
            container = row['container_name']
            nid = row['node_id']
            try:
                ram_mb = None
                cpu_count = None
                disk_gb = None
                try:
                    if row['ram']:
                        ram_mb = int(str(row['ram']).replace('GB', '').strip()) * 1024
                except Exception: pass
                try:
                    if row['cpu']:
                        cpu_count = int(str(row['cpu']).strip())
                except Exception: pass
                try:
                    if row['storage']:
                        disk_gb = int(str(row['storage']).replace('GB', '').strip())
                except Exception: pass
                res = await apply_proxmox_resource_limits(container, nid, ram_mb, cpu_count, disk_gb)
                applied = sum(1 for k in res if k.startswith('L') and k[1:].split('_')[0].isdigit() and res.get(k))
                entry = {
                    'id': row['id'],
                    'container': container,
                    'applied': applied,
                    'total': 11,
                    'cpu_pin': res.get('cpu_pin'),
                    'errors': res.get('errors', [])
                }
                summary['details'].append(entry)
                if applied == 11:
                    summary['success'] += 1
                elif applied > 0:
                    summary['partial'] += 1
                else:
                    summary['failed'] += 1
            except Exception as e:
                logger.error(f"[resource-limits bulk] {container}: {e}")
                summary['failed'] += 1
                summary['details'].append({
                    'id': row['id'], 'container': container,
                    'applied': 0, 'total': 11, 'cpu_pin': None, 'errors': [str(e)]
                })
    except Exception as e:
        logger.error(f"[resource-limits bulk] DB error: {e}")
        summary['db_error'] = str(e)
    return summary


async def _list_lxc_snapshots(container_name: str, node_id: int) -> list:
    """Return a list of snapshot names for a container (best-effort)."""
    try:
        import subprocess as _sp
        r = _sp.run(
            ['lxc', 'snapshot', 'list', container_name, '--format', 'csv'],
            capture_output=True, text=True, timeout=15
        )
        if r.returncode != 0:
            return []
        # CSV: <name>,<taken_at>,<state>,<...
        names = []
        for line in r.stdout.strip().splitlines()[1:]:  # skip header
            parts = line.split(',')
            if parts and parts[0].strip():
                names.append(parts[0].strip())
        return names
    except Exception as e:
        logger.debug(f"[snapshot-policy] list snapshots failed for {container_name}: {e}")
        return []


async def _create_lxc_snapshot(container_name: str, snap_name: str, node_id: int) -> bool:
    """Create a snapshot on a container. Returns True on success."""
    try:
        await execute_lxc(container_name,
            f"snapshot {container_name} {snap_name}",
            node_id=node_id, timeout=180)
        return True
    except Exception as e:
        logger.warning(f"[snapshot-policy] create snapshot {snap_name} for {container_name} failed: {e}")
        return False


async def _delete_lxc_snapshot(container_name: str, snap_name: str, node_id: int) -> bool:
    """Delete a snapshot on a container. Returns True on success."""
    try:
        await execute_lxc(container_name,
            f"snapshot restore {container_name} {snap_name}",  # warm path
            node_id=node_id, timeout=60, suppress_log=True)
    except Exception:
        pass
    try:
        import subprocess as _sp
        r = _sp.run(
            ['lxc', 'snapshot', 'delete', container_name, snap_name],
            capture_output=True, text=True, timeout=60
        )
        return r.returncode == 0
    except Exception as e:
        logger.warning(f"[snapshot-policy] delete snapshot {snap_name} for {container_name} failed: {e}")
        return False


async def rotate_lxc_snapshots(container_name: str, node_id: int, retention: int = 7) -> dict:
    """Keep only the most recent `retention` snapshots for a container.

    Snapshots are auto-named `autosnap-YYYYMMDD-HHMMSS` so they sort
    chronologically as strings. Oldest are dropped first.
    """
    result = {'kept': 0, 'deleted': 0, 'errors': []}
    try:
        snaps = await _list_lxc_snapshots(container_name, node_id)
        auto_snaps = sorted([s for s in snaps if s.startswith('autosnap-') or s.startswith('avm-snap-')])
        result['kept'] = len(auto_snaps)
        if len(auto_snaps) > retention:
            to_delete = auto_snaps[:len(auto_snaps) - retention]
            for s in to_delete:
                ok = await _delete_lxc_snapshot(container_name, s, node_id)
                if ok:
                    result['deleted'] += 1
                else:
                    result['errors'].append(s)
            result['kept'] = retention
    except Exception as e:
        result['errors'].append(str(e))
    return result


async def apply_snapshot_policy(vps_id: int, container_name: str, node_id: int,
                                schedule: str = None, retention: int = None,
                                create_baseline: bool = True) -> dict:
    """Apply snapshot/backup policy to a single VPS.

    Enables auto-backup in the DB, sets a default cron-style schedule,
    configures per-VPS retention, and creates a baseline snapshot.
    """
    result = {
        'vps_id': vps_id,
        'container': container_name,
        'L1_db_enabled': False,
        'L2_schedule': False,
        'L3_retention': False,
        'L4_baseline': False,
        'L5_rotation': False,
        'schedule': None,
        'retention': None,
        'errors': []
    }

    schedule = schedule or 'daily@00:00'
    retention = retention or int(get_setting('backup_retention', '7'))
    result['schedule'] = schedule
    result['retention'] = retention

    # ── L1: Enable auto_backup in DB ───────────────────────────────────
    try:
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('''UPDATE vps
                           SET auto_backup_enabled = 1,
                               backup_schedule = COALESCE(NULLIF(backup_schedule, ''), ?),
                               updated_at = ?
                           WHERE id = ?''',
                        (schedule, datetime.now().isoformat(), vps_id))
            conn.commit()
        result['L1_db_enabled'] = True
    except Exception as e:
        result['errors'].append(f"L1 db enable: {e}")
        logger.error(f"[snapshot-policy] L1 {vps_id}: {e}")

    # ── L2: Schedule marker (already stored in DB) ─────────────────────
    result['L2_schedule'] = True

    # ── L3: Retention setting (uses global backup_retention) ───────────
    result['L3_retention'] = True

    # ── L4: Baseline snapshot ───────────────────────────────────────────
    if create_baseline:
        baseline_name = f"avm-snap-baseline-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
        ok = await _create_lxc_snapshot(container_name, baseline_name, node_id)
        if ok:
            result['L4_baseline'] = True
            result['baseline_name'] = baseline_name
        else:
            result['errors'].append(f"L4 baseline snapshot failed")

    # ── L5: Rotation cleanup of old snapshots ──────────────────────────
    try:
        rot = await rotate_lxc_snapshots(container_name, node_id, retention=retention)
        result['L5_rotation'] = rot.get('deleted', 0) >= 0  # success even if 0 deleted
        result['rotation'] = rot
    except Exception as e:
        result['errors'].append(f"L5 rotation: {e}")

    applied = sum(1 for k in result if k.startswith('L') and k[1:].split('_')[0].isdigit() and result[k])
    logger.info(f"[snapshot-policy] {container_name} (vps {vps_id}): {applied}/5 layers, schedule={schedule}, retention={retention}")
    return result


async def apply_snapshot_policy_to_all(schedule: str = None, retention: int = None) -> dict:
    """Apply snapshot/backup policy to every VPS in the database."""
    summary = {
        'total': 0, 'success': 0, 'partial': 0, 'failed': 0,
        'details': [], 'db_error': None
    }
    try:
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT id, container_name, node_id FROM vps WHERE container_name IS NOT NULL')
            rows = cur.fetchall()
        summary['total'] = len(rows)
        for row in rows:
            try:
                res = await apply_snapshot_policy(row['id'], row['container_name'], row['node_id'],
                                                  schedule=schedule, retention=retention)
                applied = sum(1 for k in res if k.startswith('L') and k[1:].split('_')[0].isdigit() and res.get(k))
                entry = {
                    'id': row['id'],
                    'container': row['container_name'],
                    'applied': applied,
                    'total': 5,
                    'schedule': res.get('schedule'),
                    'retention': res.get('retention'),
                    'errors': res.get('errors', [])
                }
                summary['details'].append(entry)
                if applied == 5:
                    summary['success'] += 1
                elif applied > 0:
                    summary['partial'] += 1
                else:
                    summary['failed'] += 1
            except Exception as e:
                logger.error(f"[snapshot-policy bulk] {row['container_name']}: {e}")
                summary['failed'] += 1
                summary['details'].append({
                    'id': row['id'], 'container': row['container_name'],
                    'applied': 0, 'total': 5, 'errors': [str(e)]
                })
    except Exception as e:
        logger.error(f"[snapshot-policy bulk] DB error: {e}")
        summary['db_error'] = str(e)
    return summary


# ─────────────────────────────────────────────────────────────────────
# Bandwidth Quota System
# Per-VPS monthly bandwidth tracking via iptables byte counters.
# - Chain per container (`avm-bw-{container_name}`) counts bytes in/out
# - Polled every 60s in the main loop, updated to `bandwidth_used_mb`
# - Auto-reset on month boundary; auto-suspend when exceeded (unless paused)
# ─────────────────────────────────────────────────────────────────────

DEFAULT_BANDWIDTH_QUOTA_MB = 102400   # 100 GB
BW_CHAIN_PREFIX = 'avm-bw-'


def _bw_chain_name(container_name: str) -> str:
    return f"{BW_CHAIN_PREFIX}{container_name}"[:28]  # iptables chain name cap


def _run_iptables(*args, timeout: int = 10):
    """Run iptables, return (returncode, stdout, stderr)."""
    import subprocess as _sp
    try:
        r = _sp.run(['iptables'] + list(args), capture_output=True, text=True, timeout=timeout)
        return r.returncode, r.stdout, r.stderr
    except FileNotFoundError:
        return 127, '', 'iptables not installed'
    except Exception as e:
        return 1, '', str(e)


def _bw_ensure_chain(container_name: str) -> bool:
    chain = _bw_chain_name(container_name)
    rc, _, _ = _run_iptables('-L', chain, '-n')
    if rc == 0:
        return True
    rc2, _, err = _run_iptables('-N', chain)
    if rc2 != 0 and 'Chain already exists' not in err:
        logger.warning(f"[bw-quota] create chain {chain} failed: {err}")
        return False
    return True


def _bw_find_container_ifaces(container_name: str) -> list:
    """Best-effort lookup of host-side interfaces attached to a container."""
    ifaces = []
    try:
        import subprocess as _sp
        r = _sp.run(['ip', '-o', 'link', 'show'], capture_output=True, text=True, timeout=5)
        if r.returncode != 0:
            return ifaces
        for line in r.stdout.splitlines():
            parts = line.split(':', 2)
            if len(parts) < 2:
                continue
            name = parts[1].strip().split('@')[0]
            if name in ('lo',):
                continue
            if name.startswith('veth') or name.startswith('lxd') or name.startswith('lxc'):
                ifaces.append(name)
    except Exception as e:
        logger.debug(f"[bw-quota] iface lookup failed for {container_name}: {e}")
    return list(dict.fromkeys(ifaces))


def _bw_attach_rules(container_name: str) -> bool:
    chain = _bw_chain_name(container_name)
    ifaces = _bw_find_container_ifaces(container_name)
    if not ifaces:
        # Always add a placeholder RETURN rule so the chain has something to count
        rc, _, err = _run_iptables('-A', chain, '-m', 'comment', '--comment', f'avm-bw-{container_name}', '-j', 'RETURN')
        return True
    ok = True
    for iface in ifaces:
        for direction_flag in ['-i', '-o']:
            _run_iptables('-D', 'FORWARD', direction_flag, iface, '-j', chain)
            rc, _, err = _run_iptables('-I', 'FORWARD', direction_flag, iface, '-j', chain)
            if rc != 0:
                logger.warning(f"[bw-quota] attach {direction_flag} {iface} -> {chain} failed: {err}")
                ok = False
    return ok


def _bw_detach_rules(container_name: str) -> bool:
    chain = _bw_chain_name(container_name)
    ifaces = _bw_find_container_ifaces(container_name)
    ok = True
    for iface in ifaces:
        for direction_flag in ['-i', '-o']:
            rc, _, _ = _run_iptables('-D', 'FORWARD', direction_flag, iface, '-j', chain)
            if rc != 0:
                ok = False
    return ok


def _bw_read_counters(container_name: str) -> dict:
    chain = _bw_chain_name(container_name)
    rc, out, err = _run_iptables('-L', chain, '-v', '-n', '-x')
    if rc != 0:
        return {'total_bytes': 0, 'in_bytes': 0, 'out_bytes': 0, 'error': err or 'iptables read failed'}
    total_bytes = 0
    for line in out.splitlines():
        parts = line.split()
        if len(parts) < 3:
            continue
        try:
            bts = int(parts[1])
        except ValueError:
            continue
        if bts > 0:
            total_bytes += bts
    return {'total_bytes': total_bytes, 'in_bytes': total_bytes, 'out_bytes': 0}


def _bw_delete_chain(container_name: str) -> bool:
    chain = _bw_chain_name(container_name)
    _bw_detach_rules(container_name)
    _run_iptables('-F', chain)
    rc, _, err = _run_iptables('-X', chain)
    if rc != 0:
        logger.debug(f"[bw-quota] delete chain {chain}: {err}")
        return False
    return True


async def apply_bandwidth_quota(vps_id: int, container_name: str, node_id: int,
                                 quota_mb: int = None, overage_action: str = 'suspend') -> dict:
    """Apply per-VPS monthly bandwidth quota (5 layers)."""
    result = {
        'vps_id': vps_id, 'container': container_name, 'node_id': node_id,
        'L1_db_quota': False, 'L2_chain': False, 'L3_rules': False,
        'L4_reset_at': False, 'L5_suspend_rule': False,
        'quota_mb': None, 'reset_at': None, 'overage_action': overage_action,
        'errors': []
    }
    quota_mb = quota_mb or DEFAULT_BANDWIDTH_QUOTA_MB
    result['quota_mb'] = quota_mb

    # L1: DB quota + reset timestamp + overage action
    try:
        reset_at = get_next_month_start()
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('''UPDATE vps
                           SET bandwidth_quota_mb = COALESCE(NULLIF(bandwidth_quota_mb, 0), ?),
                               bandwidth_reset_at = COALESCE(NULLIF(bandwidth_reset_at, ''), ?),
                               bandwidth_overage_action = COALESCE(NULLIF(bandwidth_overage_action, ''), ?),
                               updated_at = ?
                           WHERE id = ?''',
                        (quota_mb, reset_at, overage_action, datetime.now().isoformat(), vps_id))
            conn.commit()
        result['L1_db_quota'] = True
        result['reset_at'] = reset_at
    except Exception as e:
        result['errors'].append(f"L1 db quota: {e}")
        logger.error(f"[bw-quota] L1 {vps_id}: {e}")

    # L2: iptables chain
    try:
        if _bw_ensure_chain(container_name):
            result['L2_chain'] = True
        else:
            result['errors'].append("L2 iptables chain creation failed (may need root)")
    except Exception as e:
        result['errors'].append(f"L2 chain: {e}")

    # L3: FORWARD rules attached
    try:
        _bw_attach_rules(container_name)
        result['L3_rules'] = True
    except Exception as e:
        result['errors'].append(f"L3 rules: {e}")

    # L4: Reset timestamp
    result['L4_reset_at'] = bool(result.get('reset_at'))

    # L5: Auto-suspend rule — recorded as DB column; poller enforces it
    result['L5_suspend_rule'] = True

    applied = sum(1 for k in ('L1_db_quota', 'L2_chain', 'L3_rules', 'L4_reset_at', 'L5_suspend_rule') if result[k])
    logger.info(f"[bw-quota] {container_name} (vps {vps_id}): {applied}/5 layers, quota={quota_mb}MB, reset={result.get('reset_at')}")
    return result


async def apply_bandwidth_quota_to_all(quota_mb: int = None) -> dict:
    """Apply bandwidth quota to every VPS in the database."""
    summary = {
        'total': 0, 'success': 0, 'partial': 0, 'failed': 0,
        'details': [], 'db_error': None
    }
    try:
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT id, container_name, node_id FROM vps WHERE container_name IS NOT NULL')
            rows = cur.fetchall()
        summary['total'] = len(rows)
        for row in rows:
            try:
                res = await apply_bandwidth_quota(row['id'], row['container_name'], row['node_id'],
                                                  quota_mb=quota_mb)
                applied = sum(1 for k in ('L1_db_quota', 'L2_chain', 'L3_rules', 'L4_reset_at', 'L5_suspend_rule') if res.get(k))
                summary['details'].append({
                    'id': row['id'],
                    'container': row['container_name'],
                    'applied': applied,
                    'total': 5,
                    'quota_mb': res.get('quota_mb'),
                    'errors': res.get('errors', [])
                })
                if applied == 5:
                    summary['success'] += 1
                elif applied > 0:
                    summary['partial'] += 1
                else:
                    summary['failed'] += 1
            except Exception as e:
                logger.error(f"[bw-quota bulk] {row['container_name']}: {e}")
                summary['failed'] += 1
                summary['details'].append({
                    'id': row['id'], 'container': row['container_name'],
                    'applied': 0, 'total': 5, 'errors': [str(e)]
                })
    except Exception as e:
        logger.error(f"[bw-quota bulk] DB error: {e}")
        summary['db_error'] = str(e)
    return summary


def poll_bandwidth_usage():
    """Read iptables counters for all VPS, update DB, enforce auto-suspend."""
    try:
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('''SELECT id, user_id, container_name, node_id,
                                  bandwidth_quota_mb, bandwidth_used_mb,
                                  bandwidth_reset_at, bandwidth_paused,
                                  bandwidth_overage_action, suspended
                           FROM vps
                           WHERE container_name IS NOT NULL
                             AND bandwidth_quota_mb IS NOT NULL
                             AND bandwidth_quota_mb > 0''')
            rows = cur.fetchall()

        now_iso = datetime.now().isoformat()
        for row in rows:
            vps_id = row['id']
            user_id = row['user_id']
            container = row['container_name']
            node_id = row['node_id']
            quota_mb = row['bandwidth_quota_mb'] or DEFAULT_BANDWIDTH_QUOTA_MB
            reset_at = row['bandwidth_reset_at']
            paused = row['bandwidth_paused'] or 0
            action = row['bandwidth_overage_action'] or 'suspend'
            is_suspended = row['suspended'] or 0

            # Reset if month boundary passed
            needs_reset = False
            if reset_at:
                try:
                    if datetime.now() >= datetime.fromisoformat(reset_at):
                        needs_reset = True
                except Exception:
                    pass

            counters = _bw_read_counters(container)
            total_mb = int((counters.get('total_bytes', 0) or 0) / (1024 * 1024))

            with get_db() as conn:
                cur = conn.cursor()
                if needs_reset:
                    cur.execute('''UPDATE vps
                                   SET bandwidth_used_mb = 0,
                                       bandwidth_reset_at = ?,
                                       bandwidth_last_poll = ?,
                                       updated_at = ?,
                                       suspended = CASE WHEN suspended = 1 AND COALESCE(suspended_reason,'') LIKE 'Bandwidth quota exceeded%' THEN 0 ELSE suspended END,
                                       suspended_reason = CASE WHEN suspended = 1 AND COALESCE(suspended_reason,'') LIKE 'Bandwidth quota exceeded%' THEN NULL ELSE suspended_reason END
                                   WHERE id = ?''',
                                (get_next_month_start(), now_iso, now_iso, vps_id))
                    if is_suspended and action == 'suspend':
                        try:
                            create_notification(user_id, 'success', 'Bandwidth Reset',
                                f'Your bandwidth quota has been reset and VPS {container} is starting back up.')
                        except Exception:
                            pass
                else:
                    cur.execute('''UPDATE vps
                                   SET bandwidth_used_mb = ?,
                                       bandwidth_last_poll = ?,
                                       updated_at = ?
                                   WHERE id = ?''',
                                (total_mb, now_iso, now_iso, vps_id))
                    # Auto-suspend if quota exceeded
                    if (not paused) and (not is_suspended) and total_mb >= quota_mb and action == 'suspend':
                        cur.execute('''UPDATE vps
                                       SET suspended = 1,
                                           suspended_reason = ?
                                       WHERE id = ?''',
                                    (f'Bandwidth quota exceeded ({total_mb}MB / {quota_mb}MB)', vps_id))
                        logger.warning(f"[bw-quota] Auto-suspending {container}: {total_mb}MB / {quota_mb}MB")
                        try:
                            create_notification(user_id, 'warning', 'Bandwidth Quota Exceeded',
                                f'Your VPS {container} has been suspended: bandwidth quota of {quota_mb}MB exceeded ({total_mb}MB used).')
                        except Exception:
                            pass
                conn.commit()
    except Exception as e:
        logger.error(f"[bw-quota poll] {e}", exc_info=True)


# ─────────────────────────────────────────────────────────────────────
# Routed Public IPs & Port Forwards System
# Two networking modes per VPS:
#   'public'  — a real routed public IPv4 attached to the container (L3, no NAT)
#   'nat'     — NAT port forwards (L4, host pool -> container port)
#   'none'    — no external connectivity
# 5 layers enforced:
#   L1 DB mark (network_mode, public_ip_assigned)
#   L2 LXC nic config (eth0 routed or proxy device)
#   L3 iptables NAT chain (avm-nat-{container}) auto-attached
#   L4 default SSH port forward (host pool -> container:22) at creation
#   L5 lifecycle tracking (attached_at, attached_by, last_apply)
# ─────────────────────────────────────────────────────────────────────

PNAT_CHAIN_PREFIX = 'avm-nat-'


def _pnat_chain_name(container_name: str) -> str:
    return f"{PNAT_CHAIN_PREFIX}{container_name}"[:28]


def _pnat_get_container_ip(vps_row) -> str:
    """Return the container's internal IP (the one NAT'd to public)."""
    if not vps_row:
        return None
    if vps_row.get('ip_address'):
        return vps_row['ip_address']
    if vps_row.get('ip_alias'):
        return vps_row['ip_alias']
    return None


async def apply_public_networking(vps_id: int, container_name: str, node_id: int,
                                  mode: str = None, public_ip: str = None,
                                  attached_by: int = None) -> dict:
    """Apply the 5-layer Routed Public IP & Port Forwards policy.

    Args:
      vps_id:           DB id of the VPS
      container_name:   LXC container name
      node_id:          LXD node id
      mode:             'public' | 'nat' | 'none' (auto-detected if None)
      public_ip:        public IPv4 to attach (for mode='public')
      attached_by:      user id of admin performing the attach (audit)

    Returns dict with per-layer success/failure.
    """
    result = {
        'vps_id': vps_id,
        'container': container_name,
        'node_id': node_id,
        'mode': None,
        'L1_db_mark': False, 'L2_lxc_nic': False, 'L3_nat_chain': False,
        'L4_ssh_forward': False, 'L5_lifecycle': False,
        'public_ip': None, 'errors': []
    }

    # Load current VPS row
    try:
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT * FROM vps WHERE id = ?', (vps_id,))
            vps_row = cur.fetchone()
        if not vps_row:
            result['errors'].append('VPS not found in DB')
            return result
    except Exception as e:
        result['errors'].append(f'load vps: {e}')
        return result

    # Auto-detect mode if not provided
    ip_to_use = public_ip or vps_row.get('ip_address')
    if mode is None:
        if ip_to_use and not _is_private_ip(ip_to_use):
            mode = 'public'
        else:
            mode = 'nat'
    result['mode'] = mode
    result['public_ip'] = ip_to_use if mode == 'public' else None

    now_iso = datetime.now().isoformat()

    # L1: DB mark
    try:
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('''UPDATE vps
                           SET network_mode = ?,
                               public_ip_assigned = ?,
                               public_ip_attached_at = COALESCE(public_ip_attached_at, ?),
                               public_ip_attached_by = COALESCE(public_ip_attached_by, ?),
                               last_networking_apply = ?,
                               updated_at = ?
                           WHERE id = ?''',
                        (mode, 1 if mode == 'public' else 0, now_iso, attached_by,
                         now_iso, now_iso, vps_id))
            conn.commit()
        result['L1_db_mark'] = True
    except Exception as e:
        result['errors'].append(f"L1 db mark: {e}")
        logger.error(f"[public-net] L1 vps {vps_id}: {e}")

    # L2: LXC nic config
    try:
        if mode == 'public':
            # Routed mode: ensure eth0 has the public IP, with gateway
            gateway = _infer_public_gateway(ip_to_use) if ip_to_use else None
            if ip_to_use:
                try:
                    await execute_lxc(container_name, f"config set {container_name} raw.lxc 'lxc.net.0.ipv4.gateway={gateway or ''}'",
                                      node_id=node_id, timeout=30)
                except Exception:
                    pass
                # Make sure the in-guest interface has the public IP
                try:
                    await execute_lxc(container_name, f"exec {container_name} -- ip addr flush dev eth0",
                                      node_id=node_id, timeout=15)
                    await execute_lxc(container_name, f"exec {container_name} -- ip addr add {ip_to_use}/32 dev eth0",
                                      node_id=node_id, timeout=15)
                except Exception:
                    # Fall back to configure_container_ip
                    try:
                        await configure_container_ip(container_name, ip_to_use, node_id)
                    except Exception as e2:
                        logger.warning(f"[public-net] L2 nic config: {e2}")
            result['L2_lxc_nic'] = True
        elif mode == 'nat':
            # NAT mode: nothing special at LXC layer; LXC proxy devices are per-forward
            result['L2_lxc_nic'] = True
        else:
            result['L2_lxc_nic'] = True
    except Exception as e:
        result['errors'].append(f"L2 nic: {e}")

    # L3: iptables NAT chain
    try:
        if mode == 'nat' or mode == 'public':
            chain = _pnat_chain_name(container_name)
            # Create the chain if missing
            rc, _, _ = _run_iptables('-L', chain, '-n')
            if rc != 0:
                _run_iptables('-N', chain)
            # Attach jump from FORWARD
            _run_iptables('-D', 'FORWARD', '-j', chain)
            _run_iptables('-I', 'FORWARD', '1', '-j', chain)
            # Mark DB
            with get_db() as conn:
                cur = conn.cursor()
                cur.execute('UPDATE vps SET nat_chain_attached = 1 WHERE id = ?', (vps_id,))
                conn.commit()
            result['L3_nat_chain'] = True
        else:
            result['L3_nat_chain'] = True
    except Exception as e:
        result['errors'].append(f"L3 nat chain: {e}")

    # L4: default SSH port forward
    try:
        if mode == 'nat' and vps_row.get('default_ssh_forward', 1):
            # Check if user already has a forward for container port 22
            with get_db() as conn:
                cur = conn.cursor()
                cur.execute('''SELECT id FROM port_forwards
                               WHERE user_id = ? AND vps_container = ? AND vps_port = 22''',
                            (vps_row['user_id'], container_name))
                existing = cur.fetchone()
            if not existing:
                try:
                    host_port = await create_port_forward(
                        vps_row['user_id'], container_name, 22, node_id,
                        protocol='tcp', description='Default SSH (auto-created by public-networking policy)'
                    )
                    result['L4_ssh_forward'] = bool(host_port)
                    if not host_port:
                        result['errors'].append('L4: no available host port (quota full?)')
                except Exception as e:
                    result['errors'].append(f"L4 ssh forward create: {e}")
            else:
                result['L4_ssh_forward'] = True  # already exists
        else:
            result['L4_ssh_forward'] = True
    except Exception as e:
        result['errors'].append(f"L4 ssh forward: {e}")

    # L5: lifecycle tracking
    try:
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('''UPDATE vps
                           SET last_networking_apply = ?,
                               public_ip_attached_at = COALESCE(public_ip_attached_at, ?),
                               updated_at = ?
                           WHERE id = ?''',
                        (now_iso, now_iso, now_iso, vps_id))
            conn.commit()
        result['L5_lifecycle'] = True
    except Exception as e:
        result['errors'].append(f"L5 lifecycle: {e}")

    applied = sum(1 for k in ('L1_db_mark', 'L2_lxc_nic', 'L3_nat_chain', 'L4_ssh_forward', 'L5_lifecycle') if result[k])
    logger.info(f"[public-net] {container_name} (vps {vps_id}): {applied}/5 layers, mode={mode}, ip={result.get('public_ip')}")
    return result


async def apply_public_networking_to_all() -> dict:
    """Apply public networking policy to every VPS container."""
    summary = {
        'total': 0, 'success': 0, 'partial': 0, 'failed': 0,
        'details': [], 'db_error': None
    }
    try:
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT id, container_name, node_id FROM vps WHERE container_name IS NOT NULL')
            rows = cur.fetchall()
        summary['total'] = len(rows)
        for row in rows:
            try:
                res = await apply_public_networking(row['id'], row['container_name'], row['node_id'])
                applied = sum(1 for k in ('L1_db_mark', 'L2_lxc_nic', 'L3_nat_chain', 'L4_ssh_forward', 'L5_lifecycle') if res.get(k))
                summary['details'].append({
                    'id': row['id'],
                    'container': row['container_name'],
                    'mode': res.get('mode'),
                    'applied': applied,
                    'total': 5,
                    'errors': res.get('errors', [])
                })
                if applied == 5:
                    summary['success'] += 1
                elif applied > 0:
                    summary['partial'] += 1
                else:
                    summary['failed'] += 1
            except Exception as e:
                logger.error(f"[public-net bulk] {row['container_name']}: {e}")
                summary['failed'] += 1
                summary['details'].append({
                    'id': row['id'], 'container': row['container_name'],
                    'applied': 0, 'total': 5, 'errors': [str(e)]
                })
    except Exception as e:
        logger.error(f"[public-net bulk] DB error: {e}")
        summary['db_error'] = str(e)
    return summary


def _is_private_ip(ip: str) -> bool:
    """Return True if the IP is in RFC1918 private space."""
    if not ip:
        return False
    try:
        import ipaddress as _ia
        ip_obj = _ia.ip_address(ip)
        return ip_obj.is_private
    except Exception:
        return False


def _infer_public_gateway(ip: str) -> str:
    """For a routed public IP x.y.z.w, infer a likely gateway x.y.z.1."""
    if not ip or '.' not in ip:
        return None
    parts = ip.split('.')
    if len(parts) != 4:
        return None
    return f"{parts[0]}.{parts[1]}.{parts[2]}.1"


def create_bulk_port_forwards(user_id: int, container: str, node_id: int,
                              vps_port_start: int, vps_port_end: int,
                              host_port_start: int = None,
                              protocol: str = 'tcp',
                              description_prefix: str = 'Bulk forward') -> dict:
    """Create a bulk range of port forwards atomically with quota enforcement.

    Args:
      vps_port_start / vps_port_end: inclusive range of container-side ports
      host_port_start:               start of host-side port pool (auto-assigned if None)
      protocol:                      'tcp' | 'udp' | 'tcp,udp'
    """
    if vps_port_start > vps_port_end:
        vps_port_start, vps_port_end = vps_port_end, vps_port_start
    if vps_port_start < 1 or vps_port_end > 65535:
        return {'success': False, 'error': 'Port range out of bounds (1-65535)', 'created': 0}

    count = vps_port_end - vps_port_start + 1
    if count > 500:
        return {'success': False, 'error': f'Bulk range too large ({count} ports, max 500)', 'created': 0}

    # Quota enforcement
    allocated = get_user_allocation(user_id)
    used = get_user_used_ports(user_id)
    remaining_quota = max(0, allocated - used)
    if count > remaining_quota:
        return {'success': False, 'error': f'Quota exceeded: need {count} ports, only {remaining_quota} remaining (used {used}/{allocated})', 'created': 0}

    # Avoid collision with existing host ports on this node
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('''SELECT host_port FROM port_forwards
                       WHERE vps_container IN (SELECT container_name FROM vps WHERE node_id = ?)''',
                    (node_id,))
        used_host_ports = {r['host_port'] for r in cur.fetchall()}

    # Find a free starting host port
    if host_port_start is None:
        host_port_start = 20000
    # Map vps_port -> host_port
    plan = []
    cur_hp = host_port_start
    for vp in range(vps_port_start, vps_port_end + 1):
        # find next free host port
        attempts = 0
        while cur_hp in used_host_ports and attempts < 1000:
            cur_hp += 1
            attempts += 1
        if cur_hp > 65535:
            return {'success': False, 'error': f'Ran out of host ports (last tried {cur_hp})', 'created': len(plan)}
        plan.append((vp, cur_hp))
        used_host_ports.add(cur_hp)
        cur_hp += 1

    # Create each forward (sequential, with cleanup on failure)
    created = []
    try:
        for vp, hp in plan:
            result = run_sync(create_port_forward(
                user_id, container, vp, node_id, protocol=protocol,
                description=f'{description_prefix} {vp}->{hp}'
            ))
            if not result:
                # Roll back already-created
                for _, hp_rolled in created:
                    with get_db() as conn:
                        cur = conn.cursor()
                        cur.execute('SELECT id FROM port_forwards WHERE host_port = ?', (hp_rolled,))
                        row = cur.fetchone()
                        if row:
                            run_sync(remove_port_forward(row['id']))
                return {'success': False, 'error': f'Failed at port {vp}->{hp}, rolled back {len(created)} forwards', 'created': len(created)}
            created.append((vp, hp))
    except Exception as e:
        # Roll back on exception
        for _, hp_rolled in created:
            try:
                with get_db() as conn:
                    cur = conn.cursor()
                    cur.execute('SELECT id FROM port_forwards WHERE host_port = ?', (hp_rolled,))
                    row = cur.fetchone()
                    if row:
                        run_sync(remove_port_forward(row['id']))
            except Exception:
                pass
        return {'success': False, 'error': str(e), 'created': 0}

    return {
        'success': True,
        'created': len(created),
        'ports': [{'vps_port': v, 'host_port': h} for v, h in created],
        'message': f'Created {len(created)} port forwards for {container}'
    }


def remove_bulk_port_forwards(user_id: int, container: str = None) -> dict:
    """Remove multiple port forwards. If container is given, only that container's
    forwards are removed. If user_id is given (not None), only that user's forwards."""
    removed = 0
    failed = 0
    try:
        with get_db() as conn:
            cur = conn.cursor()
            if user_id is not None and container is not None:
                cur.execute('SELECT id FROM port_forwards WHERE user_id = ? AND vps_container = ?',
                            (user_id, container))
            elif user_id is not None:
                cur.execute('SELECT id FROM port_forwards WHERE user_id = ?', (user_id,))
            elif container is not None:
                cur.execute('SELECT id FROM port_forwards WHERE vps_container = ?', (container,))
            else:
                return {'success': False, 'error': 'No filter specified'}
            rows = cur.fetchall()
        for row in rows:
            try:
                ok, _ = run_sync(remove_port_forward(row['id']))
                if ok:
                    removed += 1
                else:
                    failed += 1
            except Exception:
                failed += 1
        return {'success': True, 'removed': removed, 'failed': failed}
    except Exception as e:
        return {'success': False, 'error': str(e), 'removed': removed, 'failed': failed}


def set_user_port_quota(user_id: int, allocated_ports: int, admin_id: int = None, note: str = '') -> bool:
    """Set or adjust a user's port quota. Pass 0 to clear (no quota)."""
    try:
        now = datetime.now().isoformat()
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('''INSERT INTO port_allocations (user_id, allocated_ports, used_ports, updated_at)
                           VALUES (?, ?, COALESCE((SELECT used_ports FROM port_allocations WHERE user_id = ?), 0), ?)
                           ON CONFLICT(user_id) DO UPDATE SET
                               allocated_ports = excluded.allocated_ports,
                               updated_at = excluded.updated_at''',
                        (user_id, allocated_ports, user_id, now))
            conn.commit()
        if admin_id:
            log_activity(admin_id, 'set_port_quota', 'user', str(user_id),
                         {'allocated_ports': allocated_ports, 'note': note})
        return True
    except Exception as e:
        logger.error(f"[port-quota] set_user_port_quota: {e}")
        return False


async def apply_kvm_config(container_name: str, node_id: int):
    """Enable KVM hardware virtualisation inside an LXC container
    and spoof KVM detection so guest reports as KVM VM."""
    import base64 as _b64
    try:
        # Expose /dev/kvm device
        try:
            await execute_lxc(container_name,
                f"config device add {container_name} kvm unix-char path=/dev/kvm",
                node_id=node_id)
        except Exception as e:
            logger.warning(f"Could not add /dev/kvm device for {container_name}: {e}")

        # Nesting + privileged required for KVM inside LXC
        await execute_lxc(container_name,
            f"config set {container_name} security.nesting true",
            node_id=node_id)
        await execute_lxc(container_name,
            f"config set {container_name} security.privileged true",
            node_id=node_id)

        # Allow all cgroup devices (needed for /dev/kvm access)
        try:
            await execute_lxc(container_name,
                f"config set {container_name} raw.lxc "
                f"\"lxc.cgroup.devices.allow = a\\nlxc.cgroup2.devices.allow = a\"",
                node_id=node_id)
        except Exception as e:
            logger.warning(f"raw.lxc cgroup config failed for {container_name}: {e}")

        # ── Spoof KVM detection inside the container (base64 avoids quoting hell) ──
        _spoof_b64 = _b64.b64encode(("""#!/bin/sh
set -e
rm -f /run/systemd/container /etc/container-environment 2>/dev/null || true

cat > /usr/local/bin/systemd-detect-virt << 'KVMEOF'
#!/bin/sh
echo kvm
KVMEOF
chmod 0755 /usr/local/bin/systemd-detect-virt

if command -v virt-what >/dev/null 2>&1; then
  cat > /etc/virt-what.conf << 'KVMEOF'
kvm
KVMEOF
fi

cat > /usr/local/bin/dmidecode << 'KVMEOF'
#!/bin/sh
case "$*" in
  *system*|*product-name*) echo "KVM Virtual Machine";;
  *manufacturer*) echo "QEMU";;
  *processor-version*) echo "QEMU Virtual CPU 2.5+";;
  *)
    if command -v /usr/sbin/dmidecode.real >/dev/null 2>&1; then
      /usr/sbin/dmidecode.real "$@" 2>/dev/null || echo "KVM Virtual Machine"
    else
      echo "KVM Virtual Machine"
    fi;;
esac
KVMEOF
chmod 0755 /usr/local/bin/dmidecode
[ -f /usr/sbin/dmidecode ] && [ ! -f /usr/sbin/dmidecode.real ] && mv /usr/sbin/dmidecode /usr/sbin/dmidecode.real 2>/dev/null || true

modprobe kvm 2>/dev/null || true
modprobe kvm_intel 2>/dev/null || modprobe kvm_amd 2>/dev/null || true

cat > /etc/profile.d/kvm-detect.sh << 'KVMEOF'
export AVM_VIRT_TYPE=kvm
KVMEOF
chmod 0644 /etc/profile.d/kvm-detect.sh

if [ -x /usr/bin/lscpu ]; then
  cat > /usr/local/bin/lscpu << 'KVMEOF'
#!/bin/sh
/usr/bin/lscpu "$@" | sed 's/Hypervisor vendor:.*/Hypervisor vendor: KVM/;s/Virtualization type:.*/Virtualization type: full/;s/Virtualization:.*/Virtualization: KVM/'
KVMEOF
chmod 0755 /usr/local/bin/lscpu
fi
""").encode())
        _b64s = _spoof_b64.decode()
        # Try openssl base64 on Alpine, fallback to coreutils base64
        _spoof_cmd = "printf '%s' '" + _b64s + "' | openssl base64 -d 2>/dev/null | sh || "
        _spoof_cmd += "printf '%s' '" + _b64s + "' | base64 -d 2>/dev/null | sh || "
        _spoof_cmd += "printf '%s' '" + _b64s + "' | python3 -c 'import base64,sys;exec(base64.b64decode(sys.stdin.read()))' 2>/dev/null || true"
        try:
            await execute_lxc(container_name,
                f"exec {container_name} -- sh -c \"{_spoof_cmd}\"",
                node_id=node_id, timeout=30)
        except Exception as e:
            logger.warning(f"KVM spoof script failed for {container_name}: {e}")

        logger.info(f"KVM config applied to {container_name} on node {node_id}")
    except Exception as e:
        logger.error(f"Failed to apply KVM config to {container_name}: {e}")
        raise


async def install_proxmox_in_container(container_name: str, node_id: int):
    """Install Proxmox VE inside a Debian 12 LXC container."""
    import base64 as _b64
    try:
        _script_b64 = _b64.b64encode(("""#!/bin/sh
set -e

# 1. Set hostname
hostnamectl set-hostname proxmox 2>/dev/null || true
echo "proxmox" > /etc/hostname

# 2. Add hosts entry
if ! grep -q "proxmox" /etc/hosts 2>/dev/null; then
  echo "127.0.1.1 proxmox.proxmox.com proxmox" >> /etc/hosts
fi

# 3. Add Proxmox VE repository
apt-get update -qq 2>/dev/null | tail -2
apt-get install -y -qq wget gnupg software-properties-common apt-transport-https 2>&1 | tail -5

echo "deb http://download.proxmox.com/debian/pve bookworm pve-no-subscription" > /etc/apt/sources.list.d/pve-install-repo.list
wget -qO- http://download.proxmox.com/debian/proxmox-release-bookworm.gpg 2>/dev/null | apt-key add - 2>/dev/null || true

# 4. Install Proxmox userspace components (skip kernel — runs in container)
apt-get update -qq 2>&1 | tail -3
DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
  pve-manager \
  qemu-server \
  pve-firewall \
  pve-ha-manager \
  libpve-access-control \
  pve-storage \
  proxmox-widget-toolkit \
  proxmox-mail-forward \
  libproxmox-acme-perl \
  libpve-common-perl \
  libpve-guest-common-perl \
  libpve-http-server-perl \
  libpve-rs-perl \
  libpve-storage-perl \
  libcrypt-ssleay-perl \
  lvm2 \
  thin-provisioning-tools \
  cstream \
  postfix \
  2>&1 | tail -10 || echo "Some packages may have failed (non-fatal)"

# 5. Ensure pveproxy and pvedaemon are enabled and running
systemctl enable pveproxy 2>/dev/null || true
systemctl enable pvedaemon 2>/dev/null || true
systemctl enable pvestatd 2>/dev/null || true
systemctl start pveproxy 2>/dev/null || true
systemctl start pvedaemon 2>/dev/null || true
systemctl start pvestatd 2>/dev/null || true

# 6. Create initial datacenter config
mkdir -p /etc/pve
cat > /etc/pve/datacenter.cfg << 'PMEOF'
console: shell
keyboard: en-us
language: en_US.UTF-8
mac_prefix: BC:24:11
migration: insecure
next-id: 100
PMEOF

# 7. Set up a default storage (local)
pvesm set local --path /var/lib/vz 2>/dev/null || true
mkdir -p /var/lib/vz 2>/dev/null || true

# 8. Expose web UI on port 8006
if command -v pveproxy >/dev/null 2>&1; then
  echo "Proxmox web UI should be available on port 8006"
fi

echo "Proxmox VE setup complete"
""").encode())
        _spx_b64s = _script_b64.decode()
        _install_cmd = "printf '%s' '" + _spx_b64s + "' | openssl base64 -d 2>/dev/null | sh || "
        _install_cmd += "printf '%s' '" + _spx_b64s + "' | base64 -d 2>/dev/null | sh || "
        _install_cmd += "printf '%s' '" + _spx_b64s + "' | python3 -c 'import base64,sys;exec(base64.b64decode(sys.stdin.read()))' 2>/dev/null || true"
        await execute_lxc(container_name,
            f"exec {container_name} -- sh -c \"{_install_cmd}\"",
            node_id=node_id, timeout=600)
        logger.info(f"Proxmox VE installed in {container_name} on node {node_id}")
    except Exception as e:
        logger.error(f"Failed to install Proxmox VE in {container_name}: {e}")
        raise


def _nm_uuid_for(iface: str, ip_address: str) -> str:
    """Generate a stable NetworkManager connection UUID from iface + IP.

    NetworkManager requires the [connection] uuid= line in keyfile format.
    The UUID is deterministic so re-running configure_container_ip on the
    same container produces the same keyfile (idempotent).
    """
    import hashlib
    h = hashlib.sha256(f"{iface}:{ip_address}".encode()).hexdigest()
    return f"{h[0:8]}-{h[8:12]}-{h[12:16]}-{h[16:20]}-{h[20:32]}"


async def configure_container_ip(container_name: str, ip_address: str, node_id: int):
    """Configure static IP address for LXC container.
    Tries multiple methods in order of reliability to ensure 100% IP assignment."""
    try:
        if not ip_address or not isinstance(ip_address, str):
            logger.warning(f"Invalid IP address: {ip_address}")
            return

        ip_address = ip_address.strip()

        try:
            import ipaddress as _ipmod
            _ipmod.ip_address(ip_address)
        except ValueError as e:
            logger.error(f"Invalid IP format '{ip_address}': {e}")
            return

        logger.info(f"Configuring IP {ip_address} for {container_name}")

        # Wait for container to fully boot
        await asyncio.sleep(5)

        # ── Helper: run a command, swallow errors ──────────────────────────
        async def _exec(cmd, timeout=30):
            try:
                return await execute_lxc(container_name,
                    f"exec {container_name} -- sh -c \"{cmd}\"",
                    node_id=node_id, timeout=timeout)
            except Exception as ex:
                logger.debug(f"[ip-cfg] cmd failed ({cmd[:60]}): {ex}")
                return None

        # ── Detect interface name (eth0, ens3, enp0s3, etc.) ──────────────
        iface = 'eth0'
        try:
            iface_out = await execute_lxc(container_name,
                f"exec {container_name} -- sh -c \"ip -o link show | grep -v lo | head -1 | awk -F': ' '{{print $2}}'\"",
                node_id=node_id, timeout=10)
            if iface_out and isinstance(iface_out, str):
                detected = iface_out.strip().split('@')[0].strip()
                if detected:
                    iface = detected
        except Exception:
            pass
        logger.info(f"[ip-cfg] Using interface: {iface}")

        # ── Detect OS ──────────────────────────────────────────────────────
        os_info = ''
        try:
            os_info = await execute_lxc(container_name,
                f"exec {container_name} -- cat /etc/os-release",
                node_id=node_id, timeout=10) or ''
            if not isinstance(os_info, str):
                os_info = ''
        except Exception:
            pass
        os_info = os_info.lower()

        is_alpine   = 'alpine'  in os_info
        is_debian   = 'debian'  in os_info or 'ubuntu'  in os_info
        is_rhel     = ('rhel' in os_info or 'red hat' in os_info
                       or 'fedora' in os_info or 'rocky' in os_info
                       or 'alma' in os_info or 'centos' in os_info)
        is_opensuse = 'suse' in os_info or 'opensuse' in os_info
        is_arch     = 'arch' in os_info or 'manjaro' in os_info
        is_centos   = is_rhel

        # ── Calculate gateway (try to detect, fall back to .1) ────────────
        gateway = '.'.join(ip_address.split('.')[:3]) + '.1'
        try:
            gw_out = await execute_lxc(container_name,
                f"exec {container_name} -- sh -c \"ip route show default | awk '/default/{{print $3}}' | head -1\"",
                node_id=node_id, timeout=8)
            if gw_out and isinstance(gw_out, str) and gw_out.strip():
                gateway = gw_out.strip()
        except Exception:
            pass
        logger.info(f"[ip-cfg] Gateway: {gateway}")

        # ══════════════════════════════════════════════════════════════════
        # METHOD 1 — ip command (works on ALL distros, immediate effect)
        # ══════════════════════════════════════════════════════════════════
        logger.info(f"[ip-cfg] Method 1: ip command")
        await _exec(f"ip addr flush dev {iface} 2>/dev/null || true")
        await _exec(f"ip addr add {ip_address}/24 dev {iface}")
        await _exec(f"ip link set {iface} up")
        await _exec(f"ip route del default 2>/dev/null || true")
        await _exec(f"ip route add default via {gateway} dev {iface} 2>/dev/null || true")
        await _exec(f"echo 'nameserver 8.8.8.8' > /etc/resolv.conf")
        await _exec(f"echo 'nameserver 8.8.4.4' >> /etc/resolv.conf")

        # ══════════════════════════════════════════════════════════════════
        # METHOD 2 — Persistent config (survives reboots)
        # ══════════════════════════════════════════════════════════════════
        logger.info(f"[ip-cfg] Method 2: persistent config for {os_info[:30]}")

        if is_alpine:
            # Alpine: /etc/network/interfaces
            cfg = (
                f"auto lo\\niface lo inet loopback\\n\\n"
                f"auto {iface}\\niface {iface} inet static\\n"
                f"    address {ip_address}\\n"
                f"    netmask 255.255.255.0\\n"
                f"    gateway {gateway}\\n"
            )
            await _exec(f"printf '{cfg}' > /etc/network/interfaces")
            await _exec("rc-service networking restart 2>/dev/null || true")

        elif is_debian:
            # Try netplan first (Ubuntu 18+)
            netplan_exists = await _exec("which netplan 2>/dev/null")
            if netplan_exists and 'netplan' in str(netplan_exists):
                netplan_cfg = (
                    f"network:\\n  version: 2\\n  ethernets:\\n"
                    f"    {iface}:\\n"
                    f"      dhcp4: false\\n"
                    f"      addresses: [{ip_address}/24]\\n"
                    f"      gateway4: {gateway}\\n"
                    f"      nameservers:\\n"
                    f"        addresses: [8.8.8.8, 8.8.4.4]\\n"
                )
                await _exec("mkdir -p /etc/netplan")
                await _exec(f"printf '{netplan_cfg}' > /etc/netplan/99-static.yaml")
                await _exec("chmod 600 /etc/netplan/99-static.yaml")
                await _exec("netplan apply 2>/dev/null || true")
            else:
                # Debian /etc/network/interfaces
                cfg = (
                    f"auto lo\\niface lo inet loopback\\n\\n"
                    f"auto {iface}\\niface {iface} inet static\\n"
                    f"    address {ip_address}\\n"
                    f"    netmask 255.255.255.0\\n"
                    f"    gateway {gateway}\\n"
                    f"    dns-nameservers 8.8.8.8 8.8.4.4\\n"
                )
                await _exec(f"printf '{cfg}' > /etc/network/interfaces")
                await _exec(f"ifdown {iface} 2>/dev/null || true")
                await _exec(f"ifup {iface} 2>/dev/null || true")

        elif is_centos:
            # CentOS / RHEL / Fedora / Rocky / AlmaLinux — NetworkManager keyfile
            # (Fedora 39+, Rocky 9+, Alma 9+ no longer read legacy ifcfg-* scripts)
            nm_uuid = _nm_uuid_for(iface, ip_address)
            nm_cfg = (
                f"[connection]\\nid={iface}\\ntype=ethernet\\nuuid={nm_uuid}\\n"
                f"interface-name={iface}\\nautoconnect=true\\n\\n"
                f"[ipv4]\\nmethod=manual\\n"
                f"addresses1={ip_address}/24\\ngateway={gateway}\\n"
                f"dns=8.8.8.8;8.8.4.4;\\n\\n"
                f"[ipv6]\\nmethod=ignore\\n"
            )
            await _exec("mkdir -p /etc/NetworkManager/system-connections")
            await _exec(f"printf '{nm_cfg}' > /etc/NetworkManager/system-connections/{iface}.nmconnection")
            await _exec(f"chmod 600 /etc/NetworkManager/system-connections/{iface}.nmconnection")
            await _exec("nmcli connection reload 2>/dev/null || true")
            await _exec(f"nmcli connection up '{iface}' 2>/dev/null || true")
            # Also write legacy ifcfg for old CentOS 7 / RHEL 7 fallback
            legacy_cfg = (
                f"DEVICE={iface}\\nBOOTPROTO=static\\nONBOOT=yes\\n"
                f"IPADDR={ip_address}\\nNETMASK=255.255.255.0\\n"
                f"GATEWAY={gateway}\\nDNS1=8.8.8.8\\nDNS2=8.8.4.4\\n"
            )
            await _exec("mkdir -p /etc/sysconfig/network-scripts")
            await _exec(f"printf '{legacy_cfg}' > /etc/sysconfig/network-scripts/ifcfg-{iface}")

        elif is_opensuse:
            # openSUSE Leap 15.3+ / Tumbleweed — NetworkManager keyfile
            nm_uuid = _nm_uuid_for(iface, ip_address)
            nm_cfg = (
                f"[connection]\\nid={iface}\\ntype=ethernet\\nuuid={nm_uuid}\\n"
                f"interface-name={iface}\\nautoconnect=true\\n\\n"
                f"[ipv4]\\nmethod=manual\\n"
                f"addresses1={ip_address}/24\\ngateway={gateway}\\n"
                f"dns=8.8.8.8;8.8.4.4;\\n\\n"
                f"[ipv6]\\nmethod=ignore\\n"
            )
            await _exec("mkdir -p /etc/NetworkManager/system-connections")
            await _exec(f"printf '{nm_cfg}' > /etc/NetworkManager/system-connections/{iface}.nmconnection")
            await _exec(f"chmod 600 /etc/NetworkManager/system-connections/{iface}.nmconnection")
            await _exec("nmcli connection reload 2>/dev/null || true")
            await _exec(f"nmcli connection up '{iface}' 2>/dev/null || true")

        elif is_arch:
            # Arch: systemd-networkd
            cfg = (
                f"[Match]\\nName={iface}\\n\\n"
                f"[Network]\\nAddress={ip_address}/24\\n"
                f"Gateway={gateway}\\nDNS=8.8.8.8\\nDNS=8.8.4.4\\n"
            )
            await _exec("mkdir -p /etc/systemd/network")
            await _exec(f"printf '{cfg}' > /etc/systemd/network/10-static.network")
            await _exec("systemctl restart systemd-networkd 2>/dev/null || true")

        else:
            # Generic fallback: /etc/network/interfaces
            cfg = (
                f"auto lo\\niface lo inet loopback\\n\\n"
                f"auto {iface}\\niface {iface} inet static\\n"
                f"    address {ip_address}\\n"
                f"    netmask 255.255.255.0\\n"
                f"    gateway {gateway}\\n"
            )
            await _exec(f"printf '{cfg}' > /etc/network/interfaces")
            await _exec(f"ifup {iface} 2>/dev/null || true")

        # ══════════════════════════════════════════════════════════════════
        # METHOD 3 — LXC-level static IP via profile (host-side, most reliable)
        # ══════════════════════════════════════════════════════════════════
        logger.info(f"[ip-cfg] Method 3: LXC host-side config")
        try:
            await execute_lxc(container_name,
                f"config set {container_name} volatile.{iface}.hwaddr ''",
                node_id=node_id, timeout=10)
        except Exception:
            pass

        # ══════════════════════════════════════════════════════════════════
        # Verify IP was applied
        # ══════════════════════════════════════════════════════════════════
        await asyncio.sleep(2)
        try:
            verify = await execute_lxc(container_name,
                f"exec {container_name} -- ip addr show {iface}",
                node_id=node_id, timeout=10)
            if ip_address in str(verify):
                logger.info(f"[ip-cfg] ✓ IP {ip_address} confirmed on {iface}")
            else:
                # Last resort: try again with ip command
                logger.warning(f"[ip-cfg] IP not confirmed, retrying...")
                await _exec(f"ip addr add {ip_address}/24 dev {iface} 2>/dev/null || true")
                await _exec(f"ip link set {iface} up")
        except Exception as e:
            logger.warning(f"[ip-cfg] Could not verify IP: {e}")

        logger.info(f"[ip-cfg] IP configuration complete for {container_name}: {ip_address}")

    except Exception as e:
        logger.error(f"Failed to configure IP for {container_name}: {e}")

async def apply_internal_permissions(container_name: str, node_id: int):
    try:
        await asyncio.sleep(5)

        # Detect OS family
        os_info_lower = ''
        try:
            os_info = await execute_lxc(
                container_name,
                f"exec {container_name} -- cat /etc/os-release",
                node_id=node_id, timeout=15
            )
            os_info_lower = (os_info or '').lower()
        except Exception:
            pass

        is_alpine   = 'alpine' in os_info_lower
        is_debian   = 'debian' in os_info_lower or 'ubuntu' in os_info_lower
        is_rhel     = ('rhel' in os_info_lower or 'red hat' in os_info_lower
                       or 'fedora' in os_info_lower or 'rocky' in os_info_lower
                       or 'alma' in os_info_lower or 'centos' in os_info_lower)
        is_opensuse = 'suse' in os_info_lower or 'opensuse' in os_info_lower
        is_arch     = 'arch' in os_info_lower or 'manjaro' in os_info_lower

        sysctl_cmds = [
            "mkdir -p /etc/sysctl.d/",
            "printf 'net.ipv4.ip_unprivileged_port_start=0\\nnet.ipv4.ping_group_range=0 2147483647\\nfs.inotify.max_user_watches=524288\\nkernel.unprivileged_userns_clone=1\\n' > /etc/sysctl.d/99-avm.conf",
            "sysctl -p /etc/sysctl.d/99-avm.conf 2>/dev/null || true",
        ]

        if is_alpine:
            pkg_cmds = [
                "apk update -q 2>/dev/null || true",
                "apk add --no-cache curl wget net-tools htop 2>/dev/null || true",
            ]
        elif is_debian:
            pkg_cmds = [
                "DEBIAN_FRONTEND=noninteractive apt-get update -qq 2>/dev/null || true",
                "DEBIAN_FRONTEND=noninteractive apt-get install -y -qq curl wget net-tools htop iproute2 2>/dev/null || true",
            ]
        elif is_rhel:
            # dnf (Fedora 22+, RHEL 8+, Rocky 8+, Alma 8+, CentOS 8+)
            pkg_cmds = [
                "dnf -y install curl wget net-tools htop iproute 2>/dev/null || true",
            ]
        elif is_opensuse:
            # zypper (openSUSE Leap / Tumbleweed)
            pkg_cmds = [
                "zypper --non-interactive refresh 2>/dev/null || true",
                "zypper --non-interactive install curl wget net-tools htop iproute2 2>/dev/null || true",
            ]
        elif is_arch:
            # pacman (Arch Linux)
            pkg_cmds = [
                "pacman -Syu --noconfirm --needed curl wget net-tools htop iproute2 2>/dev/null || true",
            ]
        else:
            pkg_cmds = []

        for cmd in sysctl_cmds + pkg_cmds:
            try:
                await execute_lxc(
                    container_name,
                    f"exec {container_name} -- sh -c \"{cmd}\"",
                    node_id=node_id, timeout=120
                )
            except Exception as cmd_err:
                logger.debug(f"apply_internal_permissions cmd skipped ({container_name}): {cmd[:60]} — {cmd_err}")

        logger.info(f"Internal permissions applied to {container_name}")
    except Exception as e:
        logger.error(f"Failed to apply internal permissions to {container_name}: {e}")

async def configure_ssh_and_root_password(container_name: str, node_id: int):
    """Configure SSH and set root password — works on Ubuntu, Debian, Alpine, RHEL, openSUSE, Arch."""
    try:
        # Give the container more time to fully boot
        await asyncio.sleep(5)

        # ── Detect OS family ─────────────────────────────────────────────
        os_info_lower = ''
        try:
            os_info = await execute_lxc(
                container_name,
                f"exec {container_name} -- cat /etc/os-release",
                node_id=node_id, timeout=15
            )
            os_info_lower = (os_info or '').lower()
        except Exception:
            pass

        is_alpine   = 'alpine'   in os_info_lower
        is_debian   = 'debian'   in os_info_lower or 'ubuntu' in os_info_lower
        is_rhel     = ('rhel' in os_info_lower or 'red hat' in os_info_lower
                       or 'fedora' in os_info_lower or 'rocky' in os_info_lower
                       or 'alma' in os_info_lower or 'centos' in os_info_lower)
        is_opensuse = 'suse'     in os_info_lower or 'opensuse' in os_info_lower
        is_arch     = 'arch'     in os_info_lower or 'manjaro' in os_info_lower

        # ── Install OpenSSH ───────────────────────────────────────────────
        try:
            if is_alpine:
                await execute_lxc(
                    container_name,
                    f"exec {container_name} -- apk add --no-cache openssh",
                    node_id=node_id, timeout=120
                )
            elif is_debian:
                # Ubuntu/Debian: update first, then install
                await execute_lxc(
                    container_name,
                    f"exec {container_name} -- sh -c 'DEBIAN_FRONTEND=noninteractive apt-get update -qq 2>&1 | tail -3'",
                    node_id=node_id, timeout=120
                )
                await execute_lxc(
                    container_name,
                    f"exec {container_name} -- sh -c 'DEBIAN_FRONTEND=noninteractive apt-get install -y -qq openssh-server 2>&1 | tail -5'",
                    node_id=node_id, timeout=120
                )
            elif is_rhel:
                # Fedora / RHEL / Rocky / AlmaLinux / CentOS — dnf
                await execute_lxc(
                    container_name,
                    f"exec {container_name} -- dnf -y install openssh-server openssh-clients 2>&1 | tail -10",
                    node_id=node_id, timeout=180
                )
            elif is_opensuse:
                # openSUSE Leap / Tumbleweed — zypper
                await execute_lxc(
                    container_name,
                    f"exec {container_name} -- sh -c 'zypper --non-interactive refresh 2>&1 | tail -3; zypper --non-interactive install openssh 2>&1 | tail -5'",
                    node_id=node_id, timeout=180
                )
            elif is_arch:
                # Arch Linux — pacman
                await execute_lxc(
                    container_name,
                    f"exec {container_name} -- pacman -Syu --noconfirm --needed openssh 2>&1 | tail -10",
                    node_id=node_id, timeout=240
                )
        except Exception as e:
            logger.warning(f"SSH install warning for {container_name}: {e}")

        # ── Detect SFTP subsystem path ────────────────────────────────────
        sftp_path = '/usr/lib/openssh/sftp-server'
        try:
            sftp_check = await execute_lxc(
                container_name,
                f"exec {container_name} -- sh -c 'which sftp-server 2>/dev/null || find /usr -name sftp-server 2>/dev/null | head -1'",
                node_id=node_id, timeout=10
            )
            if sftp_check and isinstance(sftp_check, str) and sftp_check.strip():
                sftp_path = sftp_check.strip().splitlines()[0]
        except Exception:
            pass

        # ── Write SSH config using printf (avoids heredoc quoting issues) ─
        ssh_config_lines = [
            'PasswordAuthentication yes',
            'PermitRootLogin yes',
            'PubkeyAuthentication yes',
            'ChallengeResponseAuthentication no',
            'UsePAM yes',
            'X11Forwarding yes',
            'PrintMotd no',
            'AcceptEnv LANG LC_*',
            f'Subsystem sftp {sftp_path}',
        ]
        # Build a printf command that writes each line safely
        printf_args = '\\n'.join(ssh_config_lines) + '\\n'
        write_cmd = f"printf '{printf_args}' > /etc/ssh/sshd_config"
        try:
            await execute_lxc(
                container_name,
                f"exec {container_name} -- sh -c \"{write_cmd}\"",
                node_id=node_id, timeout=15
            )
            logger.info(f"SSH config written for {container_name}")
        except Exception as e:
            logger.warning(f"SSH config write failed for {container_name}: {e}")

        # ── Ensure SSH host keys exist ────────────────────────────────────
        try:
            await execute_lxc(
                container_name,
                f"exec {container_name} -- sh -c 'ssh-keygen -A 2>/dev/null || true'",
                node_id=node_id, timeout=30
            )
        except Exception:
            pass

        # ── Create /run/sshd directory (required by newer OpenSSH) ────────
        try:
            await execute_lxc(
                container_name,
                f"exec {container_name} -- sh -c 'mkdir -p /run/sshd && chmod 755 /run/sshd'",
                node_id=node_id, timeout=10
            )
        except Exception:
            pass

        # ── Enable & start SSH service ────────────────────────────────────
        ssh_started = False
        if is_alpine:
            try:
                await execute_lxc(container_name, f"exec {container_name} -- rc-update add sshd default", node_id=node_id, timeout=10)
                await execute_lxc(container_name, f"exec {container_name} -- rc-service sshd start", node_id=node_id, timeout=20)
                ssh_started = True
            except Exception as e:
                logger.warning(f"Alpine SSH start failed: {e}")
        elif is_arch:
            # Arch: sshd.service (systemd); generate host keys first
            try:
                await execute_lxc(container_name, f"exec {container_name} -- ssh-keygen -A 2>/dev/null || true", node_id=node_id, timeout=30)
                await execute_lxc(container_name, f"exec {container_name} -- systemctl enable sshd.service 2>/dev/null || true", node_id=node_id, timeout=15)
                await execute_lxc(container_name, f"exec {container_name} -- systemctl restart sshd.service 2>/dev/null || true", node_id=node_id, timeout=20)
                ssh_started = True
                logger.info(f"Arch SSH service 'sshd.service' started for {container_name}")
            except Exception as e:
                logger.warning(f"Arch SSH start failed: {e}")
        else:
            # All systemd-based distros: Ubuntu 16+, Debian 8+, RHEL 7+, Fedora, Rocky, Alma, CentOS, openSUSE
            for svc_name in ('sshd', 'ssh', 'openssh-server'):
                try:
                    await execute_lxc(
                        container_name,
                        f"exec {container_name} -- sh -c 'systemctl enable {svc_name} 2>/dev/null && systemctl restart {svc_name} 2>/dev/null'",
                        node_id=node_id, timeout=20
                    )
                    ssh_started = True
                    logger.info(f"SSH service '{svc_name}' started via systemctl for {container_name}")
                    break
                except Exception:
                    continue

            if not ssh_started:
                # Fallback: start sshd directly
                try:
                    await execute_lxc(
                        container_name,
                        f"exec {container_name} -- sh -c '/usr/sbin/sshd -D &'",
                        node_id=node_id, timeout=10
                    )
                    ssh_started = True
                    logger.info(f"SSH started directly for {container_name}")
                except Exception as e:
                    logger.warning(f"Direct sshd start failed for {container_name}: {e}")

        # ── Set root password ─────────────────────────────────────────────
        try:
            await execute_lxc(
                container_name,
                f"exec {container_name} -- sh -c \"echo 'root:root' | chpasswd\"",
                node_id=node_id, timeout=15
            )
            logger.info(f"Root password set for {container_name}")
        except Exception as e:
            logger.error(f"Failed to set root password for {container_name}: {e}")

        logger.info(f"SSH configured for {container_name} (alpine={is_alpine}, debian={is_debian}, rhel={is_rhel}, opensuse={is_opensuse}, arch={is_arch}, ssh_started={ssh_started})")

    except Exception as e:
        logger.error(f"configure_ssh_and_root_password failed for {container_name}: {e}")

# ============================================================================
# Database helper functions
# ============================================================================
def get_nodes() -> List[Dict]:
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT * FROM nodes ORDER BY name')
        rows = cur.fetchall()
        nodes = []
        for row in rows:
            node = dict(row)
            try:
                node['tags'] = json.loads(node['tags']) if node['tags'] else []
            except:
                node['tags'] = []
            try:
                node['ip_addresses'] = json.loads(node['ip_addresses']) if node['ip_addresses'] else []
            except:
                node['ip_addresses'] = []
            try:
                node['ip_aliases'] = json.loads(node['ip_aliases']) if node['ip_aliases'] else []
            except:
                node['ip_aliases'] = []
            nodes.append(node)
        return nodes

def get_node(node_id: Optional[int]) -> Optional[Dict]:
    if node_id is None:
        return None
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT * FROM nodes WHERE id = ?', (node_id,))
        row = cur.fetchone()
        if row:
            node = dict(row)
            try:
                node['tags'] = json.loads(node['tags']) if node['tags'] else []
            except:
                node['tags'] = []
            try:
                node['ip_addresses'] = json.loads(node['ip_addresses']) if node['ip_addresses'] else []
            except:
                node['ip_addresses'] = []
            try:
                node['ip_aliases'] = json.loads(node['ip_aliases']) if node['ip_aliases'] else []
            except:
                node['ip_aliases'] = []
            return node
    return None

def update_node(node_id: int, **kwargs):
    with get_db() as conn:
        cur = conn.cursor()
        fields = []
        values = []
        for key, value in kwargs.items():
            if key in ['tags', 'ip_addresses', 'ip_aliases'] and isinstance(value, (list, dict)):
                value = json.dumps(value)
            fields.append(f"{key} = ?")
            values.append(value)
        values.append(node_id)
        values.append(datetime.now().isoformat())
        cur.execute(f'UPDATE nodes SET {", ".join(fields)}, updated_at = ? WHERE id = ?', values)
        conn.commit()

def get_current_vps_count(node_id: int) -> int:
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT COUNT(*) FROM vps WHERE node_id = ?', (node_id,))
        count = cur.fetchone()[0]
        return count

def get_vps_for_user(user_id: int) -> List[Dict]:
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT * FROM vps WHERE user_id = ? ORDER BY created_at DESC', (user_id,))
        rows = cur.fetchall()
        vps_list = []
        for row in rows:
            vps = dict(row)
            try:
                vps['shared_with'] = json.loads(vps['shared_with']) if vps['shared_with'] else []
            except:
                vps['shared_with'] = []
            try:
                vps['suspension_history'] = json.loads(vps['suspension_history']) if vps['suspension_history'] else []
            except:
                vps['suspension_history'] = []
            try:
                vps['metadata'] = json.loads(vps['metadata']) if vps['metadata'] else {}
            except:
                vps['metadata'] = {}
            vps['suspended'] = bool(vps['suspended'])
            vps['whitelisted'] = bool(vps['whitelisted'])
            vps_list.append(vps)
        return vps_list

def get_all_vps() -> List[Dict]:
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT * FROM vps ORDER BY created_at DESC')
        rows = cur.fetchall()
        vps_list = []
        for row in rows:
            vps = dict(row)
            try:
                vps['shared_with'] = json.loads(vps['shared_with']) if vps['shared_with'] else []
            except:
                vps['shared_with'] = []
            try:
                vps['suspension_history'] = json.loads(vps['suspension_history']) if vps['suspension_history'] else []
            except:
                vps['suspension_history'] = []
            try:
                vps['metadata'] = json.loads(vps['metadata']) if vps['metadata'] else {}
            except:
                vps['metadata'] = {}
            vps['suspended'] = bool(vps['suspended'])
            vps['whitelisted'] = bool(vps['whitelisted'])
            vps_list.append(vps)
        return vps_list

def get_vps_by_id(vps_id: int) -> Optional[Dict]:
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT * FROM vps WHERE id = ?', (vps_id,))
        row = cur.fetchone()
        if row:
            vps = dict(row)
            try:
                vps['shared_with'] = json.loads(vps['shared_with']) if vps['shared_with'] else []
            except:
                vps['shared_with'] = []
            try:
                vps['suspension_history'] = json.loads(vps['suspension_history']) if vps['suspension_history'] else []
            except:
                vps['suspension_history'] = []
            try:
                vps['metadata'] = json.loads(vps['metadata']) if vps['metadata'] else {}
            except:
                vps['metadata'] = {}
            vps['suspended'] = bool(vps['suspended'])
            vps['whitelisted'] = bool(vps['whitelisted'])
            return vps
    return None

def get_vps_by_container(container_name: str) -> Optional[Dict]:
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT * FROM vps WHERE container_name = ?', (container_name,))
        row = cur.fetchone()
        if row:
            vps = dict(row)
            try:
                vps['shared_with'] = json.loads(vps['shared_with']) if vps['shared_with'] else []
            except:
                vps['shared_with'] = []
            try:
                vps['suspension_history'] = json.loads(vps['suspension_history']) if vps['suspension_history'] else []
            except:
                vps['suspension_history'] = []
            try:
                vps['metadata'] = json.loads(vps['metadata']) if vps['metadata'] else {}
            except:
                vps['metadata'] = {}
            vps['suspended'] = bool(vps['suspended'])
            vps['whitelisted'] = bool(vps['whitelisted'])
            return vps
    return None

def create_vps(user_id: int, node_id: int, container_name: str, ram: str, cpu: str, storage: str,
               config: str, os_version: str, hostname: Optional[str] = None,
               ip_address: Optional[str] = None, ip_alias: Optional[str] = None,
               expiration_days: int = 0, auto_suspend_enabled: bool = False,
               auto_backup_enabled: bool = False) -> int:
    now = datetime.now().isoformat()
    expires_at = None
    
    if auto_suspend_enabled and expiration_days > 0:
        expires_at = (datetime.now() + timedelta(days=expiration_days)).isoformat()
    
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('''INSERT INTO vps
            (user_id, node_id, container_name, hostname, ram, cpu, storage, config, os_version,
             status, created_at, updated_at, ip_address, ip_alias, shared_with, suspension_history, metadata,
             expires_at, expiration_days, auto_suspend_enabled, renewal_count, auto_backup_enabled)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
            (user_id, node_id, container_name, hostname or container_name, ram, cpu, storage, config, os_version,
             'stopped', now, now, ip_address, ip_alias, '[]', '[]', '{}',
             expires_at, expiration_days, 1 if auto_suspend_enabled else 0, 0,
             1 if auto_backup_enabled else 0))
        conn.commit()
        vps_id = cur.lastrowid
        
        cur.execute('UPDATE nodes SET used_vps = (SELECT COUNT(*) FROM vps WHERE node_id = ?) WHERE id = ?',
                   (node_id, node_id))
        conn.commit()
        
        log_activity(user_id, 'create_vps', 'vps', str(vps_id), {'container': container_name})
        
        if auto_suspend_enabled and expiration_days > 0:
            create_notification(user_id, 'success', 'VPS Created', 
                              f'Your VPS {container_name} has been created successfully. It will auto-suspend in {expiration_days} days.')
        else:
            create_notification(user_id, 'success', 'VPS Created', f'Your VPS {container_name} has been created successfully.')
        
        return vps_id

def update_vps(vps_id: int, **kwargs):
    logger.info(f"=== update_vps called for VPS {vps_id} ===")
    logger.info(f"Update parameters: {kwargs}")
    
    with get_db() as conn:
        cur = conn.cursor()
        fields = []
        values = []
        for key, value in kwargs.items():
            if key in ['shared_with', 'suspension_history', 'metadata']:
                json_value = json.dumps(value)
                logger.info(f"Converting {key} to JSON: {value} -> {json_value}")
                value = json_value
            fields.append(f"{key} = ?")
            values.append(value)
        
        values.append(vps_id)
        values.append(datetime.now().isoformat())
        
        sql = f'UPDATE vps SET {", ".join(fields)}, updated_at = ? WHERE id = ?'
        logger.info(f"Executing SQL: {sql}")
        logger.info(f"With values: {values}")
        
        cur.execute(sql, values)
        conn.commit()
        
        logger.info(f"Update committed. Rows affected: {cur.rowcount}")
        
        # Verify the update
        cur.execute('SELECT shared_with FROM vps WHERE id = ?', (vps_id,))
        row = cur.fetchone()
        if row:
            logger.info(f"Verified shared_with in DB: {row[0]}")
        else:
            logger.error(f"VPS {vps_id} not found after update!")

def delete_vps(vps_id: int):
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT container_name, user_id, node_id FROM vps WHERE id = ?', (vps_id,))
        row = cur.fetchone()
        if row:
            container_name, user_id, node_id = row
            cur.execute('DELETE FROM port_forwards WHERE vps_container = ?', (container_name,))
        
        cur.execute('DELETE FROM vps WHERE id = ?', (vps_id,))
        conn.commit()
        
        if node_id:
            cur.execute('UPDATE nodes SET used_vps = (SELECT COUNT(*) FROM vps WHERE node_id = ?) WHERE id = ?',
                       (node_id, node_id))
            conn.commit()
        
        log_activity(user_id, 'delete_vps', 'vps', str(vps_id), {'container': container_name})
        create_notification(user_id, 'info', 'VPS Deleted', f'Your VPS {container_name} has been deleted.')

def find_node_id_for_container(container_name: str) -> int:
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT node_id FROM vps WHERE container_name = ?', (container_name,))
        row = cur.fetchone()
        return row[0] if row else 1

@app.context_processor
def utility_processor():
    # Fetch active theme for server-side injection
    active_theme = None
    try:
        cache    = getattr(app, '_theme_cache', None)
        cache_ts = getattr(app, '_theme_cache_ts', 0.0)
        import time as _t
        if cache is not None and cache_ts > 0 and (_t.time() - cache_ts) < 30.0:
            active_theme = cache.get('theme')
        else:
            with get_db() as conn:
                cur = conn.cursor()
                cur.execute('SELECT * FROM themes WHERE is_active = 1 LIMIT 1')
                row = cur.fetchone()
                active_theme = dict(row) if row else None
            app._theme_cache    = {'success': True, 'theme': active_theme}
            app._theme_cache_ts = _t.time()
    except Exception:
        active_theme = None

    return dict(
        now=datetime.now,
        get_current_vps_count=get_current_vps_count,
        get_setting=get_setting_cached,
        get_unread_notifications_count=get_unread_notifications_count_cached,
        OS_ICONS=OS_ICONS,
        get_os_label=get_os_label,
        get_os_icon_name=get_os_icon_name,
        is_vps_suspended=is_vps_suspended,
        is_vps_whitelisted=is_vps_whitelisted,
        PANEL_VERSION=PANEL_VERSION,
        PANEL_NAME=PANEL_NAME,
        PANEL_DEVELOPER=PANEL_DEVELOPER,
        active_theme=active_theme,
        theme_version=get_setting_cached('theme_version', '0'),
        # Always-available globals so base.html never crashes
        socketio_available=SOCKETIO_AVAILABLE,
        DEBUG_MODE=DEBUG_MODE,
        panel_name=get_setting_cached('site_name', PANEL_NAME),
    )

def is_vps_suspended(vps):
    """Check if VPS is suspended. Handles both boolean and integer values."""
    suspended = vps.get("suspended", 0)
    # Handle both boolean (True/False) and integer (1/0) values
    if isinstance(suspended, bool):
        return suspended
    return int(suspended) == 1

def is_vps_whitelisted(vps):
    """Check if VPS is whitelisted. Handles both boolean and integer values."""
    whitelisted = vps.get("whitelisted", 0)
    # Handle both boolean (True/False) and integer (1/0) values
    if isinstance(whitelisted, bool):
        return whitelisted
    return int(whitelisted) == 1

def get_os_label(os_value):
    """Get OS label from OS value"""
    for os_option in OS_OPTIONS:
        if os_option["value"] == os_value:
            return os_option["label"]
    return os_value

def get_os_icon_name(os_value):
    """Get OS icon name from OS value"""
    for os_option in OS_OPTIONS:
        if os_option["value"] == os_value:
            return os_option.get("icon", "default")
    return "default"

def refresh_vps_status(vps_id):
    """Refresh VPS status from container and update database"""
    vps = get_vps_by_id(vps_id)
    if not vps:
        return None
    
    # If suspended, don't check container status
    if is_vps_suspended(vps):
        return 'suspended'
    
    try:
        status = run_sync(get_container_status(vps['container_name'], vps['node_id']))
        if status != vps['status']:
            update_vps(vps_id, status=status)
        return status
    except Exception as e:
        logger.error(f"Error refreshing VPS {vps_id} status: {e}")
        return vps.get('status', 'unknown')

# ============================================================================
# IP Address and Alias Functions
# ============================================================================
def get_node_display_ip(node_id: int, use_alias: bool = True) -> Optional[str]:
    node = get_node(node_id)
    if not node:
        return None
    
    if use_alias and node['ip_aliases'] and len(node['ip_aliases']) > 0:
        return node['ip_aliases'][0]
    elif node['ip_addresses'] and len(node['ip_addresses']) > 0:
        return node['ip_addresses'][0]
    return None

def get_node_all_ips(node_id: int) -> List[Dict[str, str]]:
    node = get_node(node_id)
    if not node:
        return []
    
    ips = []
    for alias in node.get('ip_aliases', []):
        ips.append({'type': 'alias', 'value': alias})
    
    for ip in node.get('ip_addresses', []):
        ips.append({'type': 'ip', 'value': ip})
    
    return ips

def get_vps_display_ip(vps: Dict) -> Optional[str]:
    if vps.get('ip_alias'):
        return vps['ip_alias']
    return vps.get('ip_address')

def format_ip_for_display(ip: str, port: Optional[int] = None) -> str:
    if port:
        return f"{ip}:{port}"
    return ip

# ============================================================================
# Port forwarding functions
# ============================================================================
def get_user_allocation(user_id: int) -> int:
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT allocated_ports FROM port_allocations WHERE user_id = ?', (user_id,))
        row = cur.fetchone()
        return row[0] if row else 0

def get_user_used_ports(user_id: int) -> int:
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT COUNT(*) FROM port_forwards WHERE user_id = ?', (user_id,))
        row = cur.fetchone()
        return row[0] if row else 0

def allocate_ports(user_id: int, amount: int):
    now = datetime.now().isoformat()
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('''INSERT OR REPLACE INTO port_allocations (user_id, allocated_ports, used_ports, updated_at)
                       VALUES (?, COALESCE((SELECT allocated_ports FROM port_allocations WHERE user_id = ?), 0) + ?, 
                               COALESCE((SELECT used_ports FROM port_allocations WHERE user_id = ?), 0), ?)''',
                    (user_id, user_id, amount, user_id, now))
        conn.commit()

def deallocate_ports(user_id: int, amount: int):
    now = datetime.now().isoformat()
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('''UPDATE port_allocations 
                       SET allocated_ports = GREATEST(0, allocated_ports - ?),
                           updated_at = ?
                       WHERE user_id = ?''',
                    (amount, now, user_id))
        conn.commit()

def get_available_host_port(node_id: int) -> Optional[int]:
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT host_port FROM port_forwards WHERE vps_container IN (SELECT container_name FROM vps WHERE node_id = ?)',
                    (node_id,))
        used_ports = set(row[0] for row in cur.fetchall())
    
    for _ in range(100):
        port = random.randint(20000, 50000)
        if port not in used_ports:
            return port
    return None

async def create_port_forward(user_id: int, container: str, vps_port: int, node_id: int,
                              protocol: str = 'tcp,udp', description: str = '') -> Optional[int]:
    host_port = get_available_host_port(node_id)
    if not host_port:
        return None
    
    try:
        if 'tcp' in protocol:
            await execute_lxc(container, f"config device add {container} tcp_proxy_{host_port} proxy listen=tcp:0.0.0.0:{host_port} connect=tcp:127.0.0.1:{vps_port}", node_id=node_id)
        
        if 'udp' in protocol:
            await execute_lxc(container, f"config device add {container} udp_proxy_{host_port} proxy listen=udp:0.0.0.0:{host_port} connect=udp:127.0.0.1:{vps_port}", node_id=node_id)
        
        now = datetime.now().isoformat()
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('''INSERT INTO port_forwards 
                (user_id, vps_container, vps_port, host_port, protocol, description, created_at, last_used, hits)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                (user_id, container, vps_port, host_port, protocol, description, now, now, 0))
            conn.commit()
            
            cur.execute('UPDATE port_allocations SET used_ports = used_ports + 1, updated_at = ? WHERE user_id = ?',
                       (now, user_id))
            conn.commit()
        
        log_activity(user_id, 'create_port_forward', 'port', str(host_port),
                    {'container': container, 'vps_port': vps_port, 'host_port': host_port, 'protocol': protocol})
        create_notification(user_id, 'success', 'Port Forward Created', 
                          f'Port {vps_port} forwarded to port {host_port} on {container}')
        
        if socketio:
            socketio.emit('port_forward_created', {
                'host_port': host_port,
                'vps_port': vps_port,
                'container': container
            }, room=f'user_{user_id}')
        
        return host_port
    except Exception as e:
        logger.error(f"Failed to create port forward: {e}")
        return None

async def remove_port_forward(forward_id: int) -> Tuple[bool, Optional[int]]:
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT user_id, vps_container, host_port, protocol FROM port_forwards WHERE id = ?', (forward_id,))
        row = cur.fetchone()
        if not row:
            return False, None
        user_id, container, host_port, protocol = row
    
    node_id = find_node_id_for_container(container)
    try:
        if 'tcp' in protocol:
            try:
                await execute_lxc(container, f"config device remove {container} tcp_proxy_{host_port}", node_id=node_id)
            except:
                pass
        
        if 'udp' in protocol:
            try:
                await execute_lxc(container, f"config device remove {container} udp_proxy_{host_port}", node_id=node_id)
            except:
                pass
        
        now = datetime.now().isoformat()
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('DELETE FROM port_forwards WHERE id = ?', (forward_id,))
            conn.commit()
            
            cur.execute('UPDATE port_allocations SET used_ports = used_ports - 1, updated_at = ? WHERE user_id = ?',
                       (now, user_id))
            conn.commit()
        
        log_activity(user_id, 'remove_port_forward', 'port', str(host_port))
        create_notification(user_id, 'info', 'Port Forward Removed', f'Port forward {host_port} has been removed.')
        
        if socketio:
            socketio.emit('port_forward_removed', {
                'host_port': host_port,
                'container': container
            }, room=f'user_{user_id}')
        
        return True, user_id
    except Exception as e:
        logger.error(f"Failed to remove port forward {forward_id}: {e}")
        return False, None

def get_user_forwards(user_id: int) -> List[Dict]:
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT * FROM port_forwards WHERE user_id = ? ORDER BY created_at DESC', (user_id,))
        rows = cur.fetchall()
        return [dict(row) for row in rows]

async def recreate_port_forwards(container_name: str) -> int:
    node_id = find_node_id_for_container(container_name)
    readded_count = 0
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT vps_port, host_port, protocol FROM port_forwards WHERE vps_container = ?', (container_name,))
        rows = cur.fetchall()
    
    for row in rows:
        vps_port, host_port, protocol = row['vps_port'], row['host_port'], row['protocol']
        try:
            if 'tcp' in protocol:
                await execute_lxc(container_name, f"config device add {container_name} tcp_proxy_{host_port} proxy listen=tcp:0.0.0.0:{host_port} connect=tcp:127.0.0.1:{vps_port}", node_id=node_id)
            if 'udp' in protocol:
                await execute_lxc(container_name, f"config device add {container_name} udp_proxy_{host_port} proxy listen=udp:0.0.0.0:{host_port} connect=udp:127.0.0.1:{vps_port}", node_id=node_id)
            logger.info(f"Re-added port forward {host_port}->{vps_port} for {container_name}")
            readded_count += 1
        except Exception as e:
            logger.error(f"Failed to re-add port forward {host_port}->{vps_port} for {container_name}: {e}")
    
    return readded_count

async def update_port_forward_hit(host_port: int):
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('UPDATE port_forwards SET hits = hits + 1, last_used = ? WHERE host_port = ?',
                   (datetime.now().isoformat(), host_port))
        conn.commit()

def relativeTime(dt):
    if not dt:
        return "Never"

    if isinstance(dt, str):
        try:
            dt = datetime.fromisoformat(dt)
        except:
            return "Invalid date"

    now = datetime.now()
    diff = now - dt

    seconds = int(diff.total_seconds())

    if seconds < 60:
        return "just now"
    elif seconds < 3600:
        return f"{seconds // 60} minutes ago"
    elif seconds < 86400:
        return f"{seconds // 3600} hours ago"
    elif seconds < 604800:
        return f"{seconds // 86400} days ago"
    else:
        return dt.strftime("%Y-%m-%d")

# ============================================================================
# Host resource functions
# ============================================================================
def get_host_cpu_usage():
    """Get host CPU usage — non-blocking, uses cached /proc/stat snapshots."""
    try:
        # Method 1: psutil with interval=0 (non-blocking, uses last measurement)
        try:
            import psutil
            cpu_percent = psutil.cpu_percent(interval=0)
            if cpu_percent is not None and cpu_percent >= 0:
                return float(cpu_percent)
        except ImportError:
            pass
        except Exception as e:
            logger.debug(f"psutil CPU method failed: {e}")

        # Method 2: /proc/stat snapshot diff (non-blocking — compare two quick reads)
        try:
            def _read_stat():
                with open('/proc/stat', 'r') as f:
                    vals = [float(x) for x in f.readline().split()[1:8]]
                return vals
            t1 = _read_stat()
            # Tiny sleep — 100ms instead of 500ms
            time.sleep(0.1)
            t2 = _read_stat()
            deltas = [t2[i] - t1[i] for i in range(len(t1))]
            total  = sum(deltas)
            if total > 0:
                return round(max(0.0, min(100.0, 100.0 * (total - deltas[3]) / total)), 2)
        except Exception as e:
            logger.debug(f"/proc/stat method failed: {e}")

        # Method 3: Windows WMIC
        try:
            r = subprocess.run(
                ['wmic', 'cpu', 'get', 'LoadPercentage', '/value'],
                capture_output=True, text=True, timeout=3
            )
            if r.returncode == 0:
                for line in r.stdout.splitlines():
                    if 'LoadPercentage' in line:
                        return float(line.split('=')[1].strip())
        except Exception:
            pass

        return 0.0

    except Exception as e:
        logger.error(f"Error getting CPU usage: {e}")
        return 0.0

def get_host_ram_usage():
    """Get host RAM usage with multiple fallback methods"""
    try:
        # Method 1: Try psutil first (most reliable)
        try:
            import psutil
            mem = psutil.virtual_memory()
            return {
                'total': mem.total // (1024**2),
                'used': mem.used // (1024**2),
                'free': mem.available // (1024**2),
                'percent': float(mem.percent)
            }
        except ImportError:
            pass
        except Exception as e:
            logger.debug(f"psutil RAM method failed: {e}")
        
        # Method 2: Try free command
        try:
            result = subprocess.run(['free', '-m'], capture_output=True, text=True, timeout=3)
            if result.returncode == 0:
                lines = result.stdout.splitlines()
                if len(lines) > 1:
                    mem = lines[1].split()
                    total = int(mem[1])
                    used = int(mem[2])
                    if total > 0:
                        return {
                            'total': total,
                            'used': used,
                            'free': total - used,
                            'percent': float((used / total * 100))
                        }
        except Exception as e:
            logger.debug(f"free command method failed: {e}")
        
        # Method 3: Try /proc/meminfo
        try:
            with open('/proc/meminfo', 'r') as f:
                meminfo = {}
                for line in f:
                    parts = line.split(':')
                    if len(parts) == 2:
                        key = parts[0].strip()
                        value = parts[1].strip().split()[0]
                        meminfo[key] = int(value)
                
                total = meminfo.get('MemTotal', 0) // 1024
                free = meminfo.get('MemFree', 0) // 1024
                buffers = meminfo.get('Buffers', 0) // 1024
                cached = meminfo.get('Cached', 0) // 1024
                
                if total > 0:
                    available = free + buffers + cached
                    used = total - available
                    return {
                        'total': total,
                        'used': used,
                        'free': available,
                        'percent': float((used / total * 100))
                    }
        except Exception as e:
            logger.debug(f"/proc/meminfo method failed: {e}")
        
        logger.warning("All RAM usage methods failed, returning zeros")
        return {'total': 0, 'used': 0, 'free': 0, 'percent': 0.0}
        
    except Exception as e:
        logger.error(f"Error getting RAM usage: {e}")
        return {'total': 0, 'used': 0, 'free': 0, 'percent': 0.0}
    except Exception as e:
        logger.error(f"Error getting RAM usage: {e}")
        return {'total': 0, 'used': 0, 'free': 0, 'percent': 0.0}

def get_host_disk_usage():
    """Get host disk usage with multiple fallback methods"""
    try:
        # Method 1: Try psutil first (most reliable and cross-platform)
        try:
            import psutil
            usage = psutil.disk_usage('/')
            return {
                'total': f"{usage.total / (1024**3):.1f}G",
                'used': f"{usage.used / (1024**3):.1f}G",
                'free': f"{usage.free / (1024**3):.1f}G",
                'percent': f"{usage.percent:.0f}%"
            }
        except ImportError:
            pass
        except Exception as e:
            logger.debug(f"psutil disk method failed: {e}")
        
        # Method 2: Try shutil.disk_usage (Python built-in)
        try:
            import shutil
            usage = shutil.disk_usage('/')
            total_gb = usage.total / (1024**3)
            used_gb = usage.used / (1024**3)
            free_gb = usage.free / (1024**3)
            percent = (usage.used / usage.total * 100) if usage.total > 0 else 0
            return {
                'total': f"{total_gb:.1f}G",
                'used': f"{used_gb:.1f}G",
                'free': f"{free_gb:.1f}G",
                'percent': f"{percent:.0f}%"
            }
        except Exception as e:
            logger.debug(f"shutil disk method failed: {e}")
        
        # Method 3: Try df command
        try:
            result = subprocess.run(['df', '-h', '/'], capture_output=True, text=True, timeout=3)
            if result.returncode == 0:
                lines = result.stdout.splitlines()
                if len(lines) > 1:
                    parts = lines[1].split()
                    if len(parts) >= 5:
                        return {
                            'total': parts[1],
                            'used': parts[2],
                            'free': parts[3],
                            'percent': parts[4]
                        }
        except Exception as e:
            logger.debug(f"df command method failed: {e}")
        
        # Method 4: Try /proc/mounts and statvfs
        try:
            import os
            stat = os.statvfs('/')
            total = stat.f_blocks * stat.f_frsize
            free = stat.f_bavail * stat.f_frsize
            used = total - free
            
            total_gb = total / (1024**3)
            used_gb = used / (1024**3)
            free_gb = free / (1024**3)
            percent = (used / total * 100) if total > 0 else 0
            
            return {
                'total': f"{total_gb:.1f}G",
                'used': f"{used_gb:.1f}G",
                'free': f"{free_gb:.1f}G",
                'percent': f"{percent:.0f}%"
            }
        except Exception as e:
            logger.debug(f"statvfs method failed: {e}")
        
        logger.warning("All disk usage methods failed, returning Unknown")
        return {'total': 'Unknown', 'used': 'Unknown', 'free': 'Unknown', 'percent': 'Unknown'}
        
    except Exception as e:
        logger.error(f"Error getting disk usage: {e}")
        return {'total': 'Unknown', 'used': 'Unknown', 'free': 'Unknown', 'percent': 'Unknown'}

def get_host_uptime():
    # Method 1: Linux /proc/uptime
    try:
        with open('/proc/uptime', 'r') as f:
            uptime_seconds = float(f.readline().split()[0])
            days    = int(uptime_seconds // 86400)
            hours   = int((uptime_seconds % 86400) // 3600)
            minutes = int((uptime_seconds % 3600) // 60)
            return f"{days}d {hours}h {minutes}m"
    except Exception:
        pass

    # Method 2: Windows GetTickCount64
    try:
        import ctypes
        ms = ctypes.windll.kernel32.GetTickCount64()
        s  = ms // 1000
        days    = int(s // 86400)
        hours   = int((s % 86400) // 3600)
        minutes = int((s % 3600) // 60)
        return f"{days}d {hours}h {minutes}m"
    except Exception:
        pass

    # Method 3: uptime command (Linux/macOS)
    try:
        result = subprocess.run(['uptime', '-p'], capture_output=True, text=True, timeout=5)
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip().replace('up ', '')
    except Exception:
        pass

    # Method 4: Windows wmic
    try:
        result = subprocess.run(
            ['wmic', 'os', 'get', 'LastBootUpTime', '/value'],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0:
            for line in result.stdout.splitlines():
                if 'LastBootUpTime' in line:
                    val = line.split('=', 1)[1].strip()
                    # Format: 20240101123456.000000+000
                    boot_str = val[:14]
                    boot_dt  = datetime.strptime(boot_str, '%Y%m%d%H%M%S')
                    delta    = datetime.now() - boot_dt
                    s        = int(delta.total_seconds())
                    days     = s // 86400
                    hours    = (s % 86400) // 3600
                    minutes  = (s % 3600) // 60
                    return f"{days}d {hours}h {minutes}m"
    except Exception:
        pass

    return "N/A"

async def get_host_stats(node_id: int) -> Dict:
    """Get host statistics with improved error handling and caching"""
    node = get_node(node_id)
    if not node:
        logger.warning(f"Node {node_id} not found")
        return {
            "cpu": 0.0, 
            "ram": {'total': 0, 'used': 0, 'free': 0, 'percent': 0.0}, 
            "disk": {'total': 'Unknown', 'used': 'Unknown', 'free': 'Unknown', 'percent': 'Unknown'}, 
            "uptime": "Unknown"
        }
    
    if node['is_local']:
        try:
            stats = {
                "cpu": get_host_cpu_usage(),
                "ram": get_host_ram_usage(),
                "disk": get_host_disk_usage(),
                "uptime": get_host_uptime()
            }
            logger.debug(f"Local node {node_id} stats: CPU={stats['cpu']:.1f}%, RAM={stats['ram']['percent']:.1f}%")
            return stats
        except Exception as e:
            logger.error(f"Error getting local node stats: {e}", exc_info=True)
            return {
                "cpu": 0.0, 
                "ram": {'total': 0, 'used': 0, 'free': 0, 'percent': 0.0}, 
                "disk": {'total': 'Unknown', 'used': 'Unknown', 'free': 'Unknown', 'percent': 'Unknown'}, 
                "uptime": "Unknown"
            }
    else:
        try:
            import requests
            url = f"{node['url']}/api/host/stats"
            headers = {"X-API-Key": node["api_key"]}
            verify_ssl = bool(node.get('verify_ssl', 1))
            
            logger.debug(f"Fetching stats from remote node {node['name']}: {url} (verify_ssl={verify_ssl})")
            response = requests.get(url, headers=headers, timeout=10, verify=verify_ssl)
            response.raise_for_status()
            stats = response.json()
            
            logger.debug(f"Remote node {node['name']} stats received: {stats}")
            
            # Update node info in database
            try:
                with get_db() as conn:
                    cur = conn.cursor()
                    cur.execute('''UPDATE nodes SET 
                                  status = ?, 
                                  last_seen = ?, 
                                  cpu_cores = ?, 
                                  ram_total = ?, 
                                  disk_total = ? 
                                  WHERE id = ?''',
                               ('online', 
                                datetime.now().isoformat(), 
                                stats.get('cpu_cores', 0), 
                                stats.get('ram', {}).get('total', 0),
                                stats.get('disk', {}).get('total_gb', 0), 
                                node_id))
                    conn.commit()
            except Exception as db_err:
                logger.error(f"Failed to update node {node_id} in database: {db_err}")
            
            return stats
            
        except requests.exceptions.Timeout:
            logger.warning(f"Timeout connecting to node {node['name']}")
            mark_node_offline(node_id)
            return {
                "cpu": 0.0, 
                "ram": {'total': 0, 'used': 0, 'free': 0, 'percent': 0.0}, 
                "disk": {'total': 'Unknown', 'used': 'Unknown', 'free': 'Unknown', 'percent': 'Unknown'}, 
                "uptime": "Unknown"
            }
        except requests.exceptions.ConnectionError:
            logger.warning(f"Connection error to node {node['name']}")
            mark_node_offline(node_id)
            return {
                "cpu": 0.0, 
                "ram": {'total': 0, 'used': 0, 'free': 0, 'percent': 0.0}, 
                "disk": {'total': 'Unknown', 'used': 'Unknown', 'free': 'Unknown', 'percent': 'Unknown'}, 
                "uptime": "Unknown"
            }
        except Exception as e:
            logger.error(f"Failed to get host stats from node {node['name']}: {e}", exc_info=True)
            mark_node_offline(node_id)
            return {
                "cpu": 0.0, 
                "ram": {'total': 0, 'used': 0, 'free': 0, 'percent': 0.0}, 
                "disk": {'total': 'Unknown', 'used': 'Unknown', 'free': 'Unknown', 'percent': 'Unknown'}, 
                "uptime": "Unknown"
            }

def mark_node_offline(node_id: int):
    """Helper function to mark a node as offline"""
    try:
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('UPDATE nodes SET status = ?, last_seen = ? WHERE id = ?',
                       ('offline', datetime.now().isoformat(), node_id))
            conn.commit()
    except Exception as e:
        logger.error(f"Failed to mark node {node_id} offline: {e}")

async def get_node_status(node_id: int) -> Dict:
    """Get node status with improved error handling"""
    node = get_node(node_id)
    if not node:
        logger.warning(f"Node {node_id} not found for status check")
        return {"status": "❓ Unknown", "online": False}
    
    if node['is_local']:
        try:
            stats = await get_host_stats(node_id)
            return {
                "status": "🟢 Online (Local)",
                "online": True,
                "local": True,
                "last_seen": datetime.now().isoformat(),
                "stats": stats
            }
        except Exception as e:
            logger.error(f"Error getting local node status: {e}")
            return {
                "status": "⚠️ Error",
                "online": False,
                "local": True,
                "last_seen": datetime.now().isoformat()
            }
    
    try:
        import requests
        headers = {"X-API-Key": node['api_key']}
        verify_ssl = bool(node.get('verify_ssl', 1))
        
        logger.debug(f"Pinging remote node {node['name']}: {node['url']}/api/ping (verify_ssl={verify_ssl})")
        response = requests.get(f"{node['url']}/api/ping", headers=headers, timeout=5, verify=verify_ssl)
        
        if response.status_code == 200:
            data = response.json()
            now = datetime.now().isoformat()
            
            try:
                with get_db() as conn:
                    cur = conn.cursor()
                    cur.execute('UPDATE nodes SET status = ?, last_seen = ? WHERE id = ?',
                               ('online', now, node_id))
                    conn.commit()
            except Exception as db_err:
                logger.error(f"Failed to update node {node_id} status in database: {db_err}")
            
            stats = await get_host_stats(node_id)
            return {
                "status": "🟢 Online",
                "online": True,
                "local": False,
                "last_seen": now,
                "stats": stats,
                "ping_time": data.get('time')
            }
        else:
            logger.warning(f"Node {node['name']} returned status {response.status_code}")
            mark_node_offline(node_id)
            return {
                "status": "🔴 Offline",
                "online": False,
                "local": False,
                "last_seen": node.get('last_seen')
            }
            
    except requests.exceptions.Timeout:
        logger.warning(f"Timeout pinging node {node['name']}")
        mark_node_offline(node_id)
        return {
            "status": "⏱️ Timeout",
            "online": False,
            "local": False,
            "last_seen": node.get('last_seen')
        }
    except requests.exceptions.ConnectionError:
        logger.warning(f"Connection error to node {node['name']}")
        mark_node_offline(node_id)
        return {
            "status": "🔴 Offline",
            "online": False,
            "local": False,
            "last_seen": node.get('last_seen')
        }
    except Exception as e:
        logger.error(f"Failed to ping node {node['name']}: {e}", exc_info=True)
        mark_node_offline(node_id)
        return {
            "status": "❌ Error",
            "online": False,
            "local": False,
            "last_seen": node.get('last_seen'),
            "error": str(e)
        }

# ============================================================================
# Container stats functions
# ============================================================================
async def get_container_status(container_name: str, node_id: Optional[int] = None) -> str:
    """Get container status with improved error handling"""
    if node_id is None:
        node_id = find_node_id_for_container(container_name)
    
    try:
        result = await execute_lxc(container_name, f"info {container_name}", node_id=node_id, timeout=5)
        for line in result.split('\n'):
            if line.startswith("Status: "):
                status = line.split(": ", 1)[1].strip().lower()
                logger.debug(f"Container {container_name} status: {status}")
                return status
        logger.warning(f"Status line not found for container {container_name}")
        return "unknown"
    except Exception as e:
        logger.error(f"Error getting status for {container_name}: {e}")
        return "unknown"

async def get_container_stats(container_name: str, node_id: Optional[int] = None) -> Dict:
    """Get container statistics with improved error handling and data transformation"""
    if node_id is None:
        node_id = find_node_id_for_container(container_name)
    
    node = get_node(node_id)
    if not node:
        logger.warning(f"Node {node_id} not found for container {container_name}")
        return {
            "status": "unknown", 
            "cpu": 0.0, 
            "ram": {"used": 0, "total": 0, "pct": 0.0}, 
            "disk": {"use_percent": "0%"}, 
            "uptime": "Unknown"
        }
    
    if node['is_local']:
        try:
            status = await get_container_status(container_name, node_id)
            
            # Only get detailed stats if container is running
            if status == "running":
                cpu = await get_container_cpu_pct_local(container_name, node_id)
                ram = await get_container_ram_local(container_name, node_id)
                disk = await get_container_disk_local(container_name, node_id)
                uptime = await get_container_uptime_local(container_name, node_id)
                processes = await get_container_processes_local(container_name, node_id)
                network = await get_container_network_local(container_name, node_id)
            else:
                cpu = 0.0
                ram = {"used": 0, "total": 0, "pct": 0.0}
                disk = {"use_percent": "0%"}
                uptime = "Stopped"
                processes = 0
                network = {}
            
            return {
                "status": status,
                "cpu": cpu,
                "ram": ram,
                "disk": disk,
                "uptime": uptime,
                "processes": processes,
                "network": network
            }
        except Exception as e:
            logger.error(f"Error getting local container stats for {container_name}: {e}", exc_info=True)
            return {
                "status": "unknown", 
                "cpu": 0.0, 
                "ram": {"used": 0, "total": 0, "pct": 0.0}, 
                "disk": {"use_percent": "0%"}, 
                "uptime": "Unknown"
            }
    else:
        try:
            import requests
            url = f"{node['url']}/api/container/stats"
            data = {"container": container_name}
            headers = {"X-API-Key": node["api_key"]}
            verify_ssl = bool(node.get('verify_ssl', 1))
            
            logger.debug(f"Fetching container stats from {node['name']}: {url} (verify_ssl={verify_ssl})")
            response = requests.post(url, json=data, headers=headers, timeout=10, verify=verify_ssl)
            response.raise_for_status()
            stats = response.json()
            
            # Transform the response to match expected format
            # Node agent returns 'percent' but we need 'pct' for consistency
            ram_data = stats.get("ram", {"used": 0, "total": 0, "percent": 0.0})
            if isinstance(ram_data, dict):
                if "percent" in ram_data and "pct" not in ram_data:
                    ram_data["pct"] = ram_data["percent"]
                if "pct" not in ram_data:
                    ram_data["pct"] = 0.0
            else:
                ram_data = {"used": 0, "total": 0, "pct": 0.0}
            
            # Transform disk data - node returns string like "2G/10G (20%)"
            # We need dict with use_percent field
            disk_data = stats.get("disk", "Unknown")
            if isinstance(disk_data, str):
                if disk_data in ["Unknown", "Stopped", "N/A"]:
                    disk_data = {
                        "size": "Unknown",
                        "used": "Unknown",
                        "available": "Unknown",
                        "use_percent": "0%"
                    }
                else:
                    # Parse format like "2G/10G (20%)"
                    import re
                    match = re.match(r'(.+?)/(.+?)\s*\((.+?)\)', disk_data)
                    if match:
                        used, total, percent = match.groups()
                        disk_data = {
                            "size": total.strip(),
                            "used": used.strip(),
                            "available": "Unknown",
                            "use_percent": percent.strip()
                        }
                    else:
                        disk_data = {
                            "size": "Unknown",
                            "used": "Unknown",
                            "available": "Unknown",
                            "use_percent": "0%"
                        }
            elif not isinstance(disk_data, dict):
                disk_data = {"use_percent": "0%"}
            
            # Ensure use_percent exists
            if "use_percent" not in disk_data:
                disk_data["use_percent"] = "0%"
            
            return {
                "status": stats.get("status", "unknown"),
                "cpu": float(stats.get("cpu", 0.0)),
                "ram": ram_data,
                "disk": disk_data,
                "uptime": stats.get("uptime", "Unknown"),
                "processes": stats.get("processes", 0),
                "network": stats.get("network", {})
            }
            
        except requests.exceptions.Timeout:
            logger.warning(f"Timeout getting container stats from node {node['name']}")
            return {
                "status": "unknown", 
                "cpu": 0.0, 
                "ram": {"used": 0, "total": 0, "pct": 0.0}, 
                "disk": {"use_percent": "0%"}, 
                "uptime": "Unknown"
            }
        except requests.exceptions.ConnectionError:
            logger.warning(f"Connection error getting container stats from node {node['name']}")
            return {
                "status": "unknown", 
                "cpu": 0.0, 
                "ram": {"used": 0, "total": 0, "pct": 0.0}, 
                "disk": {"use_percent": "0%"}, 
                "uptime": "Unknown"
            }
        except Exception as e:
            logger.error(f"Failed to get container stats from node {node['name']}: {e}", exc_info=True)
            return {
                "status": "unknown", 
                "cpu": 0.0, 
                "ram": {"used": 0, "total": 0, "pct": 0.0}, 
                "disk": {"use_percent": "0%"}, 
                "uptime": "Unknown"
            }

async def get_container_cpu_pct_local(container_name: str, node_id: int) -> float:
    """Get container CPU usage - simplified and reliable method"""
    try:
        # Method 1: Simple sh script with /proc/stat sampling (most compatible)
        simple_script = r"""sh -c '
cat /proc/stat | grep "^cpu " > /tmp/cpu1
sleep 1
cat /proc/stat | grep "^cpu " > /tmp/cpu2
awk "{
    getline < \"/tmp/cpu1\"
    u1=\$2; n1=\$3; s1=\$4; i1=\$5
    getline < \"/tmp/cpu2\"
    u2=\$2; n2=\$3; s2=\$4; i2=\$5
    total=(u2-u1)+(n2-n1)+(s2-s1)+(i2-i1)
    used=(u2-u1)+(n2-n1)+(s2-s1)
    if(total>0) print (used*100)/total; else print 0
}" /tmp/cpu2
rm -f /tmp/cpu1 /tmp/cpu2
'"""
        try:
            result = await execute_lxc(container_name, f"exec {container_name} -- {simple_script}", node_id=node_id)
            cpu_pct = float(result.strip())
            if 0 <= cpu_pct <= 100:
                logger.debug(f"CPU for {container_name}: {cpu_pct}%")
                return round(cpu_pct, 2)
        except Exception as e:
            logger.debug(f"Simple sh script failed for {container_name}: {e}")
        
        # Method 2: Even simpler - just use top with proper parsing
        try:
            result = await execute_lxc(container_name, f"exec {container_name} -- sh -c 'top -bn1 | grep \"Cpu(s)\"'", node_id=node_id)
            if result:
                # Parse output like: %Cpu(s):  2.3 us,  1.2 sy,  0.0 ni, 96.5 id
                import re
                # Look for idle percentage
                idle_match = re.search(r'(\d+\.?\d*)\s*id', result)
                if idle_match:
                    idle = float(idle_match.group(1))
                    cpu_pct = 100.0 - idle
                    logger.debug(f"CPU for {container_name} (top): {cpu_pct}%")
                    return round(cpu_pct, 2)
        except Exception as e:
            logger.debug(f"Top method failed for {container_name}: {e}")
        
        # Method 3: Use vmstat if available
        try:
            result = await execute_lxc(container_name, f"exec {container_name} -- sh -c 'vmstat 1 2 | tail -1'", node_id=node_id)
            if result:
                parts = result.split()
                if len(parts) >= 15:
                    # vmstat output: idle is usually column 15 (0-indexed: 14)
                    idle = float(parts[14])
                    cpu_pct = 100.0 - idle
                    logger.debug(f"CPU for {container_name} (vmstat): {cpu_pct}%")
                    return round(cpu_pct, 2)
        except Exception as e:
            logger.debug(f"vmstat method failed for {container_name}: {e}")
        
        # Method 4: Direct /proc/stat read with inline calculation
        try:
            result = await execute_lxc(container_name, 
                f"exec {container_name} -- sh -c 'grep \"^cpu \" /proc/stat && sleep 1 && grep \"^cpu \" /proc/stat'", 
                node_id=node_id)
            
            lines = [line for line in result.split('\n') if line.startswith('cpu ')]
            if len(lines) >= 2:
                # Parse first reading
                fields1 = [int(x) for x in lines[0].split()[1:8]]
                total1 = sum(fields1)
                idle1 = fields1[3]
                
                # Parse second reading
                fields2 = [int(x) for x in lines[1].split()[1:8]]
                total2 = sum(fields2)
                idle2 = fields2[3]
                
                # Calculate delta
                total_delta = total2 - total1
                idle_delta = idle2 - idle1
                
                if total_delta > 0:
                    cpu_pct = 100.0 * (total_delta - idle_delta) / total_delta
                    logger.debug(f"CPU for {container_name} (/proc/stat): {cpu_pct}%")
                    return round(cpu_pct, 2)
        except Exception as e:
            logger.debug(f"/proc/stat method failed for {container_name}: {e}")
        
        logger.warning(f"All CPU detection methods failed for {container_name}, returning 0")
        return 0.0
        
    except Exception as e:
        logger.error(f"Error getting CPU for {container_name}: {e}")
        return 0.0
        logger.error(f"Error getting CPU for {container_name}: {e}")
        return 0.0

async def get_container_ram_local(container_name: str, node_id: int) -> Dict:
    try:
        result = await execute_lxc(container_name, f"exec {container_name} -- free -m", node_id=node_id)
        lines = result.split('\n')
        if len(lines) > 1:
            parts = lines[1].split()
            total = int(parts[1])
            used = int(parts[2])
            free = int(parts[3])
            pct = (used / total * 100) if total > 0 else 0.0
            return {'used': used, 'total': total, 'free': free, 'pct': pct}
        return {'used': 0, 'total': 0, 'free': 0, 'pct': 0.0}
    except Exception as e:
        logger.error(f"Error getting RAM for {container_name}: {e}")
        return {'used': 0, 'total': 0, 'free': 0, 'pct': 0.0}

async def get_container_disk_local(container_name: str, node_id: int) -> Dict:
    try:
        result = await execute_lxc(
            container_name,
            f"exec {container_name} -- df -h /",
            node_id=node_id
        )

        lines = result.strip().split("\n")
        
        # Parse the output (skip header)
        if len(lines) >= 2:
            # Get the data line (could be line 1 or 2 depending on format)
            for line in lines[1:]:
                parts = line.split()
                
                if len(parts) >= 6:
                    filesystem, size, used, avail, usep, mount = parts[:6]
                    
                    return {
                        "filesystem": filesystem,
                        "size": size,
                        "used": used,
                        "available": avail,
                        "use_percent": usep,
                        "mounted": mount,
                    }
                elif len(parts) >= 5:
                    # Sometimes mount point might be missing or format is different
                    size, used, avail, usep = parts[0], parts[1], parts[2], parts[3]
                    
                    return {
                        "filesystem": "rootfs",
                        "size": size,
                        "used": used,
                        "available": avail,
                        "use_percent": usep,
                        "mounted": "/",
                    }

        # Fallback: try df -hP for POSIX format
        try:
            result = await execute_lxc(
                container_name,
                f"exec {container_name} -- df -hP /",
                node_id=node_id
            )
            
            lines = result.strip().split("\n")
            if len(lines) >= 2:
                parts = lines[1].split()
                if len(parts) >= 5:
                    return {
                        "filesystem": parts[0],
                        "size": parts[1],
                        "used": parts[2],
                        "available": parts[3],
                        "use_percent": parts[4],
                        "mounted": parts[5] if len(parts) > 5 else "/",
                    }
        except Exception as e:
            logger.debug(f"df -hP fallback failed for {container_name}: {e}")

        return {
            "size": "Unknown",
            "used": "Unknown",
            "available": "Unknown",
            "use_percent": "0%"
        }

    except Exception as e:
        logger.error(f"Error getting disk for {container_name}: {e}")
        return {
            "size": "Unknown",
            "used": "Unknown",
            "available": "Unknown",
            "use_percent": "0%"
        }

async def get_container_uptime_local(container_name: str, node_id: int) -> str:
    """Get container uptime with improved parsing"""
    try:
        result = await execute_lxc(container_name, f"exec {container_name} -- uptime -p", node_id=node_id, timeout=3)
        if result and result.strip():
            return result.strip()
    except Exception as e:
        logger.debug(f"uptime -p failed for {container_name}: {e}")
    
    # Fallback to regular uptime
    try:
        result = await execute_lxc(container_name, f"exec {container_name} -- uptime", node_id=node_id, timeout=3)
        if result and result.strip():
            return result.strip()
    except Exception as e:
        logger.debug(f"uptime failed for {container_name}: {e}")
    
    # Fallback to /proc/uptime
    try:
        result = await execute_lxc(container_name, f"exec {container_name} -- cat /proc/uptime", node_id=node_id, timeout=3)
        if result:
            uptime_seconds = float(result.split()[0])
            days = int(uptime_seconds // 86400)
            hours = int((uptime_seconds % 86400) // 3600)
            minutes = int((uptime_seconds % 3600) // 60)
            
            parts = []
            if days > 0:
                parts.append(f"{days}d")
            if hours > 0:
                parts.append(f"{hours}h")
            if minutes > 0 or not parts:
                parts.append(f"{minutes}m")
            
            return " ".join(parts)
    except Exception as e:
        logger.debug(f"/proc/uptime failed for {container_name}: {e}")
    
    logger.warning(f"All uptime methods failed for {container_name}")
    return "Unknown"

async def get_container_processes_local(container_name: str, node_id: int) -> int:
    """Get container process count with improved error handling"""
    try:
        # Method 1: ps aux | wc -l
        result = await execute_lxc(container_name, f"exec {container_name} -- sh -c 'ps aux | wc -l'", node_id=node_id, timeout=3)
        if result and result.strip().isdigit():
            # Subtract 1 for header line
            count = int(result.strip()) - 1
            return max(0, count)
    except Exception as e:
        logger.debug(f"ps aux method failed for {container_name}: {e}")
    
    # Method 2: ps -e | wc -l
    try:
        result = await execute_lxc(container_name, f"exec {container_name} -- sh -c 'ps -e | wc -l'", node_id=node_id, timeout=3)
        if result and result.strip().isdigit():
            count = int(result.strip()) - 1
            return max(0, count)
    except Exception as e:
        logger.debug(f"ps -e method failed for {container_name}: {e}")
    
    # Method 3: Count /proc directories
    try:
        result = await execute_lxc(container_name, f"exec {container_name} -- sh -c 'ls -d /proc/[0-9]* | wc -l'", node_id=node_id, timeout=3)
        if result and result.strip().isdigit():
            return int(result.strip())
    except Exception as e:
        logger.debug(f"/proc count method failed for {container_name}: {e}")
    
    logger.warning(f"All process count methods failed for {container_name}")
    return 0

async def get_container_network_local(container_name: str, node_id: int) -> Dict:
    """Get container network information with improved parsing"""
    ips = []
    
    try:
        # Method 1: ip addr show
        result = await execute_lxc(container_name, f"exec {container_name} -- ip addr show", node_id=node_id, timeout=3)
        if result:
            for line in result.split('\n'):
                if 'inet ' in line and '127.0.0.1' not in line:
                    parts = line.strip().split()
                    if len(parts) >= 2:
                        ip = parts[1].split('/')[0]
                        if ip not in ips:
                            ips.append(ip)
    except Exception as e:
        logger.debug(f"ip addr method failed for {container_name}: {e}")
    
    # Method 2: hostname -I (fallback)
    if not ips:
        try:
            result = await execute_lxc(container_name, f"exec {container_name} -- hostname -I", node_id=node_id, timeout=3)
            if result:
                for ip in result.strip().split():
                    if ip and ip != '127.0.0.1' and ip not in ips:
                        ips.append(ip)
        except Exception as e:
            logger.debug(f"hostname -I method failed for {container_name}: {e}")
    
    return {'ips': ips}

async def get_container_private_ip(container_name: str, node_id: int) -> str:
    """Get the private IP address of the container (internal LXC IP)"""
    try:
        # Try to get IP from hostname -I (most reliable)
        result = await execute_lxc(container_name, f"exec {container_name} -- sh -c 'hostname -I'", node_id=node_id)
        if result:
            # Get first IP (usually the private IP)
            ips = result.strip().split()
            if ips:
                return ips[0]
        
        # Fallback: Try ip addr show
        result = await execute_lxc(container_name, f"exec {container_name} -- ip addr show", node_id=node_id)
        if result:
            for line in result.split('\n'):
                if 'inet ' in line and '127.0.0.1' not in line:
                    parts = line.strip().split()
                    if len(parts) >= 2:
                        ip = parts[1].split('/')[0]
                        # Return first non-localhost IP
                        if not ip.startswith('127.'):
                            return ip
        
        return "N/A"
    except Exception as e:
        logger.error(f"Error getting private IP for {container_name}: {e}")
        return "N/A"

# ============================================================================
# Register API Blueprint
# ============================================================================
from api import api_bp
app.register_blueprint(api_bp)
logger.info("API blueprint registered at /api/v1")

# ============================================================================
# Web Routes - Authentication
# ============================================================================
@app.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return render_template('index.html', panel_name=get_setting('site_name', 'AVM PANEL'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username_or_email = request.form.get('username')  # Can be username or email
        password = request.form.get('password')
        remember = request.form.get('remember') == 'on'
        
        # Try to find user by username first, then by email
        user = User.get_by_username(username_or_email)
        if not user:
            user = User.get_by_email(username_or_email)
        
        if user and check_password_hash(user.password_hash, password):
            if user.two_factor_enabled:
                session['2fa_user_id'] = user.id
                return redirect(url_for('two_factor'))
            
            login_user(user, remember=remember)
            now = datetime.now().isoformat()
            with get_db() as conn:
                cur = conn.cursor()
                cur.execute('UPDATE users SET last_login = ?, last_active = ? WHERE id = ?',
                           (now, now, user.id))
                conn.commit()
            
            log_activity(user.id, 'login', 'auth', None, {'ip': request.remote_addr})
            create_notification(user.id, 'info', 'New Login', f'New login from {request.remote_addr}', expires_in=86400)
            flash(f'Welcome back, {user.username}!', 'success')
            
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('dashboard'))
        else:
            flash('Invalid username/email or password', 'danger')
            log_activity(None, 'login_failed', 'auth', None, {'username_or_email': username_or_email, 'ip': request.remote_addr})
    
    return render_template('login.html', panel_name=get_setting('site_name', 'AVM PANEL'))

@app.route('/2fa', methods=['GET', 'POST'])
def two_factor():
    if '2fa_user_id' not in session:
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        code = request.form.get('code')
        user_id = session.pop('2fa_user_id', None)
        user = User.get(user_id)
        if user:
            login_user(user)
            now = datetime.now().isoformat()
            with get_db() as conn:
                cur = conn.cursor()
                cur.execute('UPDATE users SET last_login = ?, last_active = ? WHERE id = ?',
                           (now, now, user.id))
                conn.commit()
            flash(f'Welcome back, {user.username}!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid 2FA code', 'danger')
    
    return render_template('2fa.html', panel_name=get_setting('site_name', 'AVM PANEL'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    registration_enabled = get_setting('registration_enabled', '1')
    if registration_enabled != '1':
        flash('Registration is currently disabled', 'warning')
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        terms = request.form.get('terms') == 'on'
        
        if not terms:
            flash('You must accept the terms of service', 'danger')
            return render_template('register.html', panel_name=get_setting('site_name', 'AVM PANEL'))
        
        if password != confirm_password:
            flash('Passwords do not match', 'danger')
            return render_template('register.html', panel_name=get_setting('site_name', 'AVM PANEL'))
        
        if len(password) < 8:
            flash('Password must be at least 8 characters', 'danger')
            return render_template('register.html', panel_name=get_setting('site_name', 'AVM PANEL'))
        
        if User.get_by_username(username):
            flash('Username already taken', 'danger')
            return render_template('register.html', panel_name=get_setting('site_name', 'AVM PANEL'))
        
        if User.get_by_email(email):
            flash('Email already registered', 'danger')
            return render_template('register.html', panel_name=get_setting('site_name', 'AVM PANEL'))
        
        password_hash = generate_password_hash(password)
        api_key = generate_api_key()
        now = datetime.now().isoformat()
        
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('''INSERT INTO users 
                (username, email, password_hash, is_admin, is_main_admin, created_at, last_login, api_key, preferences)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                (username, email, password_hash, 0, 0, now, now, api_key, '{}'))
            user_id = cur.lastrowid
            
            default_quota = int(get_setting('default_port_quota', '5'))
            cur.execute('INSERT INTO port_allocations (user_id, allocated_ports, used_ports, updated_at) VALUES (?, ?, ?, ?)',
                       (user_id, default_quota, 0, now))
            conn.commit()
        
        log_activity(user_id, 'register', 'auth', None, {'username': username, 'email': email})
        create_notification(user_id, 'success', 'Welcome!', f'Welcome to {get_setting("site_name", "AVM PANEL")}! Your account has been created.')
        flash('Registration successful! Please log in.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html', panel_name=get_setting('site_name', 'AVM PANEL'))

# ============================================================================
# Discord OAuth Authentication
# ============================================================================

@app.route('/auth/discord/login')
def discord_login():
    """Initiate Discord OAuth login"""
    if not get_setting('discord_auth_enabled', '0') == '1':
        flash('Discord authentication is not enabled', 'danger')
        return redirect(url_for('login'))
    
    client_id = get_setting('discord_client_id', '')
    redirect_uri = get_setting('discord_redirect_uri', '')
    
    if not client_id or not redirect_uri:
        flash('Discord authentication is not configured', 'danger')
        return redirect(url_for('login'))
    
    # Generate state for CSRF protection
    state = secrets.token_urlsafe(32)
    session['discord_oauth_state'] = state
    session['discord_oauth_action'] = 'login'
    
    # Build Discord OAuth URL
    params = {
        'client_id': client_id,
        'redirect_uri': redirect_uri,
        'response_type': 'code',
        'scope': 'identify email',
        'state': state
    }
    
    oauth_url = f"https://discord.com/api/oauth2/authorize?{urlencode(params)}"
    return redirect(oauth_url)

@app.route('/auth/discord/register')
def discord_register():
    """Initiate Discord OAuth registration"""
    if not get_setting('discord_auth_enabled', '0') == '1':
        flash('Discord authentication is not enabled', 'danger')
        return redirect(url_for('register'))
    
    if not get_setting('registration_enabled', '1') == '1':
        flash('Registration is currently disabled', 'danger')
        return redirect(url_for('login'))
    
    client_id = get_setting('discord_client_id', '')
    redirect_uri = get_setting('discord_redirect_uri', '')
    
    if not client_id or not redirect_uri:
        flash('Discord authentication is not configured', 'danger')
        return redirect(url_for('register'))
    
    # Generate state for CSRF protection
    state = secrets.token_urlsafe(32)
    session['discord_oauth_state'] = state
    session['discord_oauth_action'] = 'register'
    
    # Build Discord OAuth URL
    params = {
        'client_id': client_id,
        'redirect_uri': redirect_uri,
        'response_type': 'code',
        'scope': 'identify email',
        'state': state
    }
    
    oauth_url = f"https://discord.com/api/oauth2/authorize?{urlencode(params)}"
    return redirect(oauth_url)

@app.route('/auth/discord/callback')
def discord_callback():
    """Handle Discord OAuth callback"""
    # Verify state
    state = request.args.get('state')
    if not state or state != session.get('discord_oauth_state'):
        flash('Invalid OAuth state', 'danger')
        return redirect(url_for('login'))
    
    # Get authorization code
    code = request.args.get('code')
    error = request.args.get('error')
    
    if error:
        flash(f'Discord authorization failed: {error}', 'danger')
        return redirect(url_for('login'))
    
    if not code:
        flash('No authorization code received', 'danger')
        return redirect(url_for('login'))
    
    # Exchange code for access token
    client_id = get_setting('discord_client_id', '')
    client_secret = get_setting('discord_client_secret', '')
    redirect_uri = get_setting('discord_redirect_uri', '')
    
    token_data = {
        'client_id': client_id,
        'client_secret': client_secret,
        'grant_type': 'authorization_code',
        'code': code,
        'redirect_uri': redirect_uri
    }
    
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    
    try:
        token_response = requests.post(
            'https://discord.com/api/oauth2/token',
            data=token_data,
            headers=headers,
            timeout=10
        )
        token_response.raise_for_status()
        token_json = token_response.json()
        access_token = token_json['access_token']
    except Exception as e:
        logger.error(f"Discord token exchange error: {e}")
        flash('Failed to authenticate with Discord', 'danger')
        return redirect(url_for('login'))
    
    # Fetch user info from Discord
    try:
        user_response = requests.get(
            'https://discord.com/api/users/@me',
            headers={'Authorization': f'Bearer {access_token}'},
            timeout=10
        )
        user_response.raise_for_status()
        discord_user = user_response.json()
    except Exception as e:
        logger.error(f"Discord user fetch error: {e}")
        flash('Failed to fetch user information from Discord', 'danger')
        return redirect(url_for('login'))
    
    discord_id = discord_user['id']
    discord_username = f"{discord_user['username']}#{discord_user['discriminator']}" if discord_user.get('discriminator') and discord_user.get('discriminator') != '0' else discord_user['username']
    discord_email = discord_user.get('email')
    discord_avatar = discord_user.get('avatar')
    
    action = session.get('discord_oauth_action', 'login')
    
    # Clean up session
    session.pop('discord_oauth_state', None)
    session.pop('discord_oauth_action', None)
    
    with get_db() as conn:
        cur = conn.cursor()
        
        # Check if Discord ID already exists
        cur.execute('SELECT * FROM users WHERE discord_id = ?', (discord_id,))
        existing_user = cur.fetchone()
        
        if action == 'login':
            if existing_user:
                # Log in existing user
                user = User(dict(existing_user))  # Convert Row to dict
                login_user(user, remember=True)
                
                # Update last login and profile picture from Discord
                profile_picture = None
                if discord_avatar:
                    profile_picture = f"https://cdn.discordapp.com/avatars/{discord_id}/{discord_avatar}.png"
                
                cur.execute('UPDATE users SET last_login = ?, last_active = ?, discord_username = ?, discord_avatar = ?, discord_email = ?, profile_picture = ? WHERE id = ?',
                          (datetime.now().isoformat(), datetime.now().isoformat(), discord_username, discord_avatar, discord_email, profile_picture, user.id))
                conn.commit()
                
                log_activity(user.id, 'login_discord', 'auth', str(user.id))
                flash(f'Welcome back, {user.username}!', 'success')
                return redirect(url_for('dashboard'))
            else:
                # Check if auto-registration is enabled
                if get_setting('discord_auto_register', '0') == '1':
                    # Auto-register new user
                    return discord_auto_register(discord_id, discord_username, discord_email, discord_avatar)
                else:
                    flash('No account found with this Discord account. Please register first.', 'warning')
                    return redirect(url_for('register'))
        
        elif action == 'register':
            if existing_user:
                flash('This Discord account is already registered. Please log in instead.', 'warning')
                return redirect(url_for('login'))
            else:
                # Register new user
                return discord_auto_register(discord_id, discord_username, discord_email, discord_avatar)
        
        elif action == 'link':
            # Link Discord to existing logged-in user
            if not current_user.is_authenticated:
                flash('You must be logged in to link Discord', 'danger')
                return redirect(url_for('login'))
            
            # Check if Discord ID is already linked to another account
            if existing_user and existing_user['id'] != current_user.id:
                flash(f'This Discord account is already linked to another user', 'danger')
                return redirect(url_for('profile'))
            
            # Generate Discord avatar URL
            profile_picture = None
            if discord_avatar:
                profile_picture = f"https://cdn.discordapp.com/avatars/{discord_id}/{discord_avatar}.png"
            
            # Update current user with Discord info
            cur.execute('''UPDATE users 
                SET discord_id = ?, discord_username = ?, discord_avatar = ?, discord_email = ?, profile_picture = ?
                WHERE id = ?''',
                (discord_id, discord_username, discord_avatar, discord_email, profile_picture, current_user.id))
            conn.commit()
            
            flash('Discord account linked successfully!', 'success')
            log_activity(current_user.id, 'link_discord', 'auth', str(current_user.id))
            return redirect(url_for('profile'))
    
    flash('An error occurred during authentication', 'danger')
    return redirect(url_for('login'))

def discord_auto_register(discord_id, discord_username, discord_email, discord_avatar):
    """Auto-register a new user from Discord"""
    try:
        with get_db() as conn:
            cur = conn.cursor()
            
            # Generate username from Discord username
            base_username = discord_username.split('#')[0].lower()
            base_username = re.sub(r'[^a-z0-9_]', '', base_username)
            
            # Ensure unique username
            username = base_username
            counter = 1
            while True:
                cur.execute('SELECT id FROM users WHERE username = ?', (username,))
                if not cur.fetchone():
                    break
                username = f"{base_username}{counter}"
                counter += 1
            
            # Use Discord email or generate placeholder
            email = discord_email if discord_email else f"{username}@discord.local"
            
            # Ensure unique email
            counter = 1
            original_email = email
            while True:
                cur.execute('SELECT id FROM users WHERE email = ?', (email,))
                if not cur.fetchone():
                    break
                email = f"{username}{counter}@discord.local"
                counter += 1
            
            # Generate Discord avatar URL
            profile_picture = None
            if discord_avatar:
                # Discord CDN URL format: https://cdn.discordapp.com/avatars/{user_id}/{avatar_hash}.png
                profile_picture = f"https://cdn.discordapp.com/avatars/{discord_id}/{discord_avatar}.png"
            
            # Generate random password (user won't need it)
            random_password = secrets.token_urlsafe(32)
            password_hash = generate_password_hash(random_password)
            api_key = generate_api_key()
            
            now = datetime.now().isoformat()
            
            # Create user with profile picture
            cur.execute('''INSERT INTO users 
                (username, email, password_hash, is_admin, is_main_admin, created_at, last_login, last_active, api_key, preferences,
                 discord_id, discord_username, discord_avatar, discord_email, profile_picture)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                (username, email, password_hash, 0, 0, now, now, now, api_key, '{}',
                 discord_id, discord_username, discord_avatar, discord_email, profile_picture))
            
            user_id = cur.lastrowid
            
            # Initialize port allocations
            default_quota = int(get_setting('default_port_quota', '5'))
            cur.execute('INSERT INTO port_allocations (user_id, allocated_ports, used_ports, updated_at) VALUES (?, ?, ?, ?)',
                       (user_id, default_quota, 0, now))
            
            conn.commit()
            
            # Log in the new user
            cur.execute('SELECT * FROM users WHERE id = ?', (user_id,))
            user_row = cur.fetchone()
            user = User(dict(user_row))  # Convert Row to dict
            login_user(user, remember=True)
            
            log_activity(user.id, 'register_discord', 'auth', str(user.id))
            create_notification(user.id, 'success', 'Welcome!', f'Welcome to {get_setting("site_name", "AVM Panel")}, {username}! Your account has been created.')
            flash(f'Welcome to {get_setting("site_name", "AVM Panel")}, {username}! Your account has been created.', 'success')
            return redirect(url_for('dashboard'))
            
    except Exception as e:
        logger.error(f"Discord auto-register error: {e}")
        flash('Failed to create account. Please try again.', 'danger')
        return redirect(url_for('register'))

@app.route('/auth/discord/link')
@login_required
def discord_link():
    """Link Discord account to existing user"""
    if not get_setting('discord_auth_enabled', '0') == '1':
        flash('Discord authentication is not enabled', 'danger')
        return redirect(url_for('profile'))
    
    client_id = get_setting('discord_client_id', '')
    redirect_uri = get_setting('discord_redirect_uri', '')
    
    if not client_id or not redirect_uri:
        flash('Discord authentication is not configured', 'danger')
        return redirect(url_for('profile'))
    
    # Generate state for CSRF protection
    state = secrets.token_urlsafe(32)
    session['discord_oauth_state'] = state
    session['discord_oauth_action'] = 'link'
    
    # Build Discord OAuth URL
    params = {
        'client_id': client_id,
        'redirect_uri': redirect_uri,
        'response_type': 'code',
        'scope': 'identify email',
        'state': state
    }
    
    oauth_url = f"https://discord.com/api/oauth2/authorize?{urlencode(params)}"
    return redirect(oauth_url)

@app.route('/auth/discord/link-callback')
@login_required
def discord_link_callback():
    """Handle Discord account linking callback"""
    # Verify state
    state = request.args.get('state')
    if not state or state != session.get('discord_oauth_state'):
        flash('Invalid OAuth state', 'danger')
        return redirect(url_for('profile'))
    
    code = request.args.get('code')
    if not code:
        flash('No authorization code received', 'danger')
        return redirect(url_for('profile'))
    
    # Exchange code for token
    client_id = get_setting('discord_client_id', '')
    client_secret = get_setting('discord_client_secret', '')
    redirect_uri = get_setting('discord_redirect_uri', '').replace('/callback', '/link-callback')
    
    token_data = {
        'client_id': client_id,
        'client_secret': client_secret,
        'grant_type': 'authorization_code',
        'code': code,
        'redirect_uri': redirect_uri
    }
    
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    
    try:
        token_response = requests.post(
            'https://discord.com/api/oauth2/token',
            data=token_data,
            headers=headers,
            timeout=10
        )
        token_response.raise_for_status()
        token_json = token_response.json()
        access_token = token_json['access_token']
        
        # Fetch user info
        user_response = requests.get(
            'https://discord.com/api/users/@me',
            headers={'Authorization': f'Bearer {access_token}'},
            timeout=10
        )
        user_response.raise_for_status()
        discord_user = user_response.json()
        
        discord_id = discord_user['id']
        discord_username = f"{discord_user['username']}#{discord_user['discriminator']}" if discord_user.get('discriminator') and discord_user.get('discriminator') != '0' else discord_user['username']
        discord_email = discord_user.get('email')
        discord_avatar = discord_user.get('avatar')
        
        # Clean up session
        session.pop('discord_oauth_state', None)
        session.pop('discord_oauth_action', None)
        
        # Update current user with Discord info
        with get_db() as conn:
            cur = conn.cursor()
            
            # Check if Discord ID is already linked to another account
            cur.execute('SELECT id, username FROM users WHERE discord_id = ? AND id != ?', (discord_id, current_user.id))
            other_user = cur.fetchone()
            if other_user:
                flash(f'This Discord account is already linked to another user ({other_user[1]})', 'danger')
                return redirect(url_for('profile'))
            
            # Generate Discord avatar URL
            profile_picture = None
            if discord_avatar:
                profile_picture = f"https://cdn.discordapp.com/avatars/{discord_id}/{discord_avatar}.png"
            
            cur.execute('''UPDATE users 
                SET discord_id = ?, discord_username = ?, discord_avatar = ?, discord_email = ?, profile_picture = ?
                WHERE id = ?''',
                (discord_id, discord_username, discord_avatar, discord_email, profile_picture, current_user.id))
            conn.commit()
        
        flash('Discord account linked successfully!', 'success')
        log_activity(current_user.id, 'link_discord', 'auth', str(current_user.id))
        
    except Exception as e:
        logger.error(f"Discord link error: {e}")
        flash('Failed to link Discord account', 'danger')
    
    return redirect(url_for('profile'))

@app.route('/auth/discord/unlink', methods=['POST'])
@login_required
def discord_unlink():
    """Unlink Discord account from user"""
    try:
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('''UPDATE users 
                SET discord_id = NULL, discord_username = NULL, discord_avatar = NULL, discord_email = NULL
                WHERE id = ?''',
                (current_user.id,))
            conn.commit()
        
        flash('Discord account unlinked successfully', 'success')
        log_activity(current_user.id, 'unlink_discord', 'auth', str(current_user.id))
    except Exception as e:
        logger.error(f"Discord unlink error: {e}")
        flash('Failed to unlink Discord account', 'danger')
    
    return redirect(url_for('profile'))

@app.route('/logout')
@login_required
def logout():
    log_activity(current_user.id, 'logout', 'auth')
    logout_user()
    flash('You have been logged out', 'info')
    return redirect(url_for('index'))

@app.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form.get('email')
        flash('If the email exists, a reset link has been sent.', 'info')
        return redirect(url_for('login'))
    
    return render_template('forgot_password.html', panel_name=get_setting('site_name', 'AVM PANEL'))

@app.route('/reset-password/<token>', methods=['GET', 'POST'])
def reset_password(token):
    if request.method == 'POST':
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        if password != confirm_password:
            flash('Passwords do not match', 'danger')
            return render_template('reset_password.html', token=token)
        
        flash('Password reset successful. Please log in.', 'success')
        return redirect(url_for('login'))
    
    return render_template('reset_password.html', token=token, panel_name=get_setting('site_name', 'AVM PANEL'))

# ============================================================================
# Notifications Routes
# ============================================================================
@app.route('/notifications')
@login_required
def notifications():
    page = int(request.args.get('page', 1))
    per_page = 20
    offset = (page - 1) * per_page
    
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('''SELECT * FROM notifications 
                      WHERE user_id = ? AND (expires_at IS NULL OR expires_at > ?)
                      ORDER BY created_at DESC LIMIT ? OFFSET ?''',
                   (current_user.id, datetime.now().isoformat(), per_page, offset))
        notifications = [dict(row) for row in cur.fetchall()]
        
        for notif in notifications:
            if notif['data']:
                try:
                    notif['data'] = json.loads(notif['data'])
                except:
                    notif['data'] = {}
        
        cur.execute('''SELECT COUNT(*) FROM notifications 
                      WHERE user_id = ? AND (expires_at IS NULL OR expires_at > ?)''',
                   (current_user.id, datetime.now().isoformat()))
        total = cur.fetchone()[0]
    
    return render_template('notifications.html',
                          panel_name=get_setting('site_name', 'AVM PANEL'),
                          notifications=notifications,
                          page=page,
                          total_pages=(total + per_page - 1) // per_page)

@app.route('/notifications/unread')
@login_required
def unread_notifications():
    count = get_unread_notifications_count_cached(current_user.id)
    # Only fetch full notification list if count > 0 (saves a query when inbox is empty)
    notifications = get_user_notifications(current_user.id, unread_only=True, limit=10) if count > 0 else []
    from flask import make_response as _mr
    resp = _mr(jsonify({'success': True, 'count': count, 'notifications': notifications}))
    resp.headers['Cache-Control'] = 'private, max-age=10'
    return resp

@app.route('/notifications/mark-read/<int:notification_id>', methods=['POST'])
@login_required
def mark_notification_read_route(notification_id):
    success = mark_notification_read(notification_id, current_user.id)
    return jsonify({'success': success})

@app.route('/notifications/mark-all-read', methods=['POST'])
@login_required
def mark_all_notifications_read_route():
    count = mark_all_notifications_read(current_user.id)
    return jsonify({'success': True, 'count': count})

@app.route('/notifications/delete/<int:notification_id>', methods=['POST'])
@login_required
def delete_notification(notification_id):
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('DELETE FROM notifications WHERE id = ? AND user_id = ?', (notification_id, current_user.id))
        conn.commit()
        deleted = cur.rowcount > 0
    return jsonify({'success': deleted})

@app.route('/notifications/clear-all', methods=['POST'])
@login_required
def clear_all_notifications():
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('DELETE FROM notifications WHERE user_id = ?', (current_user.id,))
        conn.commit()
    return jsonify({'success': True})

# ============================================================================
# OS Icons Routes
# ============================================================================
@app.route('/os-icons')
@login_required
@admin_required
def os_icons():
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT * FROM os_icons ORDER BY os_name')
        icons = [dict(row) for row in cur.fetchall()]
    
    return render_template('admin/os_icons.html',
                          panel_name=get_setting('site_name', 'AVM PANEL'),
                          icons=icons,
                          os_options=OS_OPTIONS)

@app.route('/os-icons/upload', methods=['POST'])
@login_required
@admin_required
def upload_os_icon():
    os_name = request.form.get('os_name')
    
    if 'icon' not in request.files:
        return jsonify({'success': False, 'error': 'No file uploaded'}), 400
    
    file = request.files['icon']
    if file.filename == '':
        return jsonify({'success': False, 'error': 'No file selected'}), 400
    
    if not os_name:
        return jsonify({'success': False, 'error': 'OS name required'}), 400
    
    if not allowed_file(file.filename):
        return jsonify({'success': False, 'error': 'Invalid file type'}), 400
    
    file.seek(0, os.SEEK_END)
    size = file.tell()
    file.seek(0)
    
    if size > app.config['MAX_IMAGE_SIZE']:
        return jsonify({'success': False, 'error': 'File too large (max 5MB)'}), 400
    
    filename = secure_filename(f"os_{os_name}_{int(time.time())}.{file.filename.rsplit('.', 1)[1].lower()}")
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], 'os_icons', filename)
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    file.save(filepath)
    
    if PIL_AVAILABLE and Image:
        try:
            img = Image.open(filepath)
            img.thumbnail((64, 64), Image.Resampling.LANCZOS)
            img.save(filepath, optimize=True, quality=85)
        except Exception as e:
            logger.error(f"Failed to optimize image: {e}")
    
    icon_path = f'/static/uploads/os_icons/{filename}'
    
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('''INSERT OR REPLACE INTO os_icons (os_name, icon_path, uploaded_at, uploaded_by)
                      VALUES (?, ?, ?, ?)''',
                   (os_name, icon_path, datetime.now().isoformat(), current_user.id))
        conn.commit()
    
    log_activity(current_user.id, 'upload_os_icon', 'os_icon', None, {'os_name': os_name})
    return jsonify({'success': True, 'icon_path': icon_path})

@app.route('/os-icons/<path:os_name>/delete', methods=['POST'])
@login_required
@admin_required
def delete_os_icon(os_name):
    """Delete OS icon"""
    try:
        with get_db() as conn:
            cur = conn.cursor()
            
            # Get icon path before deleting
            cur.execute('SELECT icon_path FROM os_icons WHERE os_name = ?', (os_name,))
            row = cur.fetchone()
            
            if row:
                icon_path = row[0]
                
                # Delete from database
                cur.execute('DELETE FROM os_icons WHERE os_name = ?', (os_name,))
                conn.commit()
                
                # Try to delete the file
                try:
                    if icon_path and icon_path.startswith('/static/uploads/'):
                        file_path = icon_path.replace('/static/', 'static/')
                        if os.path.exists(file_path):
                            os.remove(file_path)
                            logger.info(f"Deleted icon file: {file_path}")
                except Exception as e:
                    logger.warning(f"Failed to delete icon file: {e}")
                
                log_activity(current_user.id, 'delete_os_icon', 'os_icon', None, {'os_name': os_name})
                return jsonify({'success': True, 'message': 'Icon removed successfully'})
            else:
                return jsonify({'success': False, 'error': 'Icon not found'}), 404
                
    except Exception as e:
        logger.error(f"Error deleting OS icon: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/os-icons/<os_name>')
def get_os_icon(os_name):
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT icon_path FROM os_icons WHERE os_name = ?', (os_name,))
        row = cur.fetchone()
        if row:
            return jsonify({'success': True, 'icon_path': row[0]})
    
    return jsonify({'success': True, 'icon_path': '/static/img/os/default.png'})

# ============================================================================
# User Profile Routes
# ============================================================================
@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        current_password = request.form.get('current_password')
        new_password = request.form.get('new_password')
        confirm_password = request.form.get('confirm_password')
        theme = request.form.get('theme')
        language = request.form.get('language')
        
        updates = {}
        
        if any([username != current_user.username, email != current_user.email, new_password]):
            if not current_password or not check_password_hash(current_user.password_hash, current_password):
                flash('Current password is incorrect', 'danger')
                return redirect(url_for('profile'))
        
        if username and username != current_user.username:
            if User.get_by_username(username):
                flash('Username already taken', 'danger')
            else:
                updates['username'] = username
        
        if email and email != current_user.email:
            if User.get_by_email(email):
                flash('Email already taken', 'danger')
            else:
                updates['email'] = email
        
        if new_password:
            if new_password != confirm_password:
                flash('New passwords do not match', 'danger')
            elif len(new_password) < 8:
                flash('Password must be at least 8 characters', 'danger')
            else:
                updates['password_hash'] = generate_password_hash(new_password)
        
        if theme:
            updates['theme'] = theme
        if language:
            updates['language'] = language
        
        if updates:
            with get_db() as conn:
                cur = conn.cursor()
                fields = ', '.join(f"{k} = ?" for k in updates)
                values = list(updates.values()) + [current_user.id]
                cur.execute(f'UPDATE users SET {fields} WHERE id = ?', values)
                conn.commit()
            
            log_activity(current_user.id, 'update_profile', 'user', str(current_user.id), 
                        {'fields': list(updates.keys())})
            create_notification(current_user.id, 'success', 'Profile Updated', 'Your profile has been updated successfully.')
            flash('Profile updated successfully', 'success')
        else:
            flash('No changes made', 'info')
        
        return redirect(url_for('profile'))
    
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('''SELECT * FROM activity_logs WHERE user_id = ? 
                       ORDER BY created_at DESC LIMIT 50''', (current_user.id,))
        activities = [dict(row) for row in cur.fetchall()]
    
    notifications = get_user_notifications(current_user.id, limit=10)
    
    return render_template('profile.html',
                          panel_name=get_setting('site_name', 'AVM PANEL'),
                          activities=activities,
                          notifications=notifications)

@app.route('/profile/picture', methods=['POST'])
@login_required
def upload_profile_picture():
    if 'picture' not in request.files:
        return jsonify({'success': False, 'error': 'No file uploaded'}), 400
    
    file = request.files['picture']
    if file.filename == '':
        return jsonify({'success': False, 'error': 'No file selected'}), 400
    
    if not allowed_file(file.filename):
        return jsonify({'success': False, 'error': 'Invalid file type'}), 400
    
    file.seek(0, os.SEEK_END)
    size = file.tell()
    file.seek(0)
    
    if size > app.config['MAX_IMAGE_SIZE']:
        return jsonify({'success': False, 'error': 'File too large (max 5MB)'}), 400
    
    filename = secure_filename(f"user_{current_user.id}_{int(time.time())}.{file.filename.rsplit('.', 1)[1].lower()}")
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], 'profiles', filename)
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    file.save(filepath)
    
    if PIL_AVAILABLE and Image:
        try:
            img = Image.open(filepath)
            img.thumbnail((256, 256), Image.Resampling.LANCZOS)
            img.save(filepath, optimize=True, quality=85)
        except Exception as e:
            logger.error(f"Failed to optimize image: {e}")
    
    if current_user.profile_picture:
        old_path = current_user.profile_picture.lstrip('/')
        if os.path.exists(old_path):
            try:
                os.remove(old_path)
            except:
                pass
    
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('UPDATE users SET profile_picture = ? WHERE id = ?',
                   (f'/static/uploads/profiles/{filename}', current_user.id))
        conn.commit()
    
    return jsonify({'success': True, 'path': f'/static/uploads/profiles/{filename}'})

@app.route('/profile/picture/delete', methods=['POST'])
@login_required
def delete_profile_picture():
    if current_user.profile_picture:
        old_path = current_user.profile_picture.lstrip('/')
        if os.path.exists(old_path):
            try:
                os.remove(old_path)
            except:
                pass
    
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('UPDATE users SET profile_picture = NULL WHERE id = ?', (current_user.id,))
        conn.commit()
    
    return jsonify({'success': True})

@app.route('/profile/api-key/regenerate', methods=['POST'])
@login_required
def regenerate_api_key():
    new_key = generate_api_key()
    
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('UPDATE users SET api_key = ? WHERE id = ?', (new_key, current_user.id))
        conn.commit()
    
    log_activity(current_user.id, 'regenerate_api_key', 'user', str(current_user.id))
    create_notification(current_user.id, 'warning', 'API Key Regenerated', 'Your API key has been regenerated.')
    return jsonify({'success': True, 'api_key': new_key})

@app.route('/profile/preferences', methods=['POST'])
@login_required
def update_preferences():
    data = request.get_json()
    
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('UPDATE users SET preferences = ? WHERE id = ?',
                   (json.dumps(data.get('preferences', {})), current_user.id))
        conn.commit()
    
    return jsonify({'success': True})

@app.route('/profile_picture')
@login_required
def profile_picture():
    if current_user.profile_picture and os.path.exists(current_user.profile_picture.lstrip('/')):
        return send_from_directory('static', current_user.profile_picture.replace('/static/', ''))
    else:
        return send_from_directory('static/img', 'default_avatar.png')

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

# ============================================================================
# Web Routes - Main Dashboard
# ============================================================================
@app.route('/dashboard')
@login_required
def dashboard():
    import math as _math
    import traceback as _tb

    # ── Safe int parser ──────────────────────────────────────────────────
    def _safe_int(val, suffix=''):
        try:
            if isinstance(val, (int, float)):
                return int(val)
            s = str(val).strip()
            if suffix:
                s = s.replace(suffix, '').strip()
            s = re.sub(r'[^0-9\-]', '', s)
            return int(s) if s else 0
        except Exception:
            return 0

    try:
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('UPDATE users SET last_active = ? WHERE id = ?',
                       (datetime.now().isoformat(), current_user.id))
            conn.commit()
    except Exception as e:
        logger.warning(f"dashboard: failed to update last_active: {e}")

    # ── VPS list ─────────────────────────────────────────────────────────
    try:
        vps_list = get_vps_for_user(current_user.id)
    except Exception as e:
        logger.error(f"dashboard: get_vps_for_user failed: {e}\n{_tb.format_exc()}")
        vps_list = []

    for vps in vps_list:
        vps['live_status'] = vps.get('status', 'unknown')
        vps['live_cpu']    = 0
        vps['live_ram']    = {'pct': 0, 'used': 0, 'total': 0}
        if is_vps_suspended(vps):
            vps['live_status'] = 'suspended'
        else:
            try:
                stats = run_sync(get_container_stats(vps['container_name'], vps['node_id']))
                vps['live_status'] = stats.get('status', vps.get('status', 'unknown'))
                vps['live_cpu']    = float(stats.get('cpu', 0) or 0)
                ram_data = stats.get('ram', {})
                vps['live_ram']    = ram_data if isinstance(ram_data, dict) else {'pct': 0}
            except Exception:
                pass

    total_cpu  = sum(_safe_int(v.get('cpu',   0))    for v in vps_list)
    total_ram  = sum(_safe_int(v.get('ram',  '0'), 'GB') for v in vps_list)
    total_disk = sum(_safe_int(v.get('storage','0'), 'GB') for v in vps_list)

    running_count   = sum(1 for v in vps_list if v.get('live_status') == 'running' and not is_vps_suspended(v))
    suspended_count = sum(1 for v in vps_list if is_vps_suspended(v))
    stopped_count   = len(vps_list) - running_count - suspended_count

    # ── Notifications ────────────────────────────────────────────────────
    try:
        notifications = get_user_notifications(current_user.id, unread_only=True, limit=5)
    except Exception as e:
        logger.error(f"dashboard: get_user_notifications failed: {e}")
        notifications = []

    for vps in vps_list:
        try:
            ram_pct = float((vps.get('live_ram') or {}).get('pct', 0) or 0)
            if vps.get('live_status') == 'running' and ram_pct > 90:
                create_notification(current_user.id, 'warning', 'High RAM Usage',
                    f'VPS {vps["container_name"]} is using high RAM ({ram_pct:.1f}%)')
        except Exception:
            pass

    # ── Node status ──────────────────────────────────────────────────────
    node_status = []
    try:
        for node in get_nodes()[:3]:
            try:
                status = run_sync(get_node_status(node['id']))
            except Exception as e:
                logger.warning(f"dashboard: node {node['id']} status failed: {e}")
                status = {"status": "❓ Unknown", "online": False}
            node_status.append({
                'id':        node['id'],
                'name':      node.get('name', 'Unknown'),
                'location':  node.get('location', ''),
                'status':    status.get('status', '❓ Unknown'),
                'online':    bool(status.get('online', False)),
                'vps_count': get_current_vps_count(node['id']),
                'total_vps': node.get('total_vps', 0),
            })
    except Exception as e:
        logger.error(f"dashboard: node_status loop failed: {e}\n{_tb.format_exc()}")

    # ── Chart data ───────────────────────────────────────────────────────
    vps_cpu_now = [float(v.get('live_cpu', 0) or 0) for v in vps_list]
    vps_ram_now = [float((v.get('live_ram') or {}).get('pct', 0) or 0) for v in vps_list]
    cur_cpu_avg = (sum(vps_cpu_now) / len(vps_cpu_now)) if vps_cpu_now else 0.0
    cur_ram_avg = (sum(vps_ram_now) / len(vps_ram_now)) if vps_ram_now else 0.0

    cpu_trend_7d = [round(max(0.0, min(100.0, cur_cpu_avg + 12 * _math.sin(i*0.9) + (i-3)*1.4)), 1) for i in range(7)]
    ram_trend_7d = [round(max(0.0, min(100.0, cur_ram_avg +  8 * _math.cos(i*0.7) + (i-3)*0.8)), 1) for i in range(7)]
    bw_trend_7d  = [round(max(0.0, min(100.0, 35 + 18 * _math.sin(i*0.6) + i*1.2)), 1) for i in range(7)]

    alloc_buckets = {'1-2 cores': 0, '3-4 cores': 0, '5-8 cores': 0, '9+ cores': 0}
    for vps in vps_list:
        c = _safe_int(vps.get('cpu', 0))
        if   c <= 2: alloc_buckets['1-2 cores'] += 1
        elif c <= 4: alloc_buckets['3-4 cores'] += 1
        elif c <= 8: alloc_buckets['5-8 cores'] += 1
        else:        alloc_buckets['9+ cores']  += 1

    return render_template('dashboard.html',
        panel_name=get_setting_cached('site_name', 'AVM PANEL'),
        site_description=get_setting_cached('site_description', ''),
        header_icon=get_setting_cached('header_icon', '/static/img/logo.png'),
        vps_list=vps_list,
        vps_count=len(vps_list),
        running_count=running_count,
        suspended_count=suspended_count,
        stopped_count=stopped_count,
        total_cpu=total_cpu,
        total_ram=total_ram,
        total_disk=total_disk,
        notifications=notifications,
        node_status=node_status,
        cpu_trend_7d=cpu_trend_7d,
        ram_trend_7d=ram_trend_7d,
        bw_trend_7d=bw_trend_7d,
        alloc_buckets=alloc_buckets,
        socketio_available=SOCKETIO_AVAILABLE,
    )

@app.route('/vps')
@login_required
def vps_list():
    """VPS list with improved stats fetching"""
    vps_list = get_vps_for_user(current_user.id)

    for vps in vps_list:
        # Initialize with safe defaults
        vps['live_status'] = vps.get('status', 'unknown')
        vps['live_cpu'] = 0.0
        vps['live_ram'] = {'used': 0, 'total': 0, 'pct': 0.0}
        vps['live_disk'] = {'use_percent': '0%'}

        # Check if VPS is suspended first
        if is_vps_suspended(vps):
            vps['live_status'] = 'suspended'
        else:
            try:
                stats = run_sync(
                    get_container_stats(
                        vps['container_name'],
                        vps['node_id']
                    )
                )

                vps['live_status'] = stats.get('status', 'unknown')
                vps['live_cpu'] = float(stats.get('cpu', 0.0))
                
                # Ensure RAM is a dict
                ram_data = stats.get('ram', {'used': 0, 'total': 0, 'pct': 0.0})
                if isinstance(ram_data, dict):
                    vps['live_ram'] = ram_data
                else:
                    vps['live_ram'] = {'used': 0, 'total': 0, 'pct': 0.0}
                
                # Ensure disk is a dict
                disk_data = stats.get('disk', {'use_percent': '0%'})
                if isinstance(disk_data, dict):
                    vps['live_disk'] = disk_data
                else:
                    vps['live_disk'] = {'use_percent': '0%'}
                
                logger.debug(f"VPS {vps['id']} stats: status={vps['live_status']}, cpu={vps['live_cpu']}, ram={vps['live_ram']}")

            except Exception as e:
                logger.warning(f"Stats error for {vps.get('container_name')}: {e}")
                vps['live_status'] = 'unknown'

    return render_template(
        'vps_list.html',
        panel_name=get_setting('site_name', 'AVM PANEL'),
        vps_list=vps_list,
        socketio_available=SOCKETIO_AVAILABLE
    )

@app.route('/vps/<int:vps_id>')
@login_required
def vps_detail(vps_id):
    vps = get_vps_by_id(vps_id)
    if not vps:
        flash('VPS not found', 'danger')
        return redirect(url_for('vps_list'))

    shared_with = vps.get('shared_with', []) or []

    allowed = (
        vps['user_id'] == current_user.id
        or str(current_user.id) in [str(uid) for uid in shared_with]
        or current_user.is_admin
    )

    if not allowed:
        flash('VPS not found or access denied', 'danger')
        return redirect(url_for('vps_list'))

    # If VPS is suspended, redirect non-admins to suspended page
    if is_vps_suspended(vps) and not current_user.is_admin:
        return redirect(url_for('vps_suspended_page', vps_id=vps_id))

    node = get_node(vps['node_id'])

    try:
        logger.info(f"Fetching stats for container {vps['container_name']} on node {vps['node_id']}")
        stats = run_sync(
            get_container_stats(
                vps['container_name'],
                vps['node_id']
            )
        ) or {}
        
        logger.info(f"Stats fetched for {vps['container_name']}: CPU={stats.get('cpu', 'N/A')}, Status={stats.get('status', 'N/A')}")

    except Exception as e:
        logger.error(
            f"Stats error for {vps['container_name']}: {e}", exc_info=True
        )
        stats = {
            "status": "unknown",
            "cpu": 0.0,
            "ram": {"used": 0, "total": 0, "pct": 0.0},
            "disk": {"use_percent": "0%"},
            "uptime": "Unknown"
        }

    live_status = stats.get("status")

    # If VPS is suspended (admin viewing), show suspended status
    if is_vps_suspended(vps):
        live_status = 'suspended'
        vps['status'] = 'suspended'
    elif live_status in ("running", "stopped"):
        if live_status != vps.get("status"):
            update_vps(vps_id, status=live_status)
            vps["status"] = live_status

    # Get console IP from inside the container (works for both LXC and KVM)
    console_ip = "N/A"
    if live_status == "running":
        try:
            console_ip = run_sync(
                get_container_private_ip(
                    vps['container_name'],
                    vps['node_id']
                )
            )
            logger.info(f"VPS {vps_id} ({vps['container_name']}) console IP: {console_ip}")
        except Exception as e:
            logger.error(f"Error getting console IP for {vps['container_name']}: {e}")
            console_ip = "N/A"

    forwards = get_user_forwards(current_user.id)
    vps_forwards = [
        f for f in forwards
        if f['vps_container'] == vps['container_name']
    ]

    shared_users = []
    if shared_with:
        logger.info(f"VPS {vps_id} shared_with list: {shared_with}")
        with get_db() as conn:
            cur = conn.cursor()

            for uid in shared_with:
                try:
                    uid_int = int(uid)
                    cur.execute(
                        '''
                        SELECT id, username, email, profile_picture
                        FROM users WHERE id=?
                        ''',
                        (uid_int,)
                    )
                    row = cur.fetchone()
                    if row:
                        user_dict = dict(row)
                        shared_users.append(user_dict)
                        logger.info(f"Added shared user: {user_dict['username']} (ID: {user_dict['id']})")
                    else:
                        logger.warning(f"User ID {uid_int} not found in database")
                except Exception as e:
                    logger.error(f"Error loading shared user {uid}: {e}")
    
    logger.info(f"VPS {vps_id} total shared_users: {len(shared_users)}")

    with get_db() as conn:
        cur = conn.cursor()
        cur.execute(
            '''
            SELECT * FROM backups
            WHERE vps_id=?
            ORDER BY created_at DESC
            ''',
            (vps_id,)
        )
        backups = [dict(r) for r in cur.fetchall()]

    with get_db() as conn:
        cur = conn.cursor()
        cur.execute(
            '''
            SELECT * FROM activity_logs
            WHERE resource_type='vps'
            AND resource_id=?
            ORDER BY created_at DESC
            LIMIT 20
            ''',
            (str(vps_id),)
        )
        activities = [dict(r) for r in cur.fetchall()]

    display_ip = get_vps_display_ip(vps) or YOUR_SERVER_IP

    os_icon = "default"
    for os_option in OS_OPTIONS:
        if os_option["value"] == vps["os_version"]:
            os_icon = os_option.get("icon", "default")
            break

    return render_template(
        "vps_detail.html",
        panel_name=get_setting('site_name', 'AVM PANEL'),
        vps=vps,
        node=node,
        stats=stats,
        forwards=vps_forwards,
        shared_users=shared_users,
        os_options=OS_OPTIONS,
        backups=backups,
        activities=activities,
        private_ip=console_ip,
        display_ip=display_ip,
        YOUR_SERVER_IP=YOUR_SERVER_IP,
        os_icon=os_icon,
        socketio_available=SOCKETIO_AVAILABLE
    )









# ============================================================================
# VPS File Manager Routes - SFTP Based
# ============================================================================

def get_sftp_connection(vps):
    """Create SFTP connection to VPS"""
    import paramiko

    # Get node to find the actual host
    node = get_node(vps['node_id'])
    if not node:
        raise Exception("Node not found")

    # Parse node URL to get host
    from urllib.parse import urlparse
    parsed = urlparse(node['url'])
    node_host = parsed.hostname or node['url'].split('://')[1].split(':')[0] if '://' in node['url'] else node['url'].split(':')[0]

    # Try to get VPS private IP first (direct connection if on same network)
    try:
        private_ip = run_sync(get_container_private_ip(vps['container_name'], vps['node_id']))
        if private_ip and private_ip != "N/A":
            # Try direct connection to private IP
            ssh = paramiko.SSHClient()
            ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            try:
                ssh.connect(
                    hostname=private_ip,
                    port=22,
                    username='root',
                    password='root',
                    timeout=5,
                    allow_agent=False,
                    look_for_keys=False
                )
                sftp = ssh.open_sftp()
                logger.info(f"SFTP connected directly to {private_ip}:22")
                return ssh, sftp
            except Exception as e:
                logger.debug(f"Direct IP connection failed: {e}, trying port forward")
                ssh.close()
    except Exception as e:
        logger.debug(f"Could not get private IP: {e}")

    # Fallback to port forward method
    # Check if port 22 forward exists
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('''
            SELECT host_port FROM port_forwards
            WHERE vps_container = ? AND vps_port = 22
        ''', (vps['container_name'],))
        row = cur.fetchone()

        if row:
            ssh_port = row['host_port']
        else:
            # Auto-create port 22 forward
            logger.info(f"Auto-creating SSH port forward for {vps['container_name']}")
            try:
                # Create the forward (it will auto-assign a host port)
                host_port = run_sync(create_port_forward(
                    user_id=vps['user_id'],
                    container=vps['container_name'],
                    vps_port=22,
                    node_id=vps['node_id'],
                    protocol='tcp',
                    description='SSH (auto-created for file manager)'
                ))
                
                if not host_port:
                    raise Exception("No available ports for SSH forward")
                
                ssh_port = host_port
                logger.info(f"Created SSH forward: {node_host}:{ssh_port} -> {vps['container_name']}:22")
            except Exception as e:
                raise Exception(f"Could not create SSH port forward: {str(e)}")

    # Create SSH client
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    try:
        # Connect with root:root credentials via port forward
        ssh.connect(
            hostname=node_host,
            port=ssh_port,
            username='root',
            password='root',
            timeout=10,
            allow_agent=False,
            look_for_keys=False
        )

        # Open SFTP session
        sftp = ssh.open_sftp()
        logger.info(f"SFTP connected via port forward {node_host}:{ssh_port}")
        return ssh, sftp
    except Exception as e:
        ssh.close()
        raise Exception(f"SFTP connection failed: {str(e)}")



@app.route('/vps/<int:vps_id>/files')
@login_required
def vps_files(vps_id):
    """VPS File Manager"""
    vps = get_vps_by_id(vps_id)
    if not vps:
        flash('VPS not found', 'danger')
        return redirect(url_for('dashboard'))
    
    # Check ownership
    if vps['user_id'] != current_user.id and not current_user.is_admin:
        flash('Access denied', 'danger')
        return redirect(url_for('dashboard'))
    
    # Check if VPS is suspended
    if is_vps_suspended(vps) and not current_user.is_admin:
        flash('VPS is suspended. File manager access denied.', 'danger')
        return redirect(url_for('vps_suspended_page', vps_id=vps_id))
    
    # Check if VPS is running
    status = run_sync(get_container_status(vps['container_name'], vps['node_id']))
    
    return render_template('vps_files.html',
                          panel_name=get_setting('site_name', 'AVM PANEL'),
                          vps=vps,
                          status=status)

@app.route('/vps/<int:vps_id>/files/browse', methods=['POST'])
@login_required
def vps_files_browse(vps_id):
    """Browse VPS files via SFTP"""
    vps = get_vps_by_id(vps_id)
    if not vps or (vps['user_id'] != current_user.id and not current_user.is_admin):
        return jsonify({'success': False, 'error': 'Access denied'}), 403
    
    if is_vps_suspended(vps) and not current_user.is_admin:
        return jsonify({'success': False, 'error': 'VPS is suspended'}), 403
    
    data = request.get_json()
    path = data.get('path', '/root')
    
    # Security: prevent path traversal
    if '..' in path:
        return jsonify({'success': False, 'error': 'Invalid path'}), 400
    
    ssh = None
    sftp = None
    try:
        ssh, sftp = get_sftp_connection(vps)
        
        # List directory
        files = []
        for item in sftp.listdir_attr(path):
            import stat
            is_dir = stat.S_ISDIR(item.st_mode)
            is_link = stat.S_ISLNK(item.st_mode)
            
            # Format size
            if is_dir:
                size = '-'
            else:
                size_bytes = item.st_size
                if size_bytes < 1024:
                    size = f"{size_bytes}B"
                elif size_bytes < 1024 * 1024:
                    size = f"{size_bytes / 1024:.1f}K"
                elif size_bytes < 1024 * 1024 * 1024:
                    size = f"{size_bytes / (1024 * 1024):.1f}M"
                else:
                    size = f"{size_bytes / (1024 * 1024 * 1024):.1f}G"
            
            # Format permissions
            perms = stat.filemode(item.st_mode)
            
            # Format modified time
            from datetime import datetime
            modified = datetime.fromtimestamp(item.st_mtime).strftime('%Y-%m-%d %H:%M')
            
            files.append({
                'name': item.filename,
                'size': size,
                'modified': modified,
                'permissions': perms,
                'owner': f"{item.st_uid}:{item.st_gid}",
                'is_dir': is_dir,
                'is_link': is_link
            })
        
        # Sort: directories first, then by name
        files.sort(key=lambda x: (not x['is_dir'], x['name'].lower()))
        
        return jsonify({
            'success': True,
            'path': path,
            'files': files
        })
        
    except Exception as e:
        logger.error(f"Error browsing files: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        if sftp:
            sftp.close()
        if ssh:
            ssh.close()

@app.route('/vps/<int:vps_id>/files/upload', methods=['POST'])
@login_required
def vps_files_upload(vps_id):
    """Upload file to VPS via SFTP"""
    vps = get_vps_by_id(vps_id)
    if not vps or (vps['user_id'] != current_user.id and not current_user.is_admin):
        return jsonify({'success': False, 'error': 'Access denied'}), 403
    
    if is_vps_suspended(vps) and not current_user.is_admin:
        return jsonify({'success': False, 'error': 'VPS is suspended'}), 403
    
    if 'file' not in request.files:
        return jsonify({'success': False, 'error': 'No file provided'}), 400
    
    file = request.files['file']
    path = request.form.get('path', '/root')
    
    if file.filename == '':
        return jsonify({'success': False, 'error': 'No file selected'}), 400
    
    # Security checks
    if '..' in path or '..' in file.filename:
        return jsonify({'success': False, 'error': 'Invalid path'}), 400
    
    ssh = None
    sftp = None
    tmp_path = None
    try:
        # Save file temporarily
        import tempfile
        with tempfile.NamedTemporaryFile(delete=False) as tmp:
            file.save(tmp.name)
            tmp_path = tmp.name
        
        # Connect via SFTP
        ssh, sftp = get_sftp_connection(vps)
        
        # Upload file
        target_path = f"{path.rstrip('/')}/{file.filename}"
        sftp.put(tmp_path, target_path)
        
        log_activity(current_user.id, 'upload_file', 'vps', str(vps_id),
                    {'file': file.filename, 'path': path})
        
        return jsonify({
            'success': True,
            'message': f'File {file.filename} uploaded successfully'
        })
        
    except Exception as e:
        logger.error(f"Error uploading file: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        if tmp_path and os.path.exists(tmp_path):
            os.unlink(tmp_path)
        if sftp:
            sftp.close()
        if ssh:
            ssh.close()

@app.route('/vps/<int:vps_id>/files/download', methods=['POST'])
@login_required  
def vps_files_download(vps_id):
    """Download file from VPS via SFTP"""
    vps = get_vps_by_id(vps_id)
    if not vps or (vps['user_id'] != current_user.id and not current_user.is_admin):
        return jsonify({'success': False, 'error': 'Access denied'}), 403
    
    if is_vps_suspended(vps) and not current_user.is_admin:
        return jsonify({'success': False, 'error': 'VPS is suspended'}), 403
    
    data = request.get_json()
    file_path = data.get('path')
    
    if not file_path or '..' in file_path:
        return jsonify({'success': False, 'error': 'Invalid path'}), 400
    
    ssh = None
    sftp = None
    tmp_path = None
    try:
        import tempfile
        
        # Connect via SFTP
        ssh, sftp = get_sftp_connection(vps)
        
        # Download to temp file
        tmp = tempfile.NamedTemporaryFile(delete=False)
        tmp.close()
        tmp_path = tmp.name
        
        sftp.get(file_path, tmp_path)
        
        filename = os.path.basename(file_path)
        
        log_activity(current_user.id, 'download_file', 'vps', str(vps_id),
                    {'file': file_path})
        
        return send_file(tmp_path, as_attachment=True, download_name=filename)
        
    except Exception as e:
        logger.error(f"Error downloading file: {e}")
        if tmp_path and os.path.exists(tmp_path):
            os.unlink(tmp_path)
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        if sftp:
            sftp.close()
        if ssh:
            ssh.close()

@app.route('/vps/<int:vps_id>/files/delete', methods=['POST'])
@login_required
def vps_files_delete(vps_id):
    """Delete file or directory from VPS via SFTP"""
    vps = get_vps_by_id(vps_id)
    if not vps or (vps['user_id'] != current_user.id and not current_user.is_admin):
        return jsonify({'success': False, 'error': 'Access denied'}), 403
    
    if is_vps_suspended(vps) and not current_user.is_admin:
        return jsonify({'success': False, 'error': 'VPS is suspended'}), 403
    
    data = request.get_json()
    path = data.get('path')
    is_dir = data.get('is_dir', False)
    
    if not path or '..' in path:
        return jsonify({'success': False, 'error': 'Invalid path'}), 400
    
    # Prevent deleting critical directories
    critical_paths = ['/', '/bin', '/boot', '/dev', '/etc', '/lib', '/proc', '/root', '/sbin', '/sys', '/usr', '/var']
    if path in critical_paths:
        return jsonify({'success': False, 'error': 'Cannot delete system directory'}), 400
    
    ssh = None
    sftp = None
    try:
        ssh, sftp = get_sftp_connection(vps)
        
        if is_dir:
            # Remove directory recursively
            def rmdir_recursive(sftp, path):
                for item in sftp.listdir_attr(path):
                    item_path = f"{path}/{item.filename}"
                    import stat
                    if stat.S_ISDIR(item.st_mode):
                        rmdir_recursive(sftp, item_path)
                    else:
                        sftp.remove(item_path)
                sftp.rmdir(path)
            
            rmdir_recursive(sftp, path)
        else:
            sftp.remove(path)
        
        log_activity(current_user.id, 'delete_file', 'vps', str(vps_id),
                    {'path': path, 'is_dir': is_dir})
        
        return jsonify({
            'success': True,
            'message': f'{"Directory" if is_dir else "File"} deleted successfully'
        })
        
    except Exception as e:
        logger.error(f"Error deleting file: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        if sftp:
            sftp.close()
        if ssh:
            ssh.close()

@app.route('/vps/<int:vps_id>/files/rename', methods=['POST'])
@login_required
def vps_files_rename(vps_id):
    """Rename file or directory in VPS via SFTP"""
    vps = get_vps_by_id(vps_id)
    if not vps or (vps['user_id'] != current_user.id and not current_user.is_admin):
        return jsonify({'success': False, 'error': 'Access denied'}), 403
    
    if is_vps_suspended(vps) and not current_user.is_admin:
        return jsonify({'success': False, 'error': 'VPS is suspended'}), 403
    
    data = request.get_json()
    old_path = data.get('old_path')
    new_name = data.get('new_name')
    
    if not old_path or not new_name or '..' in old_path or '..' in new_name or '/' in new_name:
        return jsonify({'success': False, 'error': 'Invalid path or name'}), 400
    
    ssh = None
    sftp = None
    try:
        ssh, sftp = get_sftp_connection(vps)
        
        # Get directory of old path
        directory = os.path.dirname(old_path)
        new_path = f"{directory}/{new_name}" if directory != '/' else f"/{new_name}"
        
        sftp.rename(old_path, new_path)
        
        log_activity(current_user.id, 'rename_file', 'vps', str(vps_id),
                    {'old': old_path, 'new': new_path})
        
        return jsonify({
            'success': True,
            'message': 'Renamed successfully'
        })
        
    except Exception as e:
        logger.error(f"Error renaming file: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        if sftp:
            sftp.close()
        if ssh:
            ssh.close()

@app.route('/vps/<int:vps_id>/files/mkdir', methods=['POST'])
@login_required
def vps_files_mkdir(vps_id):
    """Create new directory in VPS via SFTP"""
    vps = get_vps_by_id(vps_id)
    if not vps or (vps['user_id'] != current_user.id and not current_user.is_admin):
        return jsonify({'success': False, 'error': 'Access denied'}), 403
    
    if is_vps_suspended(vps) and not current_user.is_admin:
        return jsonify({'success': False, 'error': 'VPS is suspended'}), 403
    
    data = request.get_json()
    path = data.get('path')
    name = data.get('name')
    
    if not path or not name or '..' in path or '..' in name or '/' in name:
        return jsonify({'success': False, 'error': 'Invalid path or name'}), 400
    
    ssh = None
    sftp = None
    try:
        ssh, sftp = get_sftp_connection(vps)
        
        new_dir = f"{path.rstrip('/')}/{name}"
        sftp.mkdir(new_dir)
        
        log_activity(current_user.id, 'create_directory', 'vps', str(vps_id),
                    {'path': new_dir})
        
        return jsonify({
            'success': True,
            'message': f'Directory {name} created successfully'
        })
        
    except Exception as e:
        logger.error(f"Error creating directory: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        if sftp:
            sftp.close()
        if ssh:
            ssh.close()


# ============================================================================
# VPS Control Routes
# ============================================================================
@app.route('/vps/<int:vps_id>/control/<action>', methods=['POST'])
@login_required
def vps_control(vps_id, action):
    vps = get_vps_by_id(vps_id)
    if not vps or (vps['user_id'] != current_user.id and not current_user.is_admin):
        return jsonify({'success': False, 'error': 'Access denied'}), 403
    
    if is_vps_suspended(vps) and not current_user.is_admin:
        return jsonify({'success': False, 'error': 'VPS is suspended'}), 403
    
    actions = ['start', 'stop', 'restart', 'freeze', 'unfreeze']
    if action not in actions:
        return jsonify({'success': False, 'error': 'Invalid action'}), 400
    
    try:
        if action == 'start':
            run_sync(execute_lxc(vps['container_name'], f"start {vps['container_name']}", node_id=vps['node_id']))
            run_sync(apply_internal_permissions(vps['container_name'], vps['node_id']))
            run_sync(recreate_port_forwards(vps['container_name']))
            update_vps(vps_id, status='running', last_started=datetime.now().isoformat())
            log_activity(current_user.id, 'start_vps', 'vps', str(vps_id))
            create_notification(current_user.id, 'success', 'VPS Started', f'VPS {vps["container_name"]} has been started.')
            
            if socketio:
                socketio.emit('vps_status_change', {
                    'vps_id': vps_id,
                    'status': 'running'
                }, room=f'vps_{vps_id}')
                
        elif action == 'stop':
            run_sync(execute_lxc(vps['container_name'], f"stop {vps['container_name']}", node_id=vps['node_id']))
            update_vps(vps_id, status='stopped', last_stopped=datetime.now().isoformat())
            log_activity(current_user.id, 'stop_vps', 'vps', str(vps_id))
            create_notification(current_user.id, 'info', 'VPS Stopped', f'VPS {vps["container_name"]} has been stopped.')
            
            if socketio:
                socketio.emit('vps_status_change', {
                    'vps_id': vps_id,
                    'status': 'stopped'
                }, room=f'vps_{vps_id}')
                
        elif action == 'restart':
            run_sync(execute_lxc(vps['container_name'], f"restart {vps['container_name']}", node_id=vps['node_id']))
            run_sync(apply_internal_permissions(vps['container_name'], vps['node_id']))
            run_sync(recreate_port_forwards(vps['container_name']))
            update_vps(vps_id, status='running', last_started=datetime.now().isoformat())
            log_activity(current_user.id, 'restart_vps', 'vps', str(vps_id))
            create_notification(current_user.id, 'success', 'VPS Restarted', f'VPS {vps["container_name"]} has been restarted.')
            
            if socketio:
                socketio.emit('vps_status_change', {
                    'vps_id': vps_id,
                    'status': 'running'
                }, room=f'vps_{vps_id}')
                
        elif action == 'freeze':
            run_sync(execute_lxc(vps['container_name'], f"freeze {vps['container_name']}", node_id=vps['node_id']))
            update_vps(vps_id, status='frozen')
            log_activity(current_user.id, 'freeze_vps', 'vps', str(vps_id))
            create_notification(current_user.id, 'warning', 'VPS Frozen', f'VPS {vps["container_name"]} has been frozen.')
            
            if socketio:
                socketio.emit('vps_status_change', {
                    'vps_id': vps_id,
                    'status': 'frozen'
                }, room=f'vps_{vps_id}')
                
        elif action == 'unfreeze':
            run_sync(execute_lxc(vps['container_name'], f"unfreeze {vps['container_name']}", node_id=vps['node_id']))
            update_vps(vps_id, status='running')
            log_activity(current_user.id, 'unfreeze_vps', 'vps', str(vps_id))
            create_notification(current_user.id, 'success', 'VPS Unfrozen', f'VPS {vps["container_name"]} has been unfrozen.')
            
            if socketio:
                socketio.emit('vps_status_change', {
                    'vps_id': vps_id,
                    'status': 'running'
                }, room=f'vps_{vps_id}')
        
        return jsonify({'success': True})
    except Exception as e:
        logger.error(f"VPS control error: {e}")
        create_notification(current_user.id, 'error', 'Action Failed', f'Failed to {action} VPS: {str(e)}')
        log_vps_error(vps_id, vps['container_name'], vps['user_id'], action, str(e))
        return jsonify({'success': False, 'error': str(e)}), 500

# ============================================================================
# Console Routes - LOGIN REQUIRED VERSION
# ============================================================================
@app.route('/vps/<int:vps_id>/console/login')
@login_required
def vps_console_login(vps_id):
    """Show console login form to collect IP, username, password"""
    vps = get_vps_by_id(vps_id)
    if not vps or (vps['user_id'] != current_user.id and not current_user.is_admin):
        flash('Access denied', 'danger')
        return redirect(url_for('vps_list'))
    
    # Check if VPS is suspended
    if is_vps_suspended(vps) and not current_user.is_admin:
        flash('VPS is suspended. Console access denied.', 'danger')
        return redirect(url_for('vps_suspended_page', vps_id=vps_id))
    
    return render_template(
        'console_connect.html',
        panel_name=get_setting('site_name', 'AVM PANEL'),
        vps=vps
    )

@app.route('/vps/<int:vps_id>/console')
@login_required
def vps_console(vps_id):
    vps = get_vps_by_id(vps_id)
    if not vps or (vps['user_id'] != current_user.id and not current_user.is_admin):
        flash('Access denied', 'danger')
        return redirect(url_for('vps_list'))
    
    # Check if VPS is suspended
    if is_vps_suspended(vps) and not current_user.is_admin:
        flash('VPS is suspended. Console access denied.', 'danger')
        return redirect(url_for('vps_suspended_page', vps_id=vps_id))

    # Get VPS IP address
    vps_ip = vps.get('ip_address', '')
    
    return render_template(
        'console.html',
        panel_name=get_setting('site_name', 'AVM PANEL'),
        vps=vps,
        vps_ip=vps_ip,
        ssh_available=SSH_AVAILABLE
    )

# SocketIO events for SSH console
if socketio and SSH_AVAILABLE:
    @socketio.on('ssh_connect')
    def handle_ssh_connect(data):
        vps_id = data.get('vps_id')
        host = data.get('host', '')
        port = data.get('port', 22)
        username = data.get('username', 'root')
        password = data.get('password', '')
        sid = request.sid

        logger.info(f"SSH connect request for VPS {vps_id} from session {sid} to {username}@{host}:{port}")

        vps = get_vps_by_id(vps_id)
        if not vps:
            logger.error(f"SSH connect failed: VPS {vps_id} not found")
            emit('ssh_error', {'error': 'VPS not found'}, room=sid)
            return

        if vps['user_id'] != current_user.id and not current_user.is_admin:
            logger.error(f"SSH connect failed: Access denied for VPS {vps_id}")
            emit('ssh_error', {'error': 'Access denied'}, room=sid)
            return

        if is_vps_suspended(vps) and not current_user.is_admin:
            logger.error(f"SSH connect failed: VPS {vps_id} is suspended")
            emit('ssh_error', {'error': 'VPS is suspended'}, room=sid)
            return

        if not host or not password:
            logger.error(f"SSH connect failed: Missing host or password")
            emit('ssh_error', {'error': 'Host and password are required'}, room=sid)
            return

        with active_consoles_lock:
            # Close existing SSH connection if any
            if vps_id in active_consoles:
                old_info = active_consoles[vps_id]
                try:
                    if 'ssh_client' in old_info and old_info['ssh_client']:
                        old_info['ssh_client'].close()
                    if 'channel' in old_info and old_info['channel']:
                        old_info['channel'].close()
                except:
                    pass
                active_consoles.pop(vps_id, None)
                logger.info(f"Closed existing SSH connection for VPS {vps_id}")

            try:
                # Create SSH client
                ssh_client = paramiko.SSHClient()
                ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                
                # Connect to SSH
                try:
                    port = int(port)
                except:
                    port = 22
                
                logger.info(f"Connecting to SSH: {username}@{host}:{port}")
                ssh_client.connect(
                    hostname=host,
                    port=port,
                    username=username,
                    password=password,
                    timeout=10,
                    allow_agent=False,
                    look_for_keys=False
                )
                
                # Open interactive shell channel
                channel = ssh_client.invoke_shell(term='xterm', width=80, height=24)
                channel.settimeout(0.1)
                
                logger.info(f"SSH connected for VPS {vps_id}")

                active_consoles[vps_id] = {
                    'ssh_client': ssh_client,
                    'channel': channel,
                    'sid': sid,
                    'host': host,
                    'port': port,
                    'username': username,
                    'user_id': current_user.id
                }

                def reader():
                    try:
                        logger.info(f"SSH reader thread started for VPS {vps_id}")
                        while True:
                            # Check if channel is still open
                            if channel.closed:
                                logger.info(f"SSH channel closed for VPS {vps_id}")
                                break

                            # Read output from channel
                            try:
                                if channel.recv_ready():
                                    output = channel.recv(4096)
                                    if not output:
                                        break
                                    # Send to client
                                    socketio.emit('ssh_output', output.decode('utf-8', errors='replace'), room=sid)
                                else:
                                    time.sleep(0.01)
                            except socket.timeout:
                                continue
                            except Exception as e:
                                logger.error(f"SSH read error for VPS {vps_id}: {e}")
                                break

                    except Exception as e:
                        logger.error(f"SSH reader error for VPS {vps_id}: {e}")
                        socketio.emit('ssh_error', {'error': str(e)}, room=sid)
                    finally:
                        logger.info(f"SSH reader thread ending for VPS {vps_id}")
                        try:
                            channel.close()
                            ssh_client.close()
                        except:
                            pass
                        with active_consoles_lock:
                            active_consoles.pop(vps_id, None)
                        socketio.emit('ssh_disconnected', {}, room=sid)

                thread = threading.Thread(target=reader, daemon=True)
                thread.start()

                emit('ssh_connected', {
                    'status': 'connected',
                    'host': host,
                    'port': port,
                    'username': username
                }, room=sid)
                logger.info(f"SSH session established for VPS {vps_id}")

            except paramiko.AuthenticationException:
                logger.error(f"SSH authentication failed for VPS {vps_id}")
                emit('ssh_error', {'error': 'Authentication failed. Invalid username or password.'}, room=sid)
            except paramiko.SSHException as e:
                logger.error(f"SSH connection error for VPS {vps_id}: {e}")
                emit('ssh_error', {'error': f'SSH connection error: {str(e)}'}, room=sid)
            except socket.timeout:
                logger.error(f"SSH connection timeout for VPS {vps_id}")
                emit('ssh_error', {'error': 'Connection timeout. Check if SSH is running on the VPS.'}, room=sid)
            except Exception as e:
                logger.error(f"Failed to start SSH for VPS {vps_id}: {e}", exc_info=True)
                emit('ssh_error', {'error': f'Failed to connect: {str(e)}'}, room=sid)

    @socketio.on('ssh_input')
    def handle_ssh_input(data):
        vps_id = data.get('vps_id')
        input_data = data.get('input', '')

        with active_consoles_lock:
            info = active_consoles.get(vps_id)
            if not info or info.get('sid') != request.sid:
                emit('ssh_error', {'error': 'SSH not connected'}, room=request.sid)
                return

            try:
                channel = info.get('channel')
                if channel and not channel.closed:
                    if isinstance(input_data, str):
                        input_data = input_data.encode('utf-8')
                    channel.send(input_data)
            except Exception as e:
                logger.error(f"SSH input error for VPS {vps_id}: {e}")
                emit('ssh_error', {'error': str(e)}, room=request.sid)

    @socketio.on('ssh_resize')
    def handle_ssh_resize(data):
        vps_id = data.get('vps_id')
        cols = data.get('cols', 80)
        rows = data.get('rows', 24)

        with active_consoles_lock:
            info = active_consoles.get(vps_id)
            if info and info.get('sid') == request.sid:
                try:
                    channel = info.get('channel')
                    if channel and not channel.closed:
                        channel.resize_pty(width=cols, height=rows)
                        logger.debug(f"SSH terminal resized for VPS {vps_id}: {cols}x{rows}")
                except Exception as e:
                    logger.error(f"SSH resize error for VPS {vps_id}: {e}")

    @socketio.on('ssh_disconnect')
    def handle_ssh_disconnect(data):
        vps_id = data.get('vps_id')
        logger.info(f"SSH disconnect request for VPS {vps_id}")
        
        with active_consoles_lock:
            info = active_consoles.pop(vps_id, None)
            if info and info.get('sid') == request.sid:
                try:
                    if 'channel' in info and info['channel']:
                        info['channel'].close()
                    if 'ssh_client' in info and info['ssh_client']:
                        info['ssh_client'].close()
                    logger.info(f"SSH disconnected for VPS {vps_id}")
                except Exception as e:
                    logger.error(f"SSH disconnect error for VPS {vps_id}: {e}")

@app.route('/vps/<int:vps_id>/ssh', methods=['POST'])
@login_required
def vps_ssh(vps_id):
    vps = get_vps_by_id(vps_id)
    if not vps or (vps['user_id'] != current_user.id and not current_user.is_admin):
        return jsonify({'success': False, 'error': 'Access denied'}), 403
    
    if is_vps_suspended(vps) and not current_user.is_admin:
        return jsonify({'success': False, 'error': 'VPS is suspended'}), 403
    
    try:
        container_name = vps['container_name']
        node_id = vps['node_id']
        session_name = f"avm-session-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        
        try:
            run_sync(execute_lxc(container_name, f"exec {container_name} -- which tmate", node_id=node_id))
        except:
            try:
                os_check = run_sync(execute_lxc(container_name, f"exec {container_name} -- cat /etc/os-release", node_id=node_id))
                if 'alpine' in os_check.lower():
                    run_sync(execute_lxc(container_name, f"exec {container_name} -- apk add tmate", node_id=node_id))
                else:
                    run_sync(execute_lxc(container_name, f"exec {container_name} -- apt-get update -y", node_id=node_id))
                    run_sync(execute_lxc(container_name, f"exec {container_name} -- apt-get install -y tmate", node_id=node_id))
            except Exception as e:
                return jsonify({'success': False, 'error': f'Could not install tmate: {str(e)}'}), 500
        
        run_sync(execute_lxc(container_name, f"exec {container_name} -- tmate -S /tmp/{session_name}.sock new-session -d", node_id=node_id))
        run_sync(asyncio.sleep(3))
        
        ssh_output = run_sync(execute_lxc(container_name, f"exec {container_name} -- tmate -S /tmp/{session_name}.sock display -p '#{{tmate_ssh}}'", node_id=node_id))
        ssh_url = ssh_output.strip()
        
        web_output = run_sync(execute_lxc(container_name, f"exec {container_name} -- tmate -S /tmp/{session_name}.sock display -p '#{{tmate_web}}'", node_id=node_id))
        web_url = web_output.strip()
        
        if ssh_url:
            log_activity(current_user.id, 'generate_ssh', 'vps', str(vps_id))
            create_notification(current_user.id, 'info', 'SSH Session Created', f'SSH session created for {container_name}')
            return jsonify({
                'success': True,
                'ssh_url': ssh_url,
                'web_url': web_url,
                'session': session_name
            })
        else:
            return jsonify({'success': False, 'error': 'Could not generate SSH URL'}), 500
    except Exception as e:
        logger.error(f"SSH generation error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/vps/<int:vps_id>/change-password', methods=['POST'])
@login_required
def vps_change_password(vps_id):
    """Change the root password of a VPS container."""
    vps = get_vps_by_id(vps_id)
    if not vps or (vps['user_id'] != current_user.id and not current_user.is_admin):
        return jsonify({'success': False, 'error': 'Access denied'}), 403

    if is_vps_suspended(vps) and not current_user.is_admin:
        return jsonify({'success': False, 'error': 'VPS is suspended'}), 403

    data     = request.get_json() or {}
    password = data.get('password', '').strip()

    if not password:
        return jsonify({'success': False, 'error': 'Password cannot be empty'}), 400
    if len(password) < 6:
        return jsonify({'success': False, 'error': 'Password must be at least 6 characters'}), 400
    # Basic safety — reject shell metacharacters
    if any(c in password for c in ["'", '"', '\\', '\n', '\r', '\0']):
        return jsonify({'success': False, 'error': 'Password contains invalid characters'}), 400

    container_name = vps['container_name']
    node_id        = vps['node_id']

    try:
        # Use printf to avoid echo interpretation issues
        cmd = f"exec {container_name} -- sh -c \"printf '%s\\n%s\\n' '{password}' '{password}' | passwd root\""
        run_sync(execute_lxc(container_name, cmd, node_id=node_id))
        log_activity(current_user.id, 'change_vps_password', 'vps', str(vps_id))
        return jsonify({'success': True})
    except Exception as e:
        logger.error(f"VPS password change error for {container_name}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/vps/<int:vps_id>/tailscale/test-auto', methods=['POST'])
@login_required
def vps_tailscale_test_auto(vps_id):
    """
    Automatically test and fix all Tailscale issues without manual intervention
    This endpoint handles everything automatically
    """
    vps = get_vps_by_id(vps_id)
    if not vps or (vps['user_id'] != current_user.id and not current_user.is_admin):
        return jsonify({'success': False, 'error': 'Access denied'}), 403

    container_name = vps['container_name']
    node_id = vps['node_id']
    
    try:
        import re as _re, time as _time
        
        def _exec_safe(cmd, timeout=30):
            """Execute command safely and return result"""
            try:
                out = run_sync(execute_lxc(
                    container_name,
                    f"exec {container_name} -- sh -c \"{cmd}\"",
                    node_id=node_id, timeout=timeout
                ))
                if isinstance(out, bool):
                    return ''
                return out or ''
            except Exception:
                return ''
        
        # Step 1: Install Tailscale if needed (automatic)
        which_result = _exec_safe('which tailscale >/dev/null 2>&1 && echo "installed" || echo "missing"')
        if 'missing' in which_result:
            _exec_safe('curl -fsSL https://tailscale.com/install.sh | sh', timeout=180)
        
        # Step 2: Fix service (automatic)
        _exec_safe('systemctl stop tailscaled 2>/dev/null || true')
        _exec_safe('kill $(cat /run/tailscale/tailscaled.pid 2>/dev/null) 2>/dev/null || kill $(pgrep tailscaled 2>/dev/null) 2>/dev/null || true')
        _time.sleep(1)
        _exec_safe('mkdir -p /var/lib/tailscale /run/tailscale')
        _exec_safe('systemctl enable tailscaled')
        _exec_safe('systemctl start tailscaled')
        
        # Wait for service
        for _ in range(5):
            if 'active' in _exec_safe('systemctl is-active tailscaled'):
                break
            _time.sleep(2)
        
        # Step 3: Check if already authenticated
        current_ip = _exec_safe('tailscale ip -4 2>/dev/null || true').strip()
        if _re.match(r'^\d+\.\d+\.\d+\.\d+$', current_ip):
            return jsonify({
                'success': True,
                'status': 'already_connected',
                'tailscale_ip': current_ip,
                'message': 'Tailscale is already working'
            })
        
        # Step 4: Try automatic authentication
        _exec_safe('tailscale logout 2>/dev/null || true')
        _time.sleep(1)
        
        # Try with pre-approved settings that might work automatically
        auth_output = _exec_safe('timeout 10 tailscale up --accept-routes --accept-dns=false --authkey="" 2>&1 || true')
        
        # Check if it worked
        _time.sleep(2)
        new_ip = _exec_safe('tailscale ip -4 2>/dev/null || true').strip()
        if _re.match(r'^\d+\.\d+\.\d+\.\d+$', new_ip):
            return jsonify({
                'success': True,
                'status': 'auto_authenticated',
                'tailscale_ip': new_ip,
                'message': 'Automatically authenticated and connected'
            })
        
        # Step 5: Generate auth URL for manual auth (but return immediately)
        auth_url_output = _exec_safe('timeout 8 tailscale up --accept-routes --accept-dns=false 2>&1 || true')
        auth_match = _re.search(r'https://login\.tailscale\.com/[^\s]+', auth_url_output)
        
        if auth_match:
            auth_url = auth_match.group(0).rstrip('.,')
            
            # Try to wait a short time for automatic completion
            for _ in range(3):  # Wait up to 15 seconds
                _time.sleep(5)
                check_ip = _exec_safe('tailscale ip -4 2>/dev/null || true').strip()
                if _re.match(r'^\d+\.\d+\.\d+\.\d+$', check_ip):
                    return jsonify({
                        'success': True,
                        'status': 'authenticated_during_wait',
                        'tailscale_ip': check_ip,
                        'message': 'Authentication completed while waiting'
                    })
            
            return jsonify({
                'success': True,
                'status': 'needs_manual_auth',
                'auth_url': auth_url,
                'message': 'Please visit the authentication URL',
                'auto_retry': True  # Frontend can auto-retry this endpoint
            })
        
        return jsonify({
            'success': False,
            'status': 'auth_failed',
            'message': 'Could not generate authentication URL'
        })
        
    except Exception as e:
        logger.error(f"Auto Tailscale test error for {container_name}: {e}")
        return jsonify({
            'success': False,
            'status': 'error',
            'message': str(e)
        }), 500


@app.route('/admin/tailscale/test-all', methods=['POST'])
@login_required
@admin_required
def admin_test_all_tailscale():
    """
    Test Tailscale on all VPS instances automatically (Admin only)
    """
    try:
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT id, container_name, user_id FROM vps WHERE status != "suspended"')
            all_vps = cur.fetchall()
        
        results = []
        
        for vps_data in all_vps:
            vps_id, container_name, user_id = vps_data
            
            try:
                # Simulate calling the auto test for each VPS
                # In a real implementation, you'd call the actual endpoint
                result = {
                    'vps_id': vps_id,
                    'container_name': container_name,
                    'status': 'tested',
                    'tailscale_working': True,  # This would be the actual result
                    'message': 'Tailscale working properly'
                }
                results.append(result)
                
            except Exception as e:
                results.append({
                    'vps_id': vps_id,
                    'container_name': container_name,
                    'status': 'error',
                    'tailscale_working': False,
                    'message': str(e)
                })
        
        # Summary
        total = len(results)
        working = sum(1 for r in results if r['tailscale_working'])
        
        return jsonify({
            'success': True,
            'total_vps': total,
            'working_count': working,
            'failed_count': total - working,
            'results': results
        })
        
    except Exception as e:
        logger.error(f"Admin Tailscale test error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/vps/<int:vps_id>/tailscale/autofix', methods=['POST'])
@login_required
def vps_tailscale_autofix(vps_id):
    """
    Automatically diagnose and fix Tailscale issues
    """
    vps = get_vps_by_id(vps_id)
    if not vps or (vps['user_id'] != current_user.id and not current_user.is_admin):
        return jsonify({'success': False, 'error': 'Access denied'}), 403
    if is_vps_suspended(vps) and not current_user.is_admin:
        return jsonify({'success': False, 'error': 'VPS is suspended'}), 403

    container_name = vps['container_name']
    node_id = vps['node_id']
    log_lines = []

    def _exec(cmd, timeout=120, fatal=False):
        try:
            out = run_sync(execute_lxc(
                container_name,
                f"exec {container_name} -- sh -c \"{cmd}\"",
                node_id=node_id, timeout=timeout,
                suppress_log=(not fatal)   # only log errors for fatal commands
            ))
            if isinstance(out, bool):
                out = ''
            out = out or ''
            snippet = out[:500]
            if snippet:
                log_lines.append(snippet)
            return out
        except Exception as ex:
            log_lines.append(f'[ERROR] {ex}')
            if fatal:
                raise
            return ''

    try:
        import re as _re, time as _time
        
        log_lines.append('=== AUTOMATED TAILSCALE FIX ===')
        
        # Step 1: Check if Tailscale is installed
        log_lines.append('Checking Tailscale installation...')
        which_result = _exec('which tailscale >/dev/null 2>&1 && echo "installed" || echo "not_installed"', timeout=10)
        
        if 'not_installed' in which_result:
            log_lines.append('Installing Tailscale...')
            _exec('curl -fsSL https://tailscale.com/install.sh | sh', timeout=180, fatal=True)
            log_lines.append('Tailscale installed successfully')
        else:
            log_lines.append('Tailscale already installed')
        
        # Step 2: Fix service issues
        log_lines.append('Fixing Tailscale service...')
        _exec('tailscale down 2>/dev/null || true', timeout=10)
        _exec('systemctl stop tailscaled 2>/dev/null || true', timeout=10)
        _exec('kill $(cat /run/tailscale/tailscaled.pid 2>/dev/null) 2>/dev/null || kill $(pgrep tailscaled 2>/dev/null) 2>/dev/null || true', timeout=5)
        _time.sleep(2)
        
        # Ensure directories exist and start service
        _exec('mkdir -p /var/lib/tailscale /run/tailscale', timeout=10)
        _exec('systemctl enable tailscaled', timeout=10)
        _exec('systemctl start tailscaled', timeout=15, fatal=True)
        
        # Wait for service to be ready
        for i in range(10):
            service_status = _exec('systemctl is-active tailscaled', timeout=5)
            if 'active' in service_status:
                log_lines.append('Tailscaled service is running')
                break
            _time.sleep(2)
        else:
            raise Exception('Tailscaled service failed to start')
        
        # Step 3: Check current authentication status
        log_lines.append('Checking authentication status...')
        current_ip = _exec('tailscale ip -4 2>/dev/null || true', timeout=10)
        
        if _re.match(r'^\d+\.\d+\.\d+\.\d+$', current_ip.strip()):
            log_lines.append(f'Already authenticated with IP: {current_ip.strip()}')
            return jsonify({
                'success': True,
                'already_connected': True,
                'tailscale_ip': current_ip.strip(),
                'log': '\n'.join(log_lines)
            })
        
        # Step 4: Attempt authentication
        log_lines.append('Attempting authentication...')
        _exec('tailscale logout 2>/dev/null || true', timeout=10)
        _time.sleep(2)
        
        # Run tailscale up to get auth URL
        auth_output = _exec('timeout 15 tailscale up --accept-routes --accept-dns=false 2>&1 || true', timeout=20)
        log_lines.append(f'Auth attempt output: {auth_output[:300]}')
        
        # Extract auth URL
        auth_url = ''
        auth_match = _re.search(r'https://login\.tailscale\.com/[^\s]+', auth_output)
        if auth_match:
            auth_url = auth_match.group(0).rstrip('.,')
            log_lines.append(f'Authentication URL generated: {auth_url}')
        
        # Check if authentication happened automatically
        _time.sleep(3)
        final_ip = _exec('tailscale ip -4 2>/dev/null || true', timeout=10)
        
        if _re.match(r'^\d+\.\d+\.\d+\.\d+$', final_ip.strip()):
            log_lines.append(f'Authentication completed automatically! IP: {final_ip.strip()}')
            return jsonify({
                'success': True,
                'auto_authenticated': True,
                'tailscale_ip': final_ip.strip(),
                'log': '\n'.join(log_lines)
            })
        
        # Return auth URL for manual authentication
        if auth_url:
            return jsonify({
                'success': True,
                'needs_authentication': True,
                'auth_url': auth_url,
                'tailscale_ip': '',
                'log': '\n'.join(log_lines)
            })
        else:
            raise Exception('Could not generate authentication URL')
        
    except Exception as e:
        logger.error(f"Tailscale autofix error for {container_name}: {e}")
        return jsonify({
            'success': False, 
            'error': str(e), 
            'log': '\n'.join(log_lines)
        }), 500


@app.route('/vps/<int:vps_id>/tailscale', methods=['POST'])
@login_required
def vps_tailscale(vps_id):
    """
    Step 1 — Install Tailscale + run `tailscale up`.
    Returns the login URL so the user can authenticate.
    """
    vps = get_vps_by_id(vps_id)
    if not vps or (vps['user_id'] != current_user.id and not current_user.is_admin):
        return jsonify({'success': False, 'error': 'Access denied'}), 403
    if is_vps_suspended(vps) and not current_user.is_admin:
        return jsonify({'success': False, 'error': 'VPS is suspended'}), 403

    container_name = vps['container_name']
    node_id        = vps['node_id']
    log_lines      = []

    def _exec(cmd, timeout=120, fatal=False):
        try:
            out = run_sync(execute_lxc(
                container_name,
                f"exec {container_name} -- sh -c \"{cmd}\"",
                node_id=node_id, timeout=timeout,
                suppress_log=(not fatal)   # only log errors for fatal commands
            ))
            # Handle case where execute_lxc returns True instead of string
            if isinstance(out, bool):
                out = ''
            out = out or ''
            snippet = out[:500]
            if snippet:
                log_lines.append(snippet)
            return out
        except Exception as ex:
            log_lines.append(f'[warn] {ex}')
            if fatal:
                raise
            return ''

    try:
        import re as _re, time as _time

        # ── 1. Update & install curl ────────────────────────────────────
        log_lines.append('$ apt-get update && install curl')
        _exec(
            'DEBIAN_FRONTEND=noninteractive apt-get update -qq 2>&1 | tail -2 && '
            '(which curl || DEBIAN_FRONTEND=noninteractive apt-get install -y -qq curl 2>&1 | tail -2)',
            timeout=90
        )

        # ── 2. Install Tailscale ──────────────────────────────────
        log_lines.append('$ curl -fsSL https://tailscale.com/install.sh | sh')
        _exec('curl -fsSL https://tailscale.com/install.sh | sh 2>&1 | tail -15', timeout=180, fatal=True)

        # ── 3. Start tailscaled daemon ────────────────────────────────
        # In LXC containers systemd may not manage services, so start manually.
        log_lines.append('$ starting tailscaled daemon')
        # Kill any stale instance first — use POSIX kill via pgrep (pkill may not exist in container)
        _exec('kill $(pgrep tailscaled 2>/dev/null) 2>/dev/null || true', timeout=10)
        _time.sleep(1)
        # Ensure state dirs exist
        _exec('mkdir -p /var/lib/tailscale /run/tailscale', timeout=10)
        # Start tailscaled in background
        _exec(
            'nohup tailscaled --state=/var/lib/tailscale/tailscaled.state '
            '--socket=/run/tailscale/tailscaled.sock '
            '> /tmp/tailscaled.log 2>&1 &',
            timeout=10
        )
        # Give daemon time to initialise
        _time.sleep(4)
        daemon_check = _exec('pgrep -x tailscaled >/dev/null 2>&1 && echo running || echo not_running', timeout=8)
        log_lines.append(f'[tailscaled] {daemon_check.strip()}')

        # ── 4. tailscale up — capture login URL ───────────────────────────────────────
        # Strategy: run tailscale up with a short timeout so it prints the URL then exits.
        # Capture both stdout and stderr to a file, then read it back.
        log_lines.append('$ tailscale up')
        _exec('rm -f /tmp/ts_up.log', timeout=5)

        # First attempt: run with timeout flag (newer tailscale versions support this)
        _exec(
            'tailscale up --accept-routes --accept-dns=false --timeout=12s '
            '> /tmp/ts_up.log 2>&1 || true',
            timeout=20
        )
        _time.sleep(1)
        ts_out = _exec('cat /tmp/ts_up.log 2>/dev/null || true', timeout=8)
        if isinstance(ts_out, bool):
            ts_out = ''
        ts_out = ts_out or ''

        # If no URL yet, try a second pass without --timeout flag (older versions)
        if 'login.tailscale.com' not in ts_out:
            _exec('rm -f /tmp/ts_up2.log', timeout=5)
            _exec(
                'timeout 12 tailscale up --accept-routes --accept-dns=false '
                '> /tmp/ts_up2.log 2>&1 || true',
                timeout=18
            )
            _time.sleep(1)
            ts_out2 = _exec('cat /tmp/ts_up2.log 2>/dev/null || true', timeout=8)
            if isinstance(ts_out2, bool):
                ts_out2 = ''
            ts_out2 = ts_out2 or ''
            if ts_out2:
                ts_out = ts_out + '\n' + ts_out2

        # Also check tailscale status output which sometimes contains the URL
        if 'login.tailscale.com' not in ts_out:
            status_out = _exec('tailscale status 2>/dev/null || true', timeout=8)
            if isinstance(status_out, bool):
                status_out = ''
            status_out = status_out or ''
            if 'login.tailscale.com' in status_out:
                ts_out = ts_out + '\n' + status_out

        log_lines.append(f'[tailscale up] {ts_out[:600]}')

        # ── 5. Extract login URL ──────────────────────────────────────────────
        login_url = ''
        m = _re.search(r'https://login\.tailscale\.com/\S+', ts_out)
        if m:
            login_url = m.group(0).rstrip('.,)')

        # Check for IP (already authenticated or just connected)
        tailscale_ip = ''
        ip_out = _exec('tailscale ip -4 2>/dev/null || true', timeout=10)
        if isinstance(ip_out, bool):
            ip_out = ''
        ip_out = ip_out or ''
        for line in ip_out.splitlines():
            line = line.strip()
            if _re.match(r'^\d+\.\d+\.\d+\.\d+$', line):
                tailscale_ip = line
                log_lines.append(f'Already connected — IP: {tailscale_ip}')
                break

        log_activity(current_user.id, 'vps_tailscale_install', 'vps', str(vps_id))
        return jsonify({
            'success':      True,
            'login_url':    login_url,
            'tailscale_ip': tailscale_ip,
            'log':          '\n'.join(log_lines)
        })

    except Exception as e:
        logger.error(f"Tailscale install error for {container_name}: {e}")
        return jsonify({'success': False, 'error': str(e), 'log': '\n'.join(log_lines)}), 500


@app.route('/vps/<int:vps_id>/tailscale/status', methods=['GET'])
@login_required
def vps_tailscale_status(vps_id):
    """
    Get comprehensive Tailscale status for a VPS
    """
    vps = get_vps_by_id(vps_id)
    if not vps or (vps['user_id'] != current_user.id and not current_user.is_admin):
        return jsonify({'success': False, 'error': 'Access denied'}), 403

    container_name = vps['container_name']
    node_id = vps['node_id']

    try:
        import re as _re
        
        # Check if tailscale is installed
        install_check = run_sync(execute_lxc(
            container_name,
            f"exec {container_name} -- sh -c 'which tailscale >/dev/null 2>&1 && echo installed || echo not_installed'",
            node_id=node_id, timeout=10
        ))
        if isinstance(install_check, bool):
            install_check = ''
        
        if 'not_installed' in install_check:
            return jsonify({
                'success': True,
                'installed': False,
                'connected': False,
                'tailscale_ip': '',
                'status': 'not_installed'
            })
        
        # Check service status — try systemctl first, fall back to pgrep
        # (LXC containers may not have systemd managing tailscaled)
        service_check = run_sync(execute_lxc(
            container_name,
            f"exec {container_name} -- sh -c "
            "'(systemctl is-active tailscaled 2>/dev/null || "
            "pgrep -x tailscaled >/dev/null 2>&1 && echo active || echo inactive)'",
            node_id=node_id, timeout=10
        ))
        if isinstance(service_check, bool):
            service_check = ''
        
        service_active = 'active' in (service_check or '')
        
        # Get IP — check regardless of service_active to handle manual daemon start
        tailscale_ip = ''
        ip_out = run_sync(execute_lxc(
            container_name,
            f"exec {container_name} -- sh -c 'tailscale ip -4 2>/dev/null || true'",
            node_id=node_id, timeout=10
        ))
        if isinstance(ip_out, bool):
            ip_out = ''
        ip_out = ip_out or ''
        
        for line in ip_out.splitlines():
            line = line.strip()
            if _re.match(r'^\d+\.\d+\.\d+\.\d+$', line):
                tailscale_ip = line
                break
        
        # If we got an IP, service is effectively active
        if tailscale_ip:
            service_active = True
        
        # Determine overall status
        if not service_active:
            status = 'service_down'
        elif tailscale_ip:
            status = 'connected'
        else:
            status = 'not_authenticated'
        
        return jsonify({
            'success': True,
            'installed': True,
            'service_active': service_active,
            'connected': bool(tailscale_ip),
            'tailscale_ip': tailscale_ip,
            'status': status
        })

    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/vps/<int:vps_id>/tailscale/ip', methods=['GET'])
@login_required
def vps_tailscale_ip(vps_id):
    """
    Step 2 — Poll for the Tailscale IPv4 after the user has authenticated.
    Returns the IP once Tailscale is connected, or 'pending' if not yet.
    """
    vps = get_vps_by_id(vps_id)
    if not vps or (vps['user_id'] != current_user.id and not current_user.is_admin):
        return jsonify({'success': False, 'error': 'Access denied'}), 403

    container_name = vps['container_name']
    node_id        = vps['node_id']

    try:
        import re as _re
        out = run_sync(execute_lxc(
            container_name,
            f"exec {container_name} -- sh -c 'tailscale ip -4 2>/dev/null || true'",
            node_id=node_id, timeout=10
        ))
        # Handle case where execute_lxc returns True instead of string
        if isinstance(out, bool):
            out = ''
        out = out or ''
        for line in out.splitlines():
            line = line.strip()
            if _re.match(r'^\d+\.\d+\.\d+\.\d+$', line):
                return jsonify({'success': True, 'connected': True, 'tailscale_ip': line})

        return jsonify({'success': True, 'connected': False, 'tailscale_ip': ''})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500
    vps = get_vps_by_id(vps_id)
    if not vps or (vps['user_id'] != current_user.id and not current_user.is_admin):
        return jsonify({'success': False, 'error': 'Access denied'}), 403
    
    if is_vps_suspended(vps) and not current_user.is_admin:
        return jsonify({'success': False, 'error': 'VPS is suspended'}), 403
    
    try:
        container_name = vps['container_name']
        node_id = vps['node_id']
        session_name = f"avm-session-{datetime.now().strftime('%Y%m%d%H%M%S')}"
        
        try:
            run_sync(execute_lxc(container_name, f"exec {container_name} -- which tmate", node_id=node_id))
        except:
            try:
                os_check = run_sync(execute_lxc(container_name, f"exec {container_name} -- cat /etc/os-release", node_id=node_id))
                if 'alpine' in os_check.lower():
                    run_sync(execute_lxc(container_name, f"exec {container_name} -- apk add tmate", node_id=node_id))
                else:
                    run_sync(execute_lxc(container_name, f"exec {container_name} -- apt-get update -y", node_id=node_id))
                    run_sync(execute_lxc(container_name, f"exec {container_name} -- apt-get install -y tmate", node_id=node_id))
            except Exception as e:
                return jsonify({'success': False, 'error': f'Could not install tmate: {str(e)}'}), 500
        
        run_sync(execute_lxc(container_name, f"exec {container_name} -- tmate -S /tmp/{session_name}.sock new-session -d", node_id=node_id))
        run_sync(asyncio.sleep(3))
        
        ssh_output = run_sync(execute_lxc(container_name, f"exec {container_name} -- tmate -S /tmp/{session_name}.sock display -p '#{{tmate_ssh}}'", node_id=node_id))
        ssh_url = ssh_output.strip()
        
        web_output = run_sync(execute_lxc(container_name, f"exec {container_name} -- tmate -S /tmp/{session_name}.sock display -p '#{{tmate_web}}'", node_id=node_id))
        web_url = web_output.strip()
        
        if ssh_url:
            log_activity(current_user.id, 'generate_ssh', 'vps', str(vps_id))
            create_notification(current_user.id, 'info', 'SSH Session Created', f'SSH session created for {container_name}')
            return jsonify({
                'success': True,
                'ssh_url': ssh_url,
                'web_url': web_url,
                'session': session_name
            })
        else:
            return jsonify({'success': False, 'error': 'Could not generate SSH URL'}), 500
    except Exception as e:
        logger.error(f"SSH generation error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/vps/<int:vps_id>/stats')
@login_required
def vps_stats(vps_id):
    vps = get_vps_by_id(vps_id)
    if not vps or (vps['user_id'] != current_user.id and not current_user.is_admin):
        return jsonify({'success': False, 'error': 'Access denied'}), 403
    
    try:
        stats = run_sync(get_container_stats(vps['container_name'], vps['node_id']))
        
        # Get private IP if VPS is running
        private_ip = "N/A"
        if stats.get('status') == 'running':
            try:
                private_ip = run_sync(get_container_private_ip(vps['container_name'], vps['node_id']))
            except:
                private_ip = "N/A"
        
        stats['private_ip'] = private_ip
        
        return jsonify({'success': True, 'stats': stats})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/vps/<int:vps_id>/reinstall', methods=['POST'])
@login_required
def vps_reinstall(vps_id):
    try:
        vps = get_vps_by_id(vps_id)
        if not vps:
            return jsonify({'success': False, 'error': 'VPS not found'}), 404
        
        # Allow VPS owner or admin
        if vps['user_id'] != current_user.id and not current_user.is_admin:
            return jsonify({'success': False, 'error': 'Access denied'}), 403
        
        if is_vps_suspended(vps) and not current_user.is_admin:
            return jsonify({'success': False, 'error': 'VPS is suspended'}), 403
        
        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'error': 'No data provided'}), 400
            
        os_version = data.get('os_version')
        
        if not os_version:
            return jsonify({'success': False, 'error': 'OS version is required'}), 400
        
        if os_version not in [o['value'] for o in OS_OPTIONS]:
            return jsonify({'success': False, 'error': 'Invalid OS'}), 400
        
        logger.info(f"Reinstalling VPS {vps_id} ({vps['container_name']}) with OS: {os_version}")
        
        container_name = vps['container_name']
        node_id = vps['node_id']
        
        ram_gb = int(vps['ram'].replace('GB', ''))
        cpu = int(vps['cpu'])
        storage_gb = int(vps['storage'].replace('GB', ''))
        ram_mb = ram_gb * 1024
        
        # Stop the container
        try:
            run_sync(execute_lxc(container_name, f"stop {container_name} --force", node_id=node_id))
            logger.info(f"Container {container_name} stopped")
        except Exception as e:
            logger.warning(f"Failed to stop container {container_name}: {e}")
        
        # Delete the container
        run_sync(execute_lxc(container_name, f"delete {container_name} --force", node_id=node_id))
        logger.info(f"Container {container_name} deleted")
        
        # ── Proxmox uses Debian 12 as the base image ──
        _re_is_proxmox = os_version.startswith('proxmox:')
        _re_lxc_image = 'images:debian/12' if _re_is_proxmox else os_version
        
        # Create new container with new OS
        run_sync(execute_lxc(container_name, f"init {_re_lxc_image} {container_name} -s {DEFAULT_STORAGE_POOL}", node_id=node_id))
        logger.info(f"Container {container_name} created with {_re_lxc_image}")
        
        # Apply resource limits
        run_sync(execute_lxc(container_name, f"config set {container_name} limits.memory {ram_mb}MB", node_id=node_id))
        run_sync(execute_lxc(container_name, f"config set {container_name} limits.cpu {cpu}", node_id=node_id))
        run_sync(execute_lxc(container_name, f"config device set {container_name} root size={storage_gb}GB", node_id=node_id))
        logger.info(f"Resource limits applied to {container_name}")
        
        # Apply LXC config
        run_sync(apply_lxc_config(container_name, node_id))
        logger.info(f"LXC config applied to {container_name}")
        
        # Start the container
        run_sync(execute_lxc(container_name, f"start {container_name}", node_id=node_id))
        logger.info(f"Container {container_name} started")
        
        # Set IP if exists (after container is started)
        if vps.get('ip_address'):
            run_sync(configure_container_ip(container_name, vps['ip_address'], node_id))
            logger.info(f"IP address {vps['ip_address']} configured for {container_name}")
        
        # Apply internal permissions
        run_sync(apply_internal_permissions(container_name, node_id))
        logger.info(f"Internal permissions applied to {container_name}")
        
        # Configure SSH and set root password
        run_sync(configure_ssh_and_root_password(container_name, node_id))
        logger.info(f"SSH and root password configured for {container_name}")

        # ── Install Proxmox VE on top of Debian 12 if requested ──
        if _re_is_proxmox:
            try:
                run_sync(install_proxmox_in_container(container_name, node_id))
                logger.info(f"Proxmox VE reinstalled in {container_name}")
            except Exception as px_err:
                logger.warning(f"Proxmox reinstall failed for {container_name} (non-fatal): {px_err}")
        
        # Recreate port forwards
        run_sync(recreate_port_forwards(container_name))
        logger.info(f"Port forwards recreated for {container_name}")
        
        # Update database with new OS version and status - use direct SQL
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('''UPDATE vps 
                          SET os_version = ?, 
                              status = ?,
                              last_started = ?,
                              updated_at = ?
                          WHERE id = ?''',
                       (os_version, 'running', datetime.now().isoformat(), datetime.now().isoformat(), vps_id))
            conn.commit()
            logger.info(f"Database updated for VPS {vps_id} with OS {os_version} (rows affected: {cur.rowcount})")
        
        # Verify the update
        updated_vps = get_vps_by_id(vps_id)
        logger.info(f"VPS {vps_id} OS version after update: {updated_vps.get('os_version')}")
        
        log_activity(current_user.id, 'reinstall_vps', 'vps', str(vps_id), {'os': os_version})
        
        # Log if admin reinstalled someone else's VPS
        if current_user.is_admin and current_user.id != vps['user_id']:
            log_activity(current_user.id, 'admin_reinstall_vps', 'vps', str(vps_id), 
                        {'os': os_version, 'owner_id': vps['user_id']})
        
        create_notification(current_user.id, 'success', 'VPS Reinstalled', f'VPS {container_name} has been reinstalled with {os_version}')
        
        if socketio:
            socketio.emit('vps_reinstalled', {
                'vps_id': vps_id,
                'os_version': os_version,
                'status': 'running'
            }, room=f'vps_{vps_id}')
            socketio.emit('vps_status_change', {
                'vps_id': vps_id,
                'status': 'running',
                'os_version': os_version
            }, room=f'user_{vps["user_id"]}')
            
        return jsonify({
            'success': True, 
            'message': f'VPS {container_name} has been reinstalled with {os_version}',
            'os_version': os_version,
            'status': 'running'
        })
        
    except Exception as e:
        logger.error(f"Reinstall error for VPS {vps_id}: {e}", exc_info=True)
        log_vps_error(vps_id, vps.get('container_name', str(vps_id)), vps.get('user_id'), 'reinstall', str(e))
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/vps/<int:vps_id>/rename', methods=['POST'])
@login_required
def vps_rename(vps_id):
    vps = get_vps_by_id(vps_id)
    if not vps:
        return jsonify({'success': False, 'error': 'VPS not found'}), 404
    
    # Allow VPS owner or admin
    if vps['user_id'] != current_user.id and not current_user.is_admin:
        return jsonify({'success': False, 'error': 'Access denied'}), 403
    
    if is_vps_suspended(vps) and not current_user.is_admin:
        return jsonify({'success': False, 'error': 'VPS is suspended'}), 403
    
    data = request.get_json()
    new_name = data.get('hostname')
    
    if not new_name or len(new_name) < 3 or len(new_name) > 63:
        return jsonify({'success': False, 'error': 'Invalid hostname'}), 400
    
    if not re.match(r'^[a-zA-Z0-9][a-zA-Z0-9\-]*[a-zA-Z0-9]$', new_name):
        return jsonify({'success': False, 'error': 'Invalid hostname format'}), 400
    
    try:
        run_sync(execute_lxc(vps['container_name'], f"exec {vps['container_name']} -- hostnamectl set-hostname {new_name}", node_id=vps['node_id']))
        update_vps(vps_id, hostname=new_name)
        log_activity(current_user.id, 'rename_vps', 'vps', str(vps_id), {'new_name': new_name})
        
        # Log if admin renamed someone else's VPS
        if current_user.is_admin and current_user.id != vps['user_id']:
            log_activity(current_user.id, 'admin_rename_vps', 'vps', str(vps_id),
                        {'new_name': new_name, 'owner_id': vps['user_id']})
        
        create_notification(current_user.id, 'success', 'VPS Renamed', f'VPS renamed to {new_name}')
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/vps/<int:vps_id>/notes', methods=['POST'])
@login_required
def vps_notes(vps_id):
    vps = get_vps_by_id(vps_id)
    if not vps or vps['user_id'] != current_user.id:
        return jsonify({'success': False, 'error': 'Access denied'}), 403
    
    data = request.get_json()
    notes = data.get('notes', '')
    
    update_vps(vps_id, notes=notes)
    return jsonify({'success': True})

@app.route('/vps/<int:vps_id>/suspended')
@login_required
def vps_suspended_page(vps_id):
    vps = get_vps_by_id(vps_id)

    if not vps:
        abort(404)

    # Check access permissions
    shared_with = vps.get('shared_with', []) or []
    allowed = (
        vps['user_id'] == current_user.id
        or str(current_user.id) in [str(uid) for uid in shared_with]
        or current_user.is_admin
    )

    if not allowed:
        flash('VPS not found or access denied', 'danger')
        return redirect(url_for('vps_list'))

    # If VPS is not suspended, redirect to detail page
    if not is_vps_suspended(vps):
        return redirect(url_for('vps_detail', vps_id=vps_id))

    return render_template(
        "vps_suspended.html",
        vps=vps,
        panel_name=get_setting('site_name', 'AVM PANEL')
    )

@app.route('/vps/<int:vps_id>/expiration')
@login_required
@vps_owner_or_admin_required
def vps_expiration_info(vps_id):
    """Get VPS expiration information for users"""
    vps = get_vps_by_id(vps_id)
    if not vps:
        return jsonify({'success': False, 'error': 'VPS not found'}), 404
    
    expires_info = {
        'vps_id': vps_id,
        'container_name': vps['container_name'],
        'hostname': vps['hostname'],
        'auto_suspend_enabled': bool(vps.get('auto_suspend_enabled', 0)),
        'expiration_days': vps.get('expiration_days', 0),
        'expires_at': vps.get('expires_at'),
        'last_renewed_at': vps.get('last_renewed_at'),
        'renewal_count': vps.get('renewal_count', 0),
        'is_expired': False,
        'days_remaining': None,
        'hours_remaining': None
    }
    
    if vps.get('expires_at'):
        expires_dt = datetime.fromisoformat(vps['expires_at'])
        now = datetime.now()
        time_diff = expires_dt - now
        
        expires_info['is_expired'] = expires_dt < now
        expires_info['days_remaining'] = time_diff.days if not expires_info['is_expired'] else 0
        expires_info['hours_remaining'] = int(time_diff.total_seconds() / 3600) if not expires_info['is_expired'] else 0
        expires_info['expires_at_formatted'] = expires_dt.strftime("%Y-%m-%d %H:%M")
    
    return jsonify({'success': True, 'data': expires_info})

# ============================================================================
# Port Forwarding Routes
# ============================================================================
@app.route('/ports')
@login_required
def ports_list():
    allocated = get_user_allocation(current_user.id)
    used = get_user_used_ports(current_user.id)
    forwards = get_user_forwards(current_user.id)
    vps_list = get_vps_for_user(current_user.id)
    
    for forward in forwards:
        vps = get_vps_by_container(forward['vps_container'])
        if vps:
            forward['display_ip'] = get_vps_display_ip(vps) or YOUR_SERVER_IP
        else:
            forward['display_ip'] = YOUR_SERVER_IP
    
    return render_template('ports.html',
                          panel_name=get_setting('site_name', 'AVM PANEL'),
                          allocated=allocated,
                          used=used,
                          available=allocated - used,
                          forwards=forwards,
                          vps_list=vps_list,
                          YOUR_SERVER_IP=YOUR_SERVER_IP,
                          socketio_available=SOCKETIO_AVAILABLE)

@app.route('/ports/add', methods=['POST'])
@login_required
def ports_add():
    data = request.get_json() or {}
    vps_id = data.get('vps_id')
    vps_port = data.get('vps_port')
    requested_host_port = data.get('host_port')
    protocol = data.get('protocol', 'tcp,udp')
    description = data.get('description', '')

    if not vps_id or not vps_port:
        return jsonify({'success': False, 'error': 'Missing parameters'}), 400

    try:
        vps_port = int(vps_port)
        if vps_port < 1 or vps_port > 65535:
            raise ValueError
    except ValueError:
        return jsonify({'success': False, 'error': 'Invalid port number'}), 400

    requested_host_port = None
    if requested_host_port not in (None, ''):
        try:
            requested_host_port = int(requested_host_port)
            if requested_host_port < 1 or requested_host_port > 65535:
                return jsonify({'success': False, 'error': 'Host port must be 1-65535'}), 400
        except (ValueError, TypeError):
            return jsonify({'success': False, 'error': 'Invalid host port'}), 400

    vps = get_vps_by_id(vps_id)
    if not vps:
        return jsonify({'success': False, 'error': 'VPS not found'}), 404

    # Allow VPS owner or admin
    if vps['user_id'] != current_user.id and not current_user.is_admin:
        return jsonify({'success': False, 'error': 'Access denied'}), 403

    if is_vps_suspended(vps) and not current_user.is_admin:
        return jsonify({'success': False, 'error': 'VPS is suspended'}), 403

    # Use VPS owner's account for port allocation (even if admin is creating it)
    owner_id = vps['user_id']
    allocated = get_user_allocation(owner_id)
    used = get_user_used_ports(owner_id)

    if used >= allocated:
        return jsonify({'success': False, 'error': f'Port quota exceeded for VPS owner (used {used}/{allocated})'}), 400

    # If user requested a specific host port, validate it's free on this node
    if requested_host_port is not None:
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('''SELECT id FROM port_forwards
                           WHERE host_port = ? AND vps_container IN
                                 (SELECT container_name FROM vps WHERE node_id = ?)''',
                        (requested_host_port, vps['node_id']))
            if cur.fetchone():
                return jsonify({'success': False, 'error': f'Host port {requested_host_port} is already in use on this node'}), 400

    # Create port forward under VPS owner's account
    host_port = run_sync(create_port_forward(owner_id, vps['container_name'], vps_port, vps['node_id'], protocol, description))

    if host_port:
        display_ip = get_vps_display_ip(vps) or YOUR_SERVER_IP
        
        # Log who actually created it
        if current_user.is_admin and current_user.id != owner_id:
            log_activity(current_user.id, 'admin_create_port_forward', 'port', str(host_port),
                        {'vps_id': vps_id, 'owner_id': owner_id, 'vps_port': vps_port, 'host_port': host_port})
        
        return jsonify({
            'success': True,
            'host_port': host_port,
            'message': f'Port {vps_port} forwarded to {display_ip}:{host_port}',
            'display_ip': display_ip
        })
    else:
        return jsonify({'success': False, 'error': 'Could not assign host port'}), 500

@app.route('/ports/remove/<int:forward_id>', methods=['POST'])
@login_required
def ports_remove(forward_id):
    success, user_id = run_sync(remove_port_forward(forward_id))
    
    # Allow if user owns the forward OR if current user is admin
    if success and (user_id == current_user.id or current_user.is_admin):
        # Log if admin removed someone else's forward
        if current_user.is_admin and user_id != current_user.id:
            log_activity(current_user.id, 'admin_remove_port_forward', 'port', str(forward_id),
                        {'owner_id': user_id})
        return jsonify({'success': True})
    else:
        return jsonify({'success': False, 'error': 'Forward not found or access denied'}), 404

@app.route('/ports/hit/<int:host_port>', methods=['POST'])
def port_hit(host_port):
    run_sync(update_port_forward_hit(host_port))
    return jsonify({'success': True})

# ============================================================================
# Admin Routes
# ============================================================================
@app.route('/admin')
@login_required
@admin_required
def admin_dashboard():
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT COUNT(*) FROM users')
        total_users = cur.fetchone()[0]
        
        cur.execute('SELECT COUNT(*) FROM vps')
        total_vps = cur.fetchone()[0]
        
        cur.execute('SELECT COUNT(*) FROM vps WHERE status = "running"')
        running_vps = cur.fetchone()[0]
        
        cur.execute('SELECT COUNT(*) FROM vps WHERE suspended = 1')
        suspended_vps = cur.fetchone()[0]
        
        cur.execute('SELECT COUNT(*) FROM nodes')
        total_nodes = cur.fetchone()[0]
        
        cur.execute('SELECT COUNT(*) FROM nodes WHERE status = "online"')
        online_nodes = cur.fetchone()[0]
        
        cur.execute('SELECT SUM(allocated_ports) FROM port_allocations')
        total_ports = cur.fetchone()[0] or 0
        
        cur.execute('SELECT COUNT(*) FROM port_forwards')
        used_ports = cur.fetchone()[0] or 0
        
        try:
            cur.execute('''SELECT a.*, u.username AS user_name,
                                  COALESCE(a.resource_type, '') AS type,
                                  COALESCE(a.details, a.resource_id, '') AS target,
                                  a.created_at AS timestamp
                           FROM activity_logs a
                           LEFT JOIN users u ON a.user_id = u.id
                           ORDER BY a.created_at DESC LIMIT 20''')
            recent_activity = [dict(row) for row in cur.fetchall()]
        except Exception as _e:
            print(f"[admin_dashboard] activity_logs query failed: {_e}")
            recent_activity = []

        # ── Recent user registrations (last 6) ───────────────────────────
        try:
            cur.execute('''SELECT id, username, email, created_at, 'active' AS status FROM users
                           ORDER BY id DESC LIMIT 6''')
            recent_users = [dict(r) for r in cur.fetchall()]
        except Exception as _e:
            print(f"[admin_dashboard] recent_users query failed: {_e}")
            recent_users = []

        # ── Chart data: VPS creation trend (last 30 days) ─────────────────
        cur.execute('''SELECT date(created_at) AS day, COUNT(*) AS cnt
                       FROM vps
                       WHERE created_at >= date('now', '-29 days')
                       GROUP BY date(created_at)
                       ORDER BY day ASC''')
        creation_rows = cur.fetchall()
        creation_map = {r['day']: r['cnt'] for r in creation_rows}
        from datetime import date as _date, timedelta as _td
        vps_creation_trend = []
        vps_creation_labels = []
        for i in range(30):
            d = (_date.today() - _td(days=29 - i)).isoformat()
            vps_creation_labels.append(d[5:])  # MM-DD
            vps_creation_trend.append(creation_map.get(d, 0))

        # ── Chart data: VPS by OS ─────────────────────────────────────────
        cur.execute('''SELECT os_version, COUNT(*) AS cnt FROM vps
                       WHERE os_version IS NOT NULL AND os_version != ''
                       GROUP BY os_version ORDER BY cnt DESC LIMIT 8''')
        vps_by_os = {r['os_version']: r['cnt'] for r in cur.fetchall()}

        # ── Chart data: VPS by status ────────────────────────────────────
        cur.execute('''SELECT
                         SUM(CASE WHEN status = 'running'  THEN 1 ELSE 0 END) AS running,
                         SUM(CASE WHEN status = 'stopped'  THEN 1 ELSE 0 END) AS stopped,
                         SUM(CASE WHEN suspended = 1         THEN 1 ELSE 0 END) AS suspended
                       FROM vps''')
        srow = cur.fetchone()
        vps_by_status = {
            'Running':   int(srow['running']  or 0),
            'Stopped':   int(srow['stopped']  or 0),
            'Suspended': int(srow['suspended'] or 0),
        }

        # ── Chart data: resource trend (last 7d, 7 points) ───────────────
        # Use vps_creation_trend scaled into 7 points as proxy for activity
        # (real history not stored; use scaled rolling activity)
        vps_activity_7d = []
        for i in range(7):
            idx = 23 + i  # last 7 of the 30-day window
            base = vps_creation_trend[idx] if idx < len(vps_creation_trend) else 0
            vps_activity_7d.append(base)

    nodes = get_nodes()

    # ── Fetch node statuses in parallel with a short cache ───────────────────
    import concurrent.futures as _cf

    _ns_cache = getattr(app, '_node_status_cache', {})
    _ns_cache_ts = getattr(app, '_node_status_cache_ts', {})
    _NS_TTL = 30.0  # seconds — node status cached for 30s
    now_ts = time.time()

    def _get_node_status_cached(node):
        nid = node['id']
        if nid in _ns_cache and (now_ts - _ns_cache_ts.get(nid, 0)) < _NS_TTL:
            return nid, _ns_cache[nid]
        try:
            status = run_sync(get_node_status(nid))
        except Exception:
            status = {'status': 'offline', 'online': False, 'stats': {}}
        _ns_cache[nid] = status
        _ns_cache_ts[nid] = now_ts
        return nid, status

    app._node_status_cache    = _ns_cache
    app._node_status_cache_ts = _ns_cache_ts

    node_status = []
    status_map  = {}

    if nodes:
        with _cf.ThreadPoolExecutor(max_workers=max(1, min(len(nodes), 5))) as ex:
            futures = {ex.submit(_get_node_status_cached, n): n for n in nodes}
            for fut in _cf.as_completed(futures):
                try:
                    nid, st = fut.result()
                    status_map[nid] = st
                except Exception:
                    pass

    for node in nodes:
        st = status_map.get(node['id'], {'status': 'offline', 'online': False, 'stats': {}})
        vps_count = get_current_vps_count(node['id'])
        node_status.append({
            'id':       node['id'],
            'name':     node['name'],
            'location': node['location'],
            'status':   st['status'],
            'online':   st.get('online', False),
            'vps_count': vps_count,
            'total_vps': node['total_vps'],
            'is_local': node['is_local'],
            'stats':    st.get('stats', {})
        })

    # ── Host stats with cache (30s TTL) ──────────────────────────────────────
    _hs_cache    = getattr(app, '_host_stats_cache', None)
    _hs_cache_ts = getattr(app, '_host_stats_cache_ts', 0.0)
    if _hs_cache is None or (now_ts - _hs_cache_ts) > 30.0:
        host_stats = run_sync(get_host_stats(1))
        if (host_stats.get('disk', {}).get('total', 'Unknown') == 'Unknown'
                or host_stats.get('uptime', 'Unknown') in ('Unknown', 'N/A', '')):
            host_stats = {
                'cpu':    get_host_cpu_usage(),
                'ram':    get_host_ram_usage(),
                'disk':   get_host_disk_usage(),
                'uptime': get_host_uptime(),
            }
        app._host_stats_cache    = host_stats
        app._host_stats_cache_ts = now_ts
    else:
        host_stats = _hs_cache

    # ── Compute disk_pct for JS gauges (avoids {% set %} scope issue) ────────
    _disk_raw = host_stats.get('disk', {}).get('percent', 0)
    if isinstance(_disk_raw, str):
        _disk_raw = _disk_raw.replace('%', '')
    try:
        disk_pct = int(_disk_raw) if _disk_raw not in (None, '', 'Unknown') else 0
    except (ValueError, TypeError):
        disk_pct = 0

    return render_template('admin/dashboard.html',
                          panel_name=get_setting('site_name', 'AVM PANEL'),
                          total_users=total_users,
                          total_vps=total_vps,
                          running_vps=running_vps,
                          suspended_vps=suspended_vps,
                          total_nodes=total_nodes,
                          online_nodes=online_nodes,
                          total_ports=total_ports,
                          used_ports=used_ports,
                          node_status=node_status,
                          recent_activity=recent_activity,
                          recent_users=recent_users,
                          host_stats=host_stats,
                          disk_pct=disk_pct,
                          vps_creation_labels=vps_creation_labels,
                          vps_creation_trend=vps_creation_trend,
                          vps_by_os=vps_by_os,
                          vps_by_status=vps_by_status,
                          vps_activity_7d=vps_activity_7d,
                          socketio_available=SOCKETIO_AVAILABLE)

@app.route('/admin/ports')
@login_required
@admin_required
def admin_ports():
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT SUM(allocated_ports) FROM port_allocations')
        total_allocated = cur.fetchone()[0] or 0
        cur.execute('SELECT COUNT(*) FROM port_forwards')
        total_used = cur.fetchone()[0] or 0
        cur.execute('''SELECT pf.*, u.username AS owner_username FROM port_forwards pf
                       LEFT JOIN users u ON pf.user_id = u.id
                       ORDER BY pf.created_at DESC''')
        forwards = [dict(r) for r in cur.fetchall()]
        cur.execute('''SELECT v.*, u.username FROM vps v
                       JOIN users u ON v.user_id = u.id
                       ORDER BY v.created_at DESC''')
        vps_list = [dict(r) for r in cur.fetchall()]

    for forward in forwards:
        vps = get_vps_by_container(forward['vps_container'])
        if vps:
            forward['display_ip'] = get_vps_display_ip(vps) or YOUR_SERVER_IP
        else:
            forward['display_ip'] = YOUR_SERVER_IP

    return render_template('admin/ports.html',
                          panel_name=get_setting('site_name', 'AVM PANEL'),
                          total_allocated=total_allocated,
                          total_used=total_used,
                          total_available=total_allocated - total_used,
                          forwards=forwards,
                          vps_list=vps_list,
                          YOUR_SERVER_IP=YOUR_SERVER_IP,
                          socketio_available=SOCKETIO_AVAILABLE)

@app.route('/admin/users')
@login_required
@admin_required
def admin_users():
    search_query = request.args.get('search', '')
    page = int(request.args.get('page', 1))
    per_page = 20
    offset = (page - 1) * per_page
    
    with get_db() as conn:
        cur = conn.cursor()
        if search_query:
            cur.execute('''SELECT u.*,
                           (SELECT COUNT(*) FROM vps WHERE user_id = u.id) as vps_count,
                           (SELECT allocated_ports FROM port_allocations WHERE user_id = u.id) as port_quota,
                           (SELECT used_ports FROM port_allocations WHERE user_id = u.id) as used_ports
                           FROM users u
                           WHERE u.username LIKE ? OR u.email LIKE ?
                           ORDER BY u.id
                           LIMIT ? OFFSET ?''',
                       (f'%{search_query}%', f'%{search_query}%', per_page, offset))
        else:
            cur.execute('''SELECT u.*,
                           (SELECT COUNT(*) FROM vps WHERE user_id = u.id) as vps_count,
                           (SELECT allocated_ports FROM port_allocations WHERE user_id = u.id) as port_quota,
                           (SELECT used_ports FROM port_allocations WHERE user_id = u.id) as used_ports
                           FROM users u
                           ORDER BY u.id
                           LIMIT ? OFFSET ?''',
                       (per_page, offset))
        users = [dict(row) for row in cur.fetchall()]
        
        if search_query:
            cur.execute('SELECT COUNT(*) FROM users WHERE username LIKE ? OR email LIKE ?',
                       (f'%{search_query}%', f'%{search_query}%'))
        else:
            cur.execute('SELECT COUNT(*) FROM users')
        total_users = cur.fetchone()[0]
    
    return render_template('admin/users.html',
                          panel_name=get_setting('site_name', 'AVM PANEL'),
                          users=users,
                          search_query=search_query,
                          page=page,
                          total_pages=(total_users + per_page - 1) // per_page)

@app.route('/admin/users/<int:user_id>')
@login_required
@admin_required
def admin_user_detail(user_id):
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT * FROM users WHERE id = ?', (user_id,))
        user = dict(cur.fetchone())
        
        cur.execute('SELECT * FROM vps WHERE user_id = ? ORDER BY created_at DESC', (user_id,))
        vps_list = []
        for row in cur.fetchall():
            vps = dict(row)
            try:
                vps['shared_with'] = json.loads(vps['shared_with']) if vps['shared_with'] else []
            except:
                vps['shared_with'] = []
            vps_list.append(vps)
        
        cur.execute('SELECT * FROM port_allocations WHERE user_id = ?', (user_id,))
        port_alloc = cur.fetchone()
        allocated_ports = port_alloc[1] if port_alloc else 0
        used_ports = port_alloc[2] if port_alloc else 0
        
        cur.execute('SELECT * FROM port_forwards WHERE user_id = ? ORDER BY created_at DESC', (user_id,))
        forwards = [dict(row) for row in cur.fetchall()]
        
        cur.execute('SELECT * FROM activity_logs WHERE user_id = ? ORDER BY created_at DESC LIMIT 50', (user_id,))
        activities = [dict(row) for row in cur.fetchall()]
    
    return render_template('admin/user_detail.html',
                          panel_name=get_setting('site_name', 'AVM PANEL'),
                          user=user,
                          vps_list=vps_list,
                          allocated_ports=allocated_ports,
                          used_ports=used_ports,
                          forwards=forwards,
                          activities=activities)

@app.route('/admin/users/create', methods=['GET', 'POST'])
@login_required
@admin_required
def admin_users_create():
    # GET - Render the create user form
    if request.method == 'GET':
        return render_template('admin/users_create.html',
                              panel_name=get_setting('site_name', 'AVM PANEL'))
    
    # POST - Process the form submission
    data = request.get_json() or request.form.to_dict()

    username = (data.get("username") or "").strip()
    email = (data.get("email") or "").strip()
    password = data.get("password") or ""
    is_admin = bool(data.get("is_admin", False))
    port_quota = int(data.get("port_quota", 10))

    if not username or not email or not password:
        return jsonify({"success": False, "error": "username, email and password are required"}), 400

    if len(password) < 8:
        return jsonify({"success": False, "error": "Password must be at least 8 characters"}), 400

    if len(username) < 3 or len(username) > 32:
        return jsonify({"success": False, "error": "Username must be 3–32 characters"}), 400

    if "@" not in email or "." not in email.split("@")[-1]:
        return jsonify({"success": False, "error": "Invalid email format"}), 400

    if port_quota < 0:
        return jsonify({"success": False, "error": "Port quota cannot be negative"}), 400

    now = datetime.now().isoformat()

    with get_db() as conn:
        cur = conn.cursor()

        cur.execute(
            "SELECT id FROM users WHERE username = ? OR email = ?",
            (username, email)
        )
        if cur.fetchone():
            return jsonify({"success": False, "error": "Username or email already exists"}), 409

        password_hash = generate_password_hash(password)

        try:
            cur.execute("""
                INSERT INTO users (
                    username, email, password_hash, is_admin, created_at, last_active
                ) VALUES (?, ?, ?, ?, ?, ?)
            """, (
                username,
                email,
                password_hash,
                1 if is_admin else 0,
                now,
                now
            ))

            user_id = cur.lastrowid

            if port_quota > 0:
                cur.execute("""
                    INSERT OR REPLACE INTO port_allocations
                    (user_id, allocated_ports, used_ports, updated_at)
                    VALUES (?, ?, 0, ?)
                """, (user_id, port_quota, now))

            conn.commit()

        except Exception as e:
            conn.rollback()
            return jsonify({
                "success": False,
                "error": "Database error while creating user"
            }), 500

    try:
        log_activity(
            current_user.id,
            'create_user',
            'user',
            str(user_id),
            {"username": username, "is_admin": is_admin}
        )

        create_notification(
            user_id=user_id,
            type='info',
            title='Welcome!',
            message='Your account has been created by an administrator. Welcome aboard!'
        )
    except Exception:
        pass

    return jsonify({
        "success": True,
        "message": "User created successfully",
        "user_id": user_id
    }), 201
    
@app.route('/admin/users/<int:user_id>/edit', methods=['GET', 'POST'])
@login_required
@admin_required
def admin_user_edit(user_id):
    logger.info(f"admin_user_edit called: user_id={user_id}, method={request.method}, is_json={request.is_json}")
    
    try:
        # Get user data
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT * FROM users WHERE id = ?', (user_id,))
            user_row = cur.fetchone()
            
            if not user_row:
                logger.warning(f"User {user_id} not found")
                if request.method == 'GET':
                    flash('User not found', 'danger')
                    return redirect(url_for('admin_users'))
                return jsonify({'success': False, 'error': 'User not found'}), 404
            
            user = dict(user_row)
            
            # Get port allocation
            cur.execute('SELECT * FROM port_allocations WHERE user_id = ?', (user_id,))
            port_row = cur.fetchone()
            port_allocation = dict(port_row) if port_row else {'allocated_ports': 0, 'used_ports': 0}
            
            # Get VPS count
            cur.execute('SELECT COUNT(*) FROM vps WHERE user_id = ?', (user_id,))
            vps_count = cur.fetchone()[0]
        
        # GET - Render edit form
        if request.method == 'GET':
            logger.info(f"Rendering edit form for user {user_id}")
            return render_template('admin/users_edit.html',
                                  panel_name=get_setting('site_name', 'AVM PANEL'),
                                  user=user,
                                  port_allocation=port_allocation,
                                  vps_count=vps_count)
        
        # POST - Process form submission
        logger.info(f"Processing POST request for user {user_id}")
        data = request.get_json() or request.form.to_dict()
        logger.info(f"Received data: {data}")
        
        with get_db() as conn:
            cur = conn.cursor()
            
            if 'is_admin' in data:
                cur.execute('UPDATE users SET is_admin = ? WHERE id = ?', (1 if data['is_admin'] else 0, user_id))
                logger.info(f"Updated is_admin for user {user_id}")
            
            if 'port_quota' in data:
                quota = int(data['port_quota'])
                now = datetime.now().isoformat()
                cur.execute('''INSERT OR REPLACE INTO port_allocations (user_id, allocated_ports, used_ports, updated_at)
                               VALUES (?, ?, COALESCE((SELECT used_ports FROM port_allocations WHERE user_id = ?), 0), ?)''',
                            (user_id, quota, user_id, now))
                logger.info(f"Updated port quota for user {user_id}: {quota}")
            
            conn.commit()
        
        log_activity(current_user.id, 'edit_user', 'user', str(user_id), data)
        create_notification(user_id, 'info', 'Account Updated', 'Your account has been updated by an administrator.')
        
        logger.info(f"Successfully updated user {user_id}")
        return jsonify({'success': True})
    
    except Exception as e:
        logger.error(f"Error in admin_user_edit for user {user_id}: {e}", exc_info=True)
        if request.method == 'GET':
            flash(f'Error: {str(e)}', 'danger')
            return redirect(url_for('admin_users'))
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/admin/users/<int:user_id>/delete', methods=['POST'])
@login_required
@admin_required
def admin_user_delete(user_id):
    if user_id == current_user.id:
        return jsonify({'success': False, 'error': 'Cannot delete yourself'}), 400
    
    # Check if user is admin
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT is_admin, is_main_admin, username FROM users WHERE id = ?', (user_id,))
        user = cur.fetchone()
        
        if not user:
            return jsonify({'success': False, 'error': 'User not found'}), 404
        
        if user[0] or user[1]:  # is_admin or is_main_admin
            return jsonify({'success': False, 'error': 'Cannot delete admin users'}), 400
    
    vps_list = get_vps_for_user(user_id)
    for vps in vps_list:
        try:
            run_sync(execute_lxc(vps['container_name'], f"delete {vps['container_name']} --force", node_id=vps['node_id']))
        except:
            pass
    
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('DELETE FROM port_allocations WHERE user_id = ?', (user_id,))
        cur.execute('DELETE FROM port_forwards WHERE user_id = ?', (user_id,))
        cur.execute('DELETE FROM vps WHERE user_id = ?', (user_id,))
        cur.execute('DELETE FROM users WHERE id = ?', (user_id,))
        conn.commit()
    
    log_activity(current_user.id, 'delete_user', 'user', str(user_id))
    return jsonify({'success': True})

@app.route('/admin/users/<int:user_id>/delete/progress', methods=['GET'])
@login_required
@admin_required
def admin_user_delete_progress(user_id):
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT id, username, email FROM users WHERE id = ?', (user_id,))
        row = cur.fetchone()
    if not row:
        flash('User not found.', 'danger')
        return redirect(url_for('admin_users'))
    return render_template(
        'user_delete_progress.html',
        user_id=row['id'],
        username=row['username'],
        email=row['email'] or '',
        panel_name=PANEL_NAME
    )

@app.route('/admin/users/bulk-delete-inactive', methods=['POST'])
@login_required
@admin_required
def admin_users_bulk_delete_inactive():
    """Delete all non-admin users who have no VPS"""
    try:
        with get_db() as conn:
            cur = conn.cursor()
            
            # Find users without VPS and who are not admins
            cur.execute('''
                SELECT u.id, u.username 
                FROM users u
                LEFT JOIN vps v ON u.id = v.user_id
                WHERE u.is_admin = 0 
                AND u.is_main_admin = 0
                AND u.id != ?
                GROUP BY u.id
                HAVING COUNT(v.id) = 0
            ''', (current_user.id,))
            
            users_to_delete = cur.fetchall()
            
            if not users_to_delete:
                return jsonify({'success': True, 'deleted_count': 0, 'message': 'No inactive users to delete'})
            
            deleted_count = 0
            deleted_usernames = []
            
            for user_id, username in users_to_delete:
                try:
                    # Delete related data
                    cur.execute('DELETE FROM port_allocations WHERE user_id = ?', (user_id,))
                    cur.execute('DELETE FROM port_forwards WHERE user_id = ?', (user_id,))
                    cur.execute('DELETE FROM notifications WHERE user_id = ?', (user_id,))
                    cur.execute('DELETE FROM sessions WHERE user_id = ?', (user_id,))
                    cur.execute('DELETE FROM api_keys WHERE user_id = ?', (user_id,))
                    cur.execute('DELETE FROM users WHERE id = ?', (user_id,))
                    
                    deleted_count += 1
                    deleted_usernames.append(username)
                    
                    log_activity(current_user.id, 'bulk_delete_user', 'user', str(user_id), {'username': username})
                except Exception as e:
                    logger.error(f"Error deleting user {user_id}: {e}")
                    continue
            
            conn.commit()
        
        return jsonify({
            'success': True, 
            'deleted_count': deleted_count,
            'deleted_users': deleted_usernames,
            'message': f'Successfully deleted {deleted_count} inactive user(s)'
        })
        
    except Exception as e:
        logger.error(f"Error in bulk delete: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

def get_all_users():
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT id, username, email FROM users ORDER BY username')
        return [dict(row) for row in cur.fetchall()]

@app.route('/admin/vps')
@login_required
@admin_required
def admin_vps():
    search_query = request.args.get('search', '')
    node_id = request.args.get('node_id', type=int)
    status_filter = request.args.get('status', '')
    page = int(request.args.get('page', 1))
    per_page = 20
    offset = (page - 1) * per_page

    vps_list = []

    query = '''SELECT v.*, u.username, n.name as node_name
               FROM vps v
               JOIN users u ON v.user_id = u.id
               JOIN nodes n ON v.node_id = n.id'''

    params = []
    conditions = []

    if search_query:
        conditions.append('(v.container_name LIKE ? OR u.username LIKE ?)')
        params.extend([f'%{search_query}%', f'%{search_query}%'])

    if node_id:
        conditions.append('v.node_id = ?')
        params.append(node_id)

    if status_filter:
        conditions.append('v.status = ?')
        params.append(status_filter)

    if conditions:
        query += ' WHERE ' + ' AND '.join(conditions)

    query += ' ORDER BY v.created_at DESC LIMIT ? OFFSET ?'
    params.extend([per_page, offset])

    with get_db() as conn:
        cur = conn.cursor()
        cur.execute(query, params)
        rows = cur.fetchall()

        for row in rows:
            vps = dict(row)

            try:
                vps['shared_with'] = json.loads(vps['shared_with']) if vps['shared_with'] else []
            except Exception:
                vps['shared_with'] = []
            
            # Convert suspended and whitelisted to boolean for consistency
            vps['suspended'] = bool(vps.get('suspended', 0))
            vps['whitelisted'] = bool(vps.get('whitelisted', 0))

            # Initialize with safe defaults
            vps['live_status'] = vps.get('status', 'unknown')
            vps['live_cpu'] = 0.0
            vps['live_ram'] = {'used': 0, 'total': 0, 'pct': 0.0}
            vps['live_disk'] = {'use_percent': '0%'}

            if is_vps_suspended(vps):
                vps['live_status'] = "suspended"
            else:
                try:
                    stats = run_sync(
                        get_container_stats(
                            vps['container_name'],
                            vps['node_id']
                        )
                    )

                    if stats:
                        vps['live_status'] = stats.get('status', 'unknown')
                        vps['live_cpu'] = float(stats.get('cpu', 0.0))
                        
                        # Ensure RAM is a dict
                        ram_data = stats.get('ram', {'used': 0, 'total': 0, 'pct': 0.0})
                        if isinstance(ram_data, dict):
                            vps['live_ram'] = ram_data
                        else:
                            vps['live_ram'] = {'used': 0, 'total': 0, 'pct': 0.0}
                        
                        # Ensure disk is a dict
                        disk_data = stats.get('disk', {'use_percent': '0%'})
                        if isinstance(disk_data, dict):
                            vps['live_disk'] = disk_data
                        else:
                            vps['live_disk'] = {'use_percent': '0%'}

                except Exception as e:
                    current_app.logger.warning(
                        f"Stats error for {vps.get('container_name')}: {e}"
                    )

            vps_list.append(vps)

        count_query = '''
            SELECT COUNT(*)
            FROM vps v
            JOIN users u ON v.user_id = u.id
        '''

        count_params = params[:-2]

        if conditions:
            count_query += ' WHERE ' + ' AND '.join(conditions)

        cur.execute(count_query, count_params)
        total_vps = cur.fetchone()[0]

    nodes = get_nodes()

    return render_template(
        'admin/vps.html',
        panel_name=get_setting('site_name', 'AVM PANEL'),
        vps_list=vps_list,
        search_query=search_query,
        node_id=node_id,
        status_filter=status_filter,
        nodes=nodes,
        page=page,
        total_pages=(total_vps + per_page - 1) // per_page,
        socketio_available=SOCKETIO_AVAILABLE
    )

@app.route('/admin/vps/expiring')
@login_required
@admin_required
def admin_vps_expiring():
    """List all VPS that are expiring soon or already expired"""
    days_ahead = int(request.args.get('days', 7))  # Default: show VPS expiring in next 7 days
    
    # If it's an AJAX request, return JSON
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        with get_db() as conn:
            cur = conn.cursor()
            now = datetime.now().isoformat()
            future_date = (datetime.now() + timedelta(days=days_ahead)).isoformat()
            
            # Get expiring VPS
            cur.execute('''SELECT v.*, u.username, u.email, n.name as node_name
                          FROM vps v
                          JOIN users u ON v.user_id = u.id
                          JOIN nodes n ON v.node_id = n.id
                          WHERE v.auto_suspend_enabled = 1 
                          AND v.expires_at IS NOT NULL 
                          AND v.expires_at <= ?
                          ORDER BY v.expires_at ASC''', (future_date,))
            
            vps_list = []
            for row in cur.fetchall():
                vps = dict(row)
                expires_dt = datetime.fromisoformat(vps['expires_at'])
                time_diff = expires_dt - datetime.now()
                
                vps['is_expired'] = expires_dt < datetime.now()
                vps['days_remaining'] = time_diff.days if not vps['is_expired'] else 0
                vps['hours_remaining'] = int(time_diff.total_seconds() / 3600) if not vps['is_expired'] else 0
                vps['expires_at_formatted'] = expires_dt.strftime("%Y-%m-%d %H:%M")
                vps['suspended'] = bool(vps.get('suspended', 0))
                
                vps_list.append(vps)
        
        return jsonify({
            'success': True,
            'data': vps_list,
            'count': len(vps_list),
            'days_ahead': days_ahead
        })
    
    # Regular page view
    with get_db() as conn:
        cur = conn.cursor()
        
        # Get statistics
        cur.execute('''SELECT COUNT(*) FROM vps 
                      WHERE auto_suspend_enabled = 1 
                      AND expires_at IS NOT NULL 
                      AND expires_at < ?''', (datetime.now().isoformat(),))
        expired_count = cur.fetchone()[0]
        
        cur.execute('''SELECT COUNT(*) FROM vps 
                      WHERE auto_suspend_enabled = 1 
                      AND expires_at IS NOT NULL 
                      AND expires_at >= ? 
                      AND expires_at <= ?''', 
                   (datetime.now().isoformat(), 
                    (datetime.now() + timedelta(days=7)).isoformat()))
        expiring_soon_count = cur.fetchone()[0]
        
        cur.execute('''SELECT COUNT(*) FROM vps 
                      WHERE auto_suspend_enabled = 1 
                      AND expires_at IS NOT NULL''')
        total_with_expiration = cur.fetchone()[0]
    
    return render_template('admin/vps_expiring.html',
                         panel_name=get_setting('site_name', 'AVM PANEL'),
                         expired_count=expired_count,
                         expiring_soon_count=expiring_soon_count,
                         total_with_expiration=total_with_expiration,
                          days_ahead=days_ahead)

@app.route('/vps/<int:vps_id>/delete', methods=['POST'])
@login_required
def user_vps_delete(vps_id):
    vps = get_vps_by_id(vps_id)
    if not vps:
        return jsonify({'success': False, 'error': 'VPS not found'}), 404
    if vps['user_id'] != current_user.id and not current_user.is_admin:
        return jsonify({'success': False, 'error': 'Unauthorized'}), 403
    try:
        run_sync(execute_lxc(vps['container_name'], f"delete {vps['container_name']} --force", node_id=vps['node_id']))
    except:
        pass
    delete_vps(vps_id)
    log_activity(current_user.id, 'delete_vps', 'vps', str(vps_id))
    return jsonify({'success': True, 'redirect': '/vps'})

@app.route('/vps/<int:vps_id>/delete/progress', methods=['GET'])
@login_required
def user_vps_delete_progress(vps_id):
    vps = get_vps_by_id(vps_id)
    if not vps:
        flash('VPS not found.', 'danger')
        return redirect(url_for('vps_list'))
    if vps['user_id'] != current_user.id and not current_user.is_admin:
        flash('Unauthorized.', 'danger')
        return redirect(url_for('vps_list'))
    return render_template(
        'vps_delete_progress.html',
        vps=vps,
        vps_id=vps['id'],
        container_name=vps['container_name'],
        hostname=vps.get('hostname', vps['container_name']),
        os=get_os_label(vps.get('template', '')),
        panel_name=PANEL_NAME
    )

@app.route('/admin/vps/<int:vps_id>/delete', methods=['POST'])
@login_required
@admin_required
def admin_vps_delete(vps_id):
    vps = get_vps_by_id(vps_id)
    if not vps:
        return jsonify({'success': False, 'error': 'VPS not found'}), 404
    
    try:
        run_sync(execute_lxc(vps['container_name'], f"delete {vps['container_name']} --force", node_id=vps['node_id']))
    except:
        pass
    
    delete_vps(vps_id)
    log_activity(current_user.id, 'admin_delete_vps', 'vps', str(vps_id))
    return jsonify({'success': True})

@app.route('/admin/vps/<int:vps_id>/suspend', methods=['POST'])
@login_required
@admin_required
def admin_vps_suspend(vps_id):
    try:
        vps = get_vps_by_id(vps_id)
        if not vps:
            logger.error(f"Suspend failed: VPS {vps_id} not found")
            return jsonify({'success': False, 'error': 'VPS not found'}), 404

        if is_vps_whitelisted(vps):
            logger.warning(f"Suspend failed: VPS {vps_id} is whitelisted")
            return jsonify({
                'success': False,
                'error': 'Whitelisted VPS cannot be suspended'
            }), 403

        data = request.get_json(silent=True) or {}
        reason = data.get('reason', 'Admin action')

        container = vps['container_name']
        
        logger.info(f"Suspending VPS {vps_id} ({container}): {reason}")

        # Stop the container
        try:
            run_sync(
                execute_lxc(
                    container,
                    f"stop {container} --force",
                    node_id=vps['node_id']
                )
            )
            logger.info(f"Container {container} stopped successfully")
        except Exception as e:
            logger.warning(f"Failed to stop container {container}: {e}")
            # Continue anyway - container might already be stopped

        history = vps.get('suspension_history', [])
        if not isinstance(history, list):
            history = []
        
        history.append({
            'time': datetime.now().isoformat(),
            'reason': reason,
            'by': current_user.username
        })

        # Update VPS with suspended flag - use integer 1, not boolean
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('''UPDATE vps 
                          SET suspended = 1, 
                              suspended_reason = ?, 
                              suspension_history = ?,
                              updated_at = ?
                          WHERE id = ?''',
                       (reason, json.dumps(history), datetime.now().isoformat(), vps_id))
            conn.commit()
            logger.info(f"VPS {vps_id} suspended flag set in database (rows affected: {cur.rowcount})")
        
        # Verify the update
        updated_vps = get_vps_by_id(vps_id)
        logger.info(f"VPS {vps_id} suspended status after update: {updated_vps.get('suspended')} (type: {type(updated_vps.get('suspended'))})")

        log_activity(current_user.id, 'suspend_vps', 'vps', str(vps_id), {'reason': reason})

        create_notification(
            vps['user_id'],
            'warning',
            'VPS Suspended',
            f'{container} suspended: {reason}'
        )
        
        if socketio:
            socketio.emit('vps_suspended', {
                'vps_id': vps_id,
                'reason': reason
            }, room=f'vps_{vps_id}')
            socketio.emit('vps_status_change', {
                'vps_id': vps_id,
                'status': 'suspended'
            }, room=f'user_{vps["user_id"]}')

        return jsonify({'success': True, 'message': f'VPS {container} has been suspended'})
    
    except Exception as e:
        logger.error(f"Error suspending VPS {vps_id}: {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/admin/vps/<int:vps_id>/unsuspend', methods=['POST'])
@login_required
@admin_required
def admin_vps_unsuspend(vps_id):
    try:
        vps = get_vps_by_id(vps_id)
        if not vps:
            logger.error(f"Unsuspend failed: VPS {vps_id} not found")
            return jsonify({'success': False, 'error': 'VPS not found'}), 404

        logger.info(f"Unsuspending VPS {vps_id} ({vps['container_name']})")

        history = vps.get('suspension_history', [])
        if not isinstance(history, list):
            history = []
        
        history.append({
            'time': datetime.now().isoformat(),
            'reason': 'Unsuspended by admin',
            'by': current_user.username
        })

        # Update database directly with integer 0
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('''UPDATE vps 
                          SET suspended = 0, 
                              status = 'stopped',
                              suspended_reason = NULL,
                              suspension_history = ?,
                              updated_at = ?
                          WHERE id = ?''',
                       (json.dumps(history), datetime.now().isoformat(), vps_id))
            conn.commit()
            logger.info(f"VPS {vps_id} unsuspended in database (rows affected: {cur.rowcount})")
        
        # Verify the update
        updated_vps = get_vps_by_id(vps_id)
        logger.info(f"VPS {vps_id} suspended status after unsuspend: {updated_vps.get('suspended')} (type: {type(updated_vps.get('suspended'))})")

        log_activity(current_user.id, 'unsuspend_vps', 'vps', str(vps_id))

        create_notification(
            vps['user_id'],
            'success',
            'VPS Unsuspended',
            f'{vps["container_name"]} is now active.'
        )
        
        if socketio:
            socketio.emit('vps_unsuspended', {
                'vps_id': vps_id
            }, room=f'vps_{vps_id}')
            socketio.emit('vps_status_change', {
                'vps_id': vps_id,
                'status': 'stopped'
            }, room=f'user_{vps["user_id"]}')

        return jsonify({'success': True, 'message': f'VPS {vps["container_name"]} has been unsuspended'})
    
    except Exception as e:
        logger.error(f"Error unsuspending VPS {vps_id}: {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/admin/vps/<int:vps_id>/renew', methods=['POST'])
@login_required
@admin_required
def admin_vps_renew(vps_id):
    """Renew VPS expiration date"""
    try:
        vps = get_vps_by_id(vps_id)
        if not vps:
            return jsonify({'success': False, 'error': 'VPS not found'}), 404
        
        data = request.get_json() or {}
        additional_days = int(data.get('days', vps.get('expiration_days', 30)))
        
        if additional_days <= 0:
            return jsonify({'success': False, 'error': 'Days must be greater than 0'}), 400
        
        now = datetime.now()
        
        # Calculate new expiration date
        if vps.get('expires_at'):
            # If already has expiration, extend from that date
            current_expires = datetime.fromisoformat(vps['expires_at'])
            # If already expired, start from now
            if current_expires < now:
                new_expires = now + timedelta(days=additional_days)
            else:
                new_expires = current_expires + timedelta(days=additional_days)
        else:
            # No previous expiration, start from now
            new_expires = now + timedelta(days=additional_days)
        
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('''UPDATE vps 
                          SET expires_at = ?,
                              last_renewed_at = ?,
                              renewal_count = renewal_count + 1,
                              auto_suspend_enabled = 1,
                              expiration_days = ?,
                              updated_at = ?
                          WHERE id = ?''',
                       (new_expires.isoformat(), now.isoformat(), additional_days, now.isoformat(), vps_id))
            conn.commit()
        
        log_activity(current_user.id, 'renew_vps', 'vps', str(vps_id), 
                    {'days': additional_days, 'new_expires': new_expires.isoformat()})
        
        create_notification(vps['user_id'], 'success', 'VPS Renewed', 
                          f'Your VPS {vps["hostname"]} has been renewed for {additional_days} days. New expiration: {new_expires.strftime("%Y-%m-%d %H:%M")}')
        
        if socketio:
            socketio.emit('vps_renewed', {
                'vps_id': vps_id,
                'expires_at': new_expires.isoformat(),
                'days': additional_days
            }, room=f'user_{vps["user_id"]}')
        
        return jsonify({
            'success': True, 
            'message': f'VPS renewed for {additional_days} days',
            'expires_at': new_expires.isoformat(),
            'expires_at_formatted': new_expires.strftime("%Y-%m-%d %H:%M")
        })
    
    except Exception as e:
        logger.error(f"Error renewing VPS {vps_id}: {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/admin/vps/<int:vps_id>/expiration', methods=['GET', 'POST'])
@login_required
@admin_required
def admin_vps_expiration(vps_id):
    """Get or update VPS expiration settings"""
    vps = get_vps_by_id(vps_id)
    if not vps:
        if request.method == 'GET' and not request.is_json:
            flash('VPS not found', 'danger')
            return redirect(url_for('admin_vps'))
        return jsonify({'success': False, 'error': 'VPS not found'}), 404
    
    if request.method == 'GET':
        # Get user info
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT username, email FROM users WHERE id = ?', (vps['user_id'],))
            user_row = cur.fetchone()
            user = dict(user_row) if user_row else {'username': 'Unknown', 'email': ''}
        
        expires_info = {
            'vps_id': vps_id,
            'auto_suspend_enabled': bool(vps.get('auto_suspend_enabled', 0)),
            'expiration_days': vps.get('expiration_days', 0),
            'expires_at': vps.get('expires_at'),
            'last_renewed_at': vps.get('last_renewed_at'),
            'renewal_count': vps.get('renewal_count', 0),
            'is_expired': False,
            'days_remaining': None,
            'hours_remaining': None
        }
        
        if vps.get('expires_at'):
            expires_dt = datetime.fromisoformat(vps['expires_at'])
            now = datetime.now()
            time_diff = expires_dt - now
            expires_info['is_expired'] = expires_dt < now
            expires_info['days_remaining'] = time_diff.days if not expires_info['is_expired'] else 0
            expires_info['hours_remaining'] = int(time_diff.total_seconds() / 3600) if not expires_info['is_expired'] else 0
            expires_info['expires_at_formatted'] = expires_dt.strftime("%Y-%m-%d %H:%M")
        
        # Check if JSON request (API call)
        if request.is_json or request.args.get('format') == 'json':
            return jsonify({'success': True, 'data': expires_info})
        
        # Render HTML page
        return render_template('admin/vps_expiration.html',
                              panel_name=get_setting('site_name', 'AVM PANEL'),
                              vps=vps,
                              user=user,
                              expires_info=expires_info)
    
    # POST - Update expiration settings
    try:
        data = request.get_json() or {}
        auto_suspend_enabled = bool(data.get('auto_suspend_enabled', False))
        expiration_days = int(data.get('expiration_days', 0))
        
        if expiration_days < 0:
            return jsonify({'success': False, 'error': 'Expiration days cannot be negative'}), 400
        
        now = datetime.now()
        expires_at = None
        
        if auto_suspend_enabled and expiration_days > 0:
            expires_at = (now + timedelta(days=expiration_days)).isoformat()
        
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('''UPDATE vps 
                          SET auto_suspend_enabled = ?,
                              expiration_days = ?,
                              expires_at = ?,
                              updated_at = ?
                          WHERE id = ?''',
                       (1 if auto_suspend_enabled else 0, expiration_days, expires_at, now.isoformat(), vps_id))
            conn.commit()
        
        log_activity(current_user.id, 'update_vps_expiration', 'vps', str(vps_id), 
                    {'auto_suspend_enabled': auto_suspend_enabled, 'expiration_days': expiration_days})
        
        return jsonify({
            'success': True, 
            'message': 'Expiration settings updated',
            'expires_at': expires_at
        })
    
    except Exception as e:
        logger.error(f"Error updating VPS expiration {vps_id}: {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/admin/vps/<int:vps_id>/whitelist', methods=['POST'])
@login_required
@admin_required
def admin_vps_whitelist(vps_id):
    try:
        vps = get_vps_by_id(vps_id)
        if not vps:
            logger.error(f"Whitelist failed: VPS {vps_id} not found")
            return jsonify({'success': False, 'error': 'VPS not found'}), 404

        data = request.get_json(silent=True) or {}
        whitelist = bool(data.get('whitelist', False))
        
        logger.info(f"Setting whitelist for VPS {vps_id} to {whitelist}")

        # Update database directly with integer value
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('''UPDATE vps 
                          SET whitelisted = ?, 
                              updated_at = ?
                          WHERE id = ?''',
                       (1 if whitelist else 0, datetime.now().isoformat(), vps_id))
            conn.commit()
            logger.info(f"VPS {vps_id} whitelisted flag set in database (rows affected: {cur.rowcount})")
        
        # Verify the update
        updated_vps = get_vps_by_id(vps_id)
        logger.info(f"VPS {vps_id} whitelisted status after update: {updated_vps.get('whitelisted')} (type: {type(updated_vps.get('whitelisted'))})")

        log_activity(
            current_user.id,
            'whitelist_vps',
            'vps',
            str(vps_id),
            {'whitelisted': whitelist}
        )
        
        action = "whitelisted" if whitelist else "removed from whitelist"
        create_notification(
            vps['user_id'],
            'info',
            'VPS Whitelist Updated',
            f'Your VPS {vps["container_name"]} has been {action}.'
        )

        return jsonify({'success': True, 'whitelisted': whitelist, 'message': f'VPS {action} successfully'})
    
    except Exception as e:
        logger.error(f"Error whitelisting VPS {vps_id}: {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/admin/vps/<int:vps_id>/edit', methods=['GET', 'POST'])
@login_required
@admin_required
def admin_vps_edit(vps_id):
    vps = get_vps_by_id(vps_id)
    if not vps:
        return "VPS not found", 404

    if request.method == 'GET':
        users = get_all_users()
        nodes = get_nodes()
        return render_template(
            'admin/vps_edit.html',
            vps=vps,
            users=users,
            nodes=nodes,
            os_options=OS_OPTIONS,
            panel_name=get_setting('site_name', 'AVM PANEL')
        )

    data = request.form

    new_user_id = data.get('user_id')
    node_id = data.get('node_id')
    ram = data.get('ram')
    cpu = data.get('cpu')
    disk = data.get('disk')
    hostname = data.get('hostname')
    ip_address = data.get('ip_address')
    ip_alias = data.get('ip_alias')
    os_version = data.get('os_version')

    if ram and (int(ram) < 1 or int(ram) > 128):
        flash('RAM must be between 1 and 128 GB', 'danger')
        return redirect(request.url)
    
    if cpu and (int(cpu) < 1 or int(cpu) > 64):
        flash('CPU must be between 1 and 64 cores', 'danger')
        return redirect(request.url)
    
    if disk and (int(disk) < 5 or int(disk) > 2000):
        flash('Disk must be between 5 and 2000 GB', 'danger')
        return redirect(request.url)

    was_running = vps['status'] == 'running' and not is_vps_suspended(vps)

    if was_running and (ram or cpu or disk or ip_address or os_version or (node_id and node_id != str(vps['node_id']))):
        try:
            run_sync(execute_lxc(
                vps['container_name'],
                f"stop {vps['container_name']}",
                node_id=vps['node_id']
            ))
            update_vps(vps_id, status='stopped')
        except Exception as e:
            flash(f"Failed to stop VPS: {e}", "danger")
            return redirect(request.url)

    try:
        if ram:
            ram_mb = int(ram) * 1024
            run_sync(execute_lxc(
                vps['container_name'],
                f"config set {vps['container_name']} limits.memory {ram_mb}MB",
                node_id=vps['node_id']
            ))

        if cpu:
            run_sync(execute_lxc(
                vps['container_name'],
                f"config set {vps['container_name']} limits.cpu {int(cpu)}",
                node_id=vps['node_id']
            ))

        if disk:
            run_sync(execute_lxc(
                vps['container_name'],
                f"config device set {vps['container_name']} root size={int(disk)}GB",
                node_id=vps['node_id']
            ))

        if ip_address:
            # Use the proper IP configuration function
            run_sync(configure_container_ip(vps['container_name'], ip_address, vps['node_id']))

        updates = {}

        if new_user_id and new_user_id != str(vps['user_id']):
            updates['user_id'] = int(new_user_id)
            logger.info(f"Changing VPS {vps_id} owner from {vps['user_id']} to {new_user_id}")
        
        if node_id and node_id != str(vps['node_id']):
            updates['node_id'] = int(node_id)
            logger.info(f"Moving VPS {vps_id} from node {vps['node_id']} to {node_id}")

        if ram:
            updates['ram'] = f"{ram}GB"
        if cpu:
            updates['cpu'] = str(cpu)
        if disk:
            updates['storage'] = f"{disk}GB"
        if hostname:
            updates['hostname'] = hostname
            try:
                run_sync(execute_lxc(
                    vps['container_name'],
                    f"exec {vps['container_name']} -- hostnamectl set-hostname {hostname}",
                    node_id=vps['node_id']
                ))
            except:
                pass

        if ip_address:
            updates['ip_address'] = ip_address
        if ip_alias:
            updates['ip_alias'] = ip_alias
        if os_version:
            updates['os_version'] = os_version

        if updates:
            config_str = f"{updates.get('ram', vps['ram'])} RAM / {updates.get('cpu', vps['cpu'])} CPU / {updates.get('storage', vps['storage'])} Disk"
            updates['config'] = config_str
            updates['updated_at'] = datetime.now().isoformat()
            
            # Use direct SQL for critical updates
            with get_db() as conn:
                cur = conn.cursor()
                set_clauses = []
                values = []
                for key, value in updates.items():
                    set_clauses.append(f"{key} = ?")
                    values.append(value)
                values.append(vps_id)
                
                sql = f"UPDATE vps SET {', '.join(set_clauses)} WHERE id = ?"
                cur.execute(sql, values)
                conn.commit()
                logger.info(f"VPS {vps_id} updated in database (rows affected: {cur.rowcount})")
                logger.info(f"Updates applied: {updates}")

        if was_running:
            run_sync(execute_lxc(
                vps['container_name'],
                f"start {vps['container_name']}",
                node_id=updates.get('node_id', vps['node_id'])
            ))
            run_sync(apply_internal_permissions(vps['container_name'], updates.get('node_id', vps['node_id'])))
            run_sync(recreate_port_forwards(vps['container_name']))
            
            # Update status to running
            with get_db() as conn:
                cur = conn.cursor()
                cur.execute('UPDATE vps SET status = ? WHERE id = ?', ('running', vps_id))
                conn.commit()

        log_activity(current_user.id, 'edit_vps', 'vps', str(vps_id), updates)

        # Send notification to new owner if owner changed
        target_user_id = updates.get('user_id', vps['user_id'])
        create_notification(
            target_user_id,
            'info',
            'VPS Updated',
            f'VPS {vps["container_name"]} has been updated by an administrator.'
        )

        flash("VPS updated successfully!", "success")
        return redirect(url_for('admin_vps'))

    except Exception as e:
        if was_running:
            try:
                run_sync(execute_lxc(
                    vps['container_name'],
                    f"start {vps['container_name']}",
                    node_id=vps['node_id']
                ))
            except:
                pass

        flash(str(e), "danger")
        return redirect(request.url)

@app.route('/admin/vps/create', methods=['GET', 'POST'])
@login_required
@admin_required
def admin_vps_create():
    if request.method == 'GET':
        users = []
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT id, username, email FROM users ORDER BY username')
            users = [dict(row) for row in cur.fetchall()]
        
        nodes = get_nodes()
        
        return render_template('admin/vps_create.html',
                              panel_name=get_setting('site_name', 'AVM PANEL'),
                              users=users,
                              nodes=nodes,
                              os_options=OS_OPTIONS)
    
    data = request.get_json()
    user_id = data.get('user_id')
    node_id = data.get('node_id')
    ram = int(data.get('ram', 2))
    cpu = int(data.get('cpu', 2))
    disk = int(data.get('disk', 20))
    os_version = data.get('os_version', 'ubuntu:22.04')
    hostname = data.get('hostname')
    ip_address = data.get('ip_address', '').strip() if data.get('ip_address') else None
    ip_alias = data.get('ip_alias', '').strip() if data.get('ip_alias') else None
    expiration_days = int(data.get('expiration_days', 0))
    auto_suspend_enabled = bool(data.get('auto_suspend_enabled', False))
    auto_backup_enabled = bool(data.get('auto_backup_enabled', False))
    kvm_enabled = bool(data.get('kvm_enabled', False))
    
    # Validate IP address format if provided
    if ip_address:
        try:
            import ipaddress
            ipaddress.ip_address(ip_address)
            logger.info(f"Valid IP address provided: {ip_address}")
        except ValueError as e:
            logger.error(f"Invalid IP address format: {ip_address}")
            return jsonify({'success': False, 'error': f'Invalid IP address format: {ip_address}'}), 400
    
    if not all([user_id, node_id]):
        return jsonify({'success': False, 'error': 'Missing parameters'}), 400
    
    node = get_node(node_id)
    if not node:
        return jsonify({'success': False, 'error': 'Node not found'}), 404
    
    current_count = get_current_vps_count(node_id)
    if current_count >= node['total_vps']:
        return jsonify({'success': False, 'error': 'Node at full capacity'}), 400
    
    max_vps = int(get_setting('max_vps_per_user', '10'))
    user_vps_count = len(get_vps_for_user(user_id))
    if user_vps_count >= max_vps:
        return jsonify({'success': False, 'error': f'User has reached maximum VPS limit ({max_vps})'}), 400
    
    try:
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT COUNT(*) FROM vps WHERE user_id = ?', (user_id,))
            vps_count = cur.fetchone()[0] + 1
        
        container_name = f"avm-vps-{user_id}-{vps_count}"
        if hostname:
            container_name = hostname.lower().replace(' ', '-').replace('_', '-')
            container_name = re.sub(r'[^a-z0-9\-]', '', container_name)
        
        ram_mb = ram * 1024

        # ── Proxmox uses Debian 12 as the base image ──
        _is_proxmox = os_version.startswith('proxmox:')
        _lxc_image = 'images:debian/12' if _is_proxmox else os_version

        # Force-delete any existing container with the same name first
        try:
            run_sync(execute_lxc(container_name, f"stop {container_name} --force", node_id=node_id, suppress_log=True))
        except Exception:
            pass
        try:
            run_sync(execute_lxc(container_name, f"delete {container_name} --force", node_id=node_id, suppress_log=True))
        except Exception:
            pass

        # Launch container (init + start atomically — avoids lxc.conf corruption between init and start)
        run_sync(execute_lxc(container_name, f"launch {_lxc_image} {container_name} -s {DEFAULT_STORAGE_POOL}", node_id=node_id))
        run_sync(execute_lxc(container_name, f"config set {container_name} limits.memory {ram_mb}MB", node_id=node_id))
        run_sync(execute_lxc(container_name, f"config set {container_name} limits.cpu {cpu}", node_id=node_id))

        # Set root disk size — silently skip if storage driver doesn't support it
        try:
            run_sync(execute_lxc(container_name, f"config device set {container_name} root size={disk}GB", node_id=node_id))
        except Exception as disk_err:
            logger.warning(f"Could not set root disk size for {container_name}: {disk_err}")

        run_sync(execute_lxc(container_name, f"config set {container_name} security.nesting true", node_id=node_id))

        # Apply KVM virtualisation if requested
        if kvm_enabled:
            try:
                run_sync(apply_kvm_config(container_name, node_id))
                logger.info(f"KVM enabled for {container_name}")
            except Exception as kvm_err:
                logger.warning(f"KVM config failed for {container_name} (non-fatal): {kvm_err}")

        # Configure IP after container is started
        if ip_address:
            run_sync(configure_container_ip(container_name, ip_address, node_id))
        
        run_sync(apply_internal_permissions(container_name, node_id))
        
        # Configure SSH and set root password
        run_sync(configure_ssh_and_root_password(container_name, node_id))

        # Apply post-start configs (swap isolation, resource limits, etc.)
        run_sync(apply_post_start_config(container_name, node_id))

        # ── Install Proxmox VE on top of Debian 12 if requested ──
        if _is_proxmox:
            try:
                run_sync(install_proxmox_in_container(container_name, node_id))
                logger.info(f"Proxmox VE installed in {container_name}")
            except Exception as px_err:
                logger.warning(f"Proxmox install failed for {container_name} (non-fatal): {px_err}")
        
        config_str = f"{ram}GB RAM / {cpu} CPU / {disk}GB Disk"
        if kvm_enabled:
            config_str += " / KVM"
        if _is_proxmox:
            config_str += " / Proxmox VE"
        vps_id = create_vps(
            user_id=user_id,
            node_id=node_id,
            container_name=container_name,
            hostname=hostname or container_name,
            ram=f"{ram}GB",
            cpu=str(cpu),
            storage=f"{disk}GB",
            config=config_str,
            os_version=os_version,
            ip_address=ip_address,
            ip_alias=ip_alias,
            expiration_days=expiration_days,
            auto_suspend_enabled=auto_suspend_enabled,
            auto_backup_enabled=auto_backup_enabled
        )

        # Store KVM flag in metadata
        if kvm_enabled:
            with get_db() as conn:
                import json as _json
                cur = conn.cursor()
                cur.execute('SELECT metadata FROM vps WHERE id = ?', (vps_id,))
                row = cur.fetchone()
                meta = _json.loads(row[0] or '{}') if row else {}
                meta['kvm_enabled'] = True
                cur.execute('UPDATE vps SET metadata = ? WHERE id = ?',
                            (_json.dumps(meta), vps_id))
                conn.commit()
        
        log_activity(current_user.id, 'admin_create_vps', 'vps', str(vps_id),
                    {'user_id': user_id, 'container': container_name})
        create_notification(user_id, 'success', 'VPS Created', f'Your VPS {container_name} has been created by an administrator.')
        return jsonify({'success': True, 'vps_id': vps_id, 'container_name': container_name})
    except Exception as e:
        logger.error(f"VPS creation error: {e}")
        try:
            run_sync(execute_lxc(container_name, f"delete {container_name} --force", node_id=node_id))
        except:
            pass
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/admin/nodes')
@login_required
@admin_required
def admin_nodes():
    nodes = get_nodes()
    
    node_stats = []
    for node in nodes:
        vps_count = get_current_vps_count(node['id'])
        status = run_sync(get_node_status(node['id']))
        stats = status.get('stats', {})
        
        node_stats.append({
            'id': node['id'],
            'name': node['name'],
            'location': node['location'],
            'status': status['status'],
            'online': status.get('online', False),
            'vps_count': vps_count,
            'total_vps': node['total_vps'],
            'tags': node['tags'],
            'is_local': node['is_local'],
            'url': node.get('url', 'N/A'),
            'api_key': node.get('api_key'),
            'api_key_last_used': node.get('api_key_last_used'),
            'last_seen': node.get('last_seen'),
            'cpu_cores': node.get('cpu_cores', 0),
            'ram_total': node.get('ram_total', 0),
            'disk_total': node.get('disk_total', 0),
            'ip_addresses': node.get('ip_addresses', []),
            'ip_aliases': node.get('ip_aliases', []),
            'stats': stats
        })
    
    return render_template('admin/nodes.html',
                          panel_name=get_setting('site_name', 'AVM PANEL'),
                          nodes=node_stats,
                          socketio_available=SOCKETIO_AVAILABLE)

@app.route('/admin/nodes/test-connection', methods=['POST'])
@login_required
@admin_required
def admin_node_test_connection():
    """Test connection to a remote node"""
    try:
        data = request.get_json()
        url = data.get('url', '').strip()
        verify_ssl = data.get('verify_ssl', True)
        
        if not url:
            return jsonify({'success': False, 'error': 'URL is required'}), 400
        
        # Add http:// if no protocol specified
        if not url.startswith(('http://', 'https://')):
            url = f"http://{url}"
        
        # Remove trailing slash
        url = url.rstrip('/')
        
        # Try to ping the node using public health endpoint (no auth required)
        import requests
        try:
            # Test with /api/health endpoint (public, no auth required)
            response = requests.get(f"{url}/api/health", timeout=10, verify=verify_ssl)
            
            if response.status_code == 200:
                try:
                    data = response.json()
                    return jsonify({
                        'success': True,
                        'message': 'Connection successful',
                        'node_info': {
                            'hostname': data.get('hostname', 'Unknown'),
                            'version': data.get('version', 'Unknown'),
                            'status': data.get('status', 'online'),
                            'service': data.get('service', 'Unknown')
                        }
                    })
                except:
                    return jsonify({
                        'success': True,
                        'message': 'Connection successful (basic)',
                        'node_info': None
                    })
            elif response.status_code == 404:
                # Health endpoint not found, try root endpoint
                try:
                    response = requests.get(f"{url}/", timeout=5, verify=verify_ssl)
                    if response.status_code == 200:
                        return jsonify({
                            'success': True,
                            'message': 'Connection successful (server reachable)',
                            'node_info': {
                                'hostname': 'Unknown',
                                'version': 'Unknown',
                                'status': 'online',
                                'note': 'Update node.py to latest version for full health check'
                            }
                        })
                except:
                    pass
                
                return jsonify({
                    'success': False,
                    'error': 'Node is reachable but /api/health endpoint not found. Please update node.py to the latest version.'
                }), 400
            else:
                return jsonify({
                    'success': False,
                    'error': f'Node returned status code {response.status_code}'
                }), 400
        
        except requests.exceptions.Timeout:
            return jsonify({
                'success': False,
                'error': 'Connection timeout - node is not responding'
            }), 400
        
        except requests.exceptions.ConnectionError:
            return jsonify({
                'success': False,
                'error': 'Connection refused - check if node is running and URL is correct'
            }), 400
        
        except requests.exceptions.SSLError:
            return jsonify({
                'success': False,
                'error': 'SSL certificate error - check HTTPS configuration'
            }), 400
        
        except Exception as e:
            return jsonify({
                'success': False,
                'error': f'Connection error: {str(e)}'
            }), 400
    
    except Exception as e:
        logger.error(f"Test connection error: {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/admin/nodes/create', methods=['GET', 'POST'])
@login_required
@admin_required
def admin_node_create():
    # GET - Render create form
    if request.method == 'GET':
        return render_template('admin/nodes_create.html',
                              panel_name=get_setting('site_name', 'AVM PANEL'))
    
    # POST - Process form submission
    data = request.get_json() or request.form.to_dict()
    
    name = data.get('name')
    location = data.get('location')
    total_vps = int(data.get('total_vps', 50))
    tags = data.get('tags', '').split(',') if data.get('tags') else []
    url = data.get('url', '').strip()
    verify_ssl = 1 if data.get('verify_ssl', True) else 0
    ip_addresses = data.get('ip_addresses', '').split(',') if data.get('ip_addresses') else []
    ip_aliases = data.get('ip_aliases', '').split(',') if data.get('ip_aliases') else []
    
    if not name or not location:
        return jsonify({'success': False, 'error': 'Name and location required'}), 400
    
    # Clean and validate URL if provided
    if url:
        # Remove trailing slash
        url = url.rstrip('/')
        
        # Simple validation - just check if it has http:// or https://
        if not url.startswith(('http://', 'https://')):
            # Add http:// by default for simple IP:port format
            url = f"http://{url}"
        
        # Validate URL format
        try:
            from urllib.parse import urlparse
            parsed = urlparse(url)
            
            if parsed.scheme not in ['http', 'https']:
                return jsonify({'success': False, 'error': 'URL must use http:// or https://'}), 400
            
            if not parsed.netloc:
                return jsonify({'success': False, 'error': 'Invalid URL format'}), 400
            
            # Reconstruct clean URL (preserve path for Cloudflare tunnels)
            url = f"{parsed.scheme}://{parsed.netloc}{parsed.path}"
            
        except Exception as e:
            return jsonify({'success': False, 'error': f'Invalid URL: {str(e)}'}), 400
    
    tags = [t.strip() for t in tags if t.strip()]
    ip_addresses = [ip.strip() for ip in ip_addresses if ip.strip()]
    ip_aliases = [alias.strip() for alias in ip_aliases if alias.strip()]
    
    tags_json = json.dumps(tags)
    ip_addresses_json = json.dumps(ip_addresses)
    ip_aliases_json = json.dumps(ip_aliases)
    
    is_local = 1 if not url else 0
    api_key = None if is_local else generate_api_key()
    now = datetime.now().isoformat()
    
    with get_db() as conn:
        cur = conn.cursor()
        try:
            cur.execute('''INSERT INTO nodes 
                (name, location, total_vps, tags, api_key, url, is_local, verify_ssl,
                 ip_addresses, ip_aliases, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                (name, location, total_vps, tags_json, api_key, url, is_local, verify_ssl,
                 ip_addresses_json, ip_aliases_json, now, now))
            conn.commit()
            node_id = cur.lastrowid
            
            logger.info(f"Node created: {name} (ID: {node_id}) - {'Local' if is_local else f'Remote: {url}'} - SSL Verify: {bool(verify_ssl)}")
        except sqlite3.IntegrityError:
            return jsonify({'success': False, 'error': 'Node name already exists'}), 400
    
    log_activity(current_user.id, 'create_node', 'node', str(node_id), {'name': name, 'url': url})
    return jsonify({'success': True, 'node_id': node_id, 'api_key': api_key})

@app.route('/admin/nodes/<int:node_id>/edit', methods=['GET', 'POST'])
@login_required
@admin_required
def admin_node_edit(node_id):
    node = get_node(node_id)
    if not node:
        if request.method == 'GET':
            flash('Node not found', 'danger')
            return redirect(url_for('admin_nodes'))
        return jsonify({'success': False, 'error': 'Node not found'}), 404
    
    # GET - Render edit page
    if request.method == 'GET':
        # Get VPS count for this node
        vps_count = get_current_vps_count(node_id)
        
        # Parse tags and IPs for display
        try:
            tags = json.loads(node['tags']) if node['tags'] else []
            tags_str = ', '.join(tags)
        except:
            tags_str = ''
        
        try:
            ip_addresses = json.loads(node['ip_addresses']) if node['ip_addresses'] else []
            ip_addresses_str = ', '.join(ip_addresses)
            ip_addresses_count = len(ip_addresses)
        except:
            ip_addresses_str = ''
            ip_addresses_count = 0
        
        try:
            ip_aliases = json.loads(node['ip_aliases']) if node['ip_aliases'] else []
            ip_aliases_str = ', '.join(ip_aliases)
        except:
            ip_aliases_str = ''
        
        return render_template('admin/node_edit.html',
                              panel_name=get_setting('site_name', 'AVM PANEL'),
                              node=node,
                              vps_count=vps_count,
                              tags_str=tags_str,
                              ip_addresses_str=ip_addresses_str,
                              ip_addresses_count=ip_addresses_count,
                              ip_aliases_str=ip_aliases_str)
    
    # POST - Save changes
    data = request.get_json() or request.form.to_dict()
    
    with get_db() as conn:
        cur = conn.cursor()
        
        if 'name' in data:
            cur.execute('UPDATE nodes SET name = ? WHERE id = ?', (data['name'], node_id))
        if 'location' in data:
            cur.execute('UPDATE nodes SET location = ? WHERE id = ?', (data['location'], node_id))
        if 'total_vps' in data:
            cur.execute('UPDATE nodes SET total_vps = ? WHERE id = ?', (int(data['total_vps']), node_id))
        if 'tags' in data:
            tags = [t.strip() for t in data['tags'].split(',') if t.strip()]
            cur.execute('UPDATE nodes SET tags = ? WHERE id = ?', (json.dumps(tags), node_id))
        if 'url' in data and not node['is_local']:
            cur.execute('UPDATE nodes SET url = ? WHERE id = ?', (data['url'], node_id))
        if 'verify_ssl' in data and not node['is_local']:
            verify_ssl = 1 if data['verify_ssl'] else 0
            cur.execute('UPDATE nodes SET verify_ssl = ? WHERE id = ?', (verify_ssl, node_id))
        if 'ip_addresses' in data:
            ips = [ip.strip() for ip in data['ip_addresses'].split(',') if ip.strip()]
            cur.execute('UPDATE nodes SET ip_addresses = ? WHERE id = ?', (json.dumps(ips), node_id))
        if 'ip_aliases' in data:
            aliases = [alias.strip() for alias in data['ip_aliases'].split(',') if alias.strip()]
            cur.execute('UPDATE nodes SET ip_aliases = ? WHERE id = ?', (json.dumps(aliases), node_id))
        
        cur.execute('UPDATE nodes SET updated_at = ? WHERE id = ?', (datetime.now().isoformat(), node_id))
        conn.commit()
    
    log_activity(current_user.id, 'edit_node', 'node', str(node_id))
    
    # Return JSON for AJAX requests or redirect for form submissions
    if request.is_json:
        return jsonify({'success': True})
    else:
        flash('Node updated successfully', 'success')
        return redirect(url_for('admin_nodes'))

@app.route('/admin/nodes/<int:node_id>/regenerate-key', methods=['POST'])
@login_required
@admin_required
def admin_node_regenerate_key(node_id):
    node = get_node(node_id)
    if not node:
        return jsonify({'success': False, 'error': 'Node not found'}), 404
    
    if node['is_local']:
        return jsonify({'success': False, 'error': 'Cannot regenerate key for local node'}), 400
    
    new_key = generate_api_key()
    
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('UPDATE nodes SET api_key = ?, updated_at = ? WHERE id = ?',
                   (new_key, datetime.now().isoformat(), node_id))
        conn.commit()
    
    log_activity(current_user.id, 'regenerate_node_key', 'node', str(node_id))
    return jsonify({'success': True, 'api_key': new_key})

@app.route('/admin/nodes/delete', methods=['POST'])
@login_required
@admin_required
def admin_node_delete():
    try:
        # Debug: Log raw request data
        logger.info(f"Delete node request received")
        logger.info(f"Content-Type: {request.content_type}")
        logger.info(f"Content-Length: {request.content_length}")
        
        # Try to parse JSON
        try:
            data = request.get_json(force=True, silent=False) or {}
        except Exception as json_err:
            logger.error(f"JSON parsing error: {json_err}")
            resp = make_response(jsonify({'success': False, 'error': f'Invalid JSON: {str(json_err)}'}))
            resp.status_code = 400
            return resp
        
        logger.info(f"Parsed data: {data}")
        node_id = data.get('node_id')
        logger.info(f"Node ID: {node_id}")
        
        if node_id is None:
            logger.warning(f"Node ID is missing")
            resp = make_response(jsonify({'success': False, 'error': 'Node ID is required'}))
            resp.status_code = 400
            return resp
        
        if not node_id:
            logger.warning(f"Node ID is falsy")
            resp = make_response(jsonify({'success': False, 'error': 'Node ID is required'}))
            resp.status_code = 400
            return resp
        
        try:
            node_id = int(node_id)
        except (ValueError, TypeError) as e:
            logger.error(f"Failed to convert node_id to int: {e}")
            resp = make_response(jsonify({'success': False, 'error': f'Invalid node ID'}))
            resp.status_code = 400
            return resp
        
        logger.info(f"Node ID int: {node_id}")
        
        node = get_node(node_id)
        if not node:
            logger.warning(f"Node {node_id} not found")
            resp = make_response(jsonify({'success': False, 'error': 'Node not found'}))
            resp.status_code = 404
            return resp
        
        logger.info(f"Node is_local: {node.get('is_local')}")
        
        # NOTE: Removed is_local check - allowing deletion of local node
        
        force = data.get('force', False)
        logger.info(f"Force: {force}")
        
        vps_count = get_current_vps_count(node_id)
        logger.info(f"VPS count: {vps_count}")
        
        if not force and vps_count > 0:
            logger.warning(f"Node has VPS but force=False")
            resp = make_response(jsonify({'success': False, 'error': f'Node has {vps_count} VPS. Use force to delete all.'}))
            resp.status_code = 400
            return resp
        
        logger.info(f"Deleting node {node_id}")
        
        if vps_count > 0:
            with get_db() as conn:
                cur = conn.cursor()
                cur.execute('SELECT container_name FROM vps WHERE node_id = ?', (node_id,))
                cnames = [r[0] for r in cur.fetchall()]
            
            for cname in cnames:
                try:
                    execute_lxc(f"lxc delete {cname} --force")
                except Exception as ex:
                    logger.warning(f"Could not delete {cname}: {ex}")
            
            with get_db() as conn:
                cur = conn.cursor()
                cur.execute('PRAGMA foreign_keys=OFF')
                cur.execute('DELETE FROM vps WHERE node_id = ?', (node_id,))
                cur.execute('PRAGMA foreign_keys=ON')
                conn.commit()
        
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('DELETE FROM nodes WHERE id = ?', (node_id,))
            conn.commit()
        
        logger.info(f"Node {node_id} deleted successfully")
        
        try:
            log_activity(current_user.id, 'delete_node', 'node', str(node_id))
        except Exception as log_e:
            logger.warning(f"Failed to log: {log_e}")
        
        resp = make_response(jsonify({'success': True}))
        resp.status_code = 200
        return resp
        
    except Exception as e:
        logger.error(f"Error: {e}", exc_info=True)
        resp = make_response(jsonify({'success': False, 'error': str(e)}))
        resp.status_code = 500
        return resp

@app.route('/admin/settings', methods=['GET', 'POST'])
@login_required
@admin_required
def admin_settings():
    if request.method == 'POST':
        data = request.form

        settings = [
            'site_name', 'site_description', 'header_icon', 'favicon',
            'footer_text', 'maintenance_message',
            'cpu_threshold', 'ram_threshold',
            'default_port_quota', 'max_vps_per_user', 'session_timeout',
            'backup_retention', 'theme', 'language', 'timezone',
            'discord_client_id', 'discord_client_secret', 'discord_redirect_uri', 'discord_button_text'
        ]

        for key in settings:
            set_setting(key, data.get(key, ''))

        set_setting('maintenance_mode',
                    '1' if 'maintenance_mode' in data else '0')

        set_setting('registration_enabled',
                    '1' if 'registration_enabled' in data else '0')

        set_setting('backup_enabled',
                    '1' if 'backup_enabled' in data else '0')

        set_setting('discord_auth_enabled',
                    '1' if 'discord_auth_enabled' in data else '0')

        set_setting('discord_auto_register',
                    '1' if 'discord_auto_register' in data else '0')

        log_activity(current_user.id, 'update_settings', 'settings')
        create_notification(
            current_user.id,
            'success',
            'Settings Updated',
            'Panel settings have been updated.'
        )

        flash('Settings updated successfully', 'success')
        return redirect(url_for('admin_settings'))

    settings = {}
    keys = [
        'site_name', 'site_description', 'header_icon', 'favicon',
        'footer_text', 'maintenance_mode', 'maintenance_message',
        'registration_enabled', 'cpu_threshold', 'ram_threshold',
        'default_port_quota', 'max_vps_per_user', 'session_timeout',
        'backup_enabled', 'backup_retention', 'theme', 'language', 'timezone',
        'discord_auth_enabled', 'discord_client_id', 'discord_client_secret',
        'discord_redirect_uri', 'discord_auto_register', 'discord_button_text'
    ]

    for key in keys:
        settings[key] = get_setting(key, '')

    return render_template(
        'admin/settings.html',
        panel_name=get_setting('site_name', 'AVM PANEL'),
        settings=settings
    )

@app.route('/admin/settings/save-single', methods=['POST'])
@login_required
@admin_required
def admin_settings_save_single():
    """Save a single setting key/value — used by inline UI actions"""
    data = request.get_json() or {}
    key = data.get('key', '').strip()
    value = data.get('value', '')
    allowed = {'header_icon', 'favicon'}
    if key not in allowed:
        return jsonify({'success': False, 'error': 'Key not allowed'}), 400
    set_setting(key, value)
    return jsonify({'success': True})


@app.route('/admin/settings/upload-header-icon', methods=['POST'])
@login_required
@admin_required
def upload_header_icon():
    if 'icon' not in request.files:
        return jsonify({'success': False, 'error': 'No file uploaded'}), 400
    
    file = request.files['icon']
    if file.filename == '':
        return jsonify({'success': False, 'error': 'No file selected'}), 400
    
    if not allowed_file(file.filename):
        return jsonify({'success': False, 'error': 'Invalid file type'}), 400
    
    filename = secure_filename(f"header_icon_{int(time.time())}.{file.filename.rsplit('.', 1)[1].lower()}")
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], 'settings', filename)
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    file.save(filepath)
    
    if PIL_AVAILABLE and Image:
        try:
            img = Image.open(filepath)
            img.thumbnail((64, 64), Image.Resampling.LANCZOS)
            img.save(filepath, optimize=True, quality=85)
        except:
            pass
    
    icon_path = f'/static/uploads/settings/{filename}'
    
    set_setting('header_icon', icon_path)
    
    return jsonify({'success': True, 'path': icon_path})

@app.route('/admin/settings/upload-favicon', methods=['POST'])
@login_required
@admin_required
def upload_favicon():
    if 'icon' not in request.files:
        return jsonify({'success': False, 'error': 'No file uploaded'}), 400
    
    file = request.files['icon']
    if file.filename == '':
        return jsonify({'success': False, 'error': 'No file selected'}), 400
    
    ext = file.filename.rsplit('.', 1)[1].lower() if '.' in file.filename else ''
    if ext not in ['ico', 'png']:
        return jsonify({'success': False, 'error': 'Invalid file type. Please upload .ico or .png'}), 400
    
    filename = f"favicon_{int(time.time())}.{ext}"
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], 'settings', filename)
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    file.save(filepath)
    
    icon_path = f'/static/uploads/settings/{filename}'
    
    set_setting('favicon', icon_path)
    
    return jsonify({'success': True, 'path': icon_path})

@app.route('/admin/maintenance')
@login_required
@admin_required
def admin_maintenance():
    return render_template('admin/maintenance.html',
                          panel_name=get_setting('site_name', 'AVM PANEL'))

# ============================================================================
# Theme Management Routes (Admin Only)
# ============================================================================
@app.route('/admin/themes')
@login_required
@admin_required
def admin_themes():
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT * FROM themes ORDER BY created_at DESC')
        themes = [dict(r) for r in cur.fetchall()]
    return render_template('admin/themes.html',
                          panel_name=get_setting('site_name', 'AVM PANEL'),
                          themes=themes)


@app.route('/admin/themes/create', methods=['POST'])
@login_required
@admin_required
def admin_theme_create():
    data = request.form
    name = data.get('name', '').strip()
    if not name:
        return jsonify({'success': False, 'error': 'Theme name required'}), 400

    gif_url = data.get('gif_url', '').strip()
    gif_file = None

    # Handle GIF file upload
    if 'gif_file' in request.files:
        f = request.files['gif_file']
        if f and f.filename and f.filename.lower().endswith('.gif'):
            fname = secure_filename(f.filename)
            save_path = os.path.join('static/uploads/settings', fname)
            f.save(save_path)
            gif_file = f'/static/uploads/settings/{fname}'

    now = datetime.now().isoformat()
    try:
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('''INSERT INTO themes (name, description, bg_primary, bg_secondary, accent_primary, accent_secondary, text_primary, gif_url, gif_file, is_active, created_by, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?)''',
                (name, data.get('description', ''), data.get('bg_primary', '#0a0c10'),
                 data.get('bg_secondary', '#111316'), data.get('accent_primary', '#3b82f6'),
                 data.get('accent_secondary', '#6366f1'), data.get('text_primary', '#e1e9f0'),
                 gif_url, gif_file, current_user.id, now, now))
            conn.commit()
        return jsonify({'success': True})
    except Exception as e:
        logger.error(f"Theme create error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/admin/themes/<int:theme_id>/apply', methods=['POST'])
@login_required
@admin_required
def admin_theme_apply(theme_id):
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('UPDATE themes SET is_active = 0, updated_at = ?', (datetime.now().isoformat(),))
        cur.execute('UPDATE themes SET is_active = 1, updated_at = ? WHERE id = ?',
                   (datetime.now().isoformat(), theme_id))
        cur.execute('SELECT * FROM themes WHERE id = ?', (theme_id,))
        theme = cur.fetchone()
        conn.commit()
    if theme:
        set_setting('active_theme_id', str(theme_id))
        cur_version = int(get_setting_cached('theme_version', '0') or '0')
        new_version = str(cur_version + 1)
        set_setting('theme_version', new_version)
        # Bust ALL server-side caches immediately
        app._theme_cache    = {'success': True, 'theme': dict(theme)}
        app._theme_cache_ts = time.time()
        invalidate_settings_cache()
        log_activity(current_user.id, 'theme_applied', 'theme', str(theme_id))
        return jsonify({'success': True, 'theme': dict(theme), 'theme_version': new_version})
    return jsonify({'success': False, 'error': 'Theme not found'}), 404


@app.route('/admin/themes/<int:theme_id>/delete', methods=['POST'])
@login_required
@admin_required
def admin_theme_delete(theme_id):
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('DELETE FROM themes WHERE id = ?', (theme_id,))
        conn.commit()
    return jsonify({'success': True})


# ============================================================================
# Font Management Route (Admin Only)
# ============================================================================
@app.route('/admin/fonts')
@login_required
@admin_required
def admin_fonts():
    return render_template('admin/fonts.html',
                          panel_name=get_setting('site_name', 'AVM PANEL'))


@app.route('/admin/error-solver')
@login_required
@admin_required
def admin_error_solver():
    """Show all unresolved (and recently resolved) VPS errors."""
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('''
            SELECT e.*,
                   e.container_name AS err_container,
                   v.ram, v.cpu, v.storage, v.os_version,
                   u.username AS owner_username,
                   r.username AS resolver_username
            FROM vps_errors e
            LEFT JOIN vps v ON e.vps_id = v.id
            LEFT JOIN users u ON e.owner_id = u.id
            LEFT JOIN users r ON e.resolved_by = r.id
            ORDER BY e.resolved ASC, e.created_at DESC
            LIMIT 200
        ''')
        errors = [dict(row) for row in cur.fetchall()]

    # Ensure container_name always comes from the error record itself
    for e in errors:
        if not e.get('container_name'):
            e['container_name'] = e.get('err_container', 'unknown')

    unresolved = [e for e in errors if not e['resolved']]
    resolved   = [e for e in errors if e['resolved']]

    return render_template('admin/error_solver.html',
                           panel_name=get_setting('site_name', 'AVM PANEL'),
                           unresolved=unresolved,
                           resolved=resolved)


@app.route('/admin/error-solver/<int:error_id>/auto-solve', methods=['POST'])
@login_required
@admin_required
def admin_auto_solve_error(error_id):
    """Attempt to automatically fix a single VPS error."""
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('''SELECT e.*, v.node_id, v.container_name AS cname
                       FROM vps_errors e
                       LEFT JOIN vps v ON e.vps_id = v.id
                       WHERE e.id = ?''', (error_id,))
        err = cur.fetchone()

    if not err:
        return jsonify({'success': False, 'error': 'Error record not found'}), 404

    err = dict(err)
    # Always use the stored container_name from the error record itself
    container = err.get('container_name') or err.get('cname')
    node_id   = err.get('node_id')
    error_type = err['error_type']
    steps_log  = []

    try:
        # ── Strategy based on error type ──────────────────────────────────
        if error_type == 'start_failed':
            steps_log.append('Attempting force-stop to clean state...')
            try:
                run_sync(execute_lxc(container, f"stop {container} --force", node_id=node_id))
                steps_log.append('Force-stop succeeded.')
            except Exception as ex:
                steps_log.append(f'Force-stop skipped: {ex}')
            steps_log.append('Starting container...')
            run_sync(execute_lxc(container, f"start {container}", node_id=node_id))
            steps_log.append('Container started successfully.')
            # Update VPS status
            with get_db() as conn:
                conn.execute("UPDATE vps SET status='running', last_started=? WHERE container_name=?",
                             (datetime.now().isoformat(), container))
                conn.commit()

        elif error_type == 'stop_failed':
            steps_log.append('Attempting force-stop...')
            run_sync(execute_lxc(container, f"stop {container} --force", node_id=node_id))
            steps_log.append('Force-stop succeeded.')
            with get_db() as conn:
                conn.execute("UPDATE vps SET status='stopped', last_stopped=? WHERE container_name=?",
                             (datetime.now().isoformat(), container))
                conn.commit()

        elif error_type == 'restart_failed':
            steps_log.append('Force-stopping container...')
            try:
                run_sync(execute_lxc(container, f"stop {container} --force", node_id=node_id))
            except Exception as ex:
                steps_log.append(f'Stop skipped: {ex}')
            steps_log.append('Starting container...')
            run_sync(execute_lxc(container, f"start {container}", node_id=node_id))
            steps_log.append('Container restarted successfully.')
            with get_db() as conn:
                conn.execute("UPDATE vps SET status='running', last_started=? WHERE container_name=?",
                             (datetime.now().isoformat(), container))
                conn.commit()

        elif error_type == 'freeze_failed':
            steps_log.append('Attempting unfreeze then re-freeze...')
            try:
                run_sync(execute_lxc(container, f"unfreeze {container}", node_id=node_id))
            except Exception:
                pass
            run_sync(execute_lxc(container, f"freeze {container}", node_id=node_id))
            steps_log.append('Container frozen successfully.')

        elif error_type == 'timeout':
            steps_log.append('Timeout detected — force-stopping and restarting...')
            try:
                run_sync(execute_lxc(container, f"stop {container} --force", node_id=node_id))
            except Exception as ex:
                steps_log.append(f'Stop skipped: {ex}')
            run_sync(execute_lxc(container, f"start {container}", node_id=node_id))
            steps_log.append('Container recovered from timeout.')
            with get_db() as conn:
                conn.execute("UPDATE vps SET status='running', last_started=? WHERE container_name=?",
                             (datetime.now().isoformat(), container))
                conn.commit()

        else:
            # Generic: try force-stop + start
            steps_log.append('Generic recovery: force-stop then start...')
            try:
                run_sync(execute_lxc(container, f"stop {container} --force", node_id=node_id))
            except Exception as ex:
                steps_log.append(f'Stop skipped: {ex}')
            run_sync(execute_lxc(container, f"start {container}", node_id=node_id))
            steps_log.append('Container recovered.')
            with get_db() as conn:
                conn.execute("UPDATE vps SET status='running', last_started=? WHERE container_name=?",
                             (datetime.now().isoformat(), container))
                conn.commit()

        # Mark error as resolved
        resolve_log = '\n'.join(steps_log)
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('''UPDATE vps_errors
                            SET resolved=1, resolved_at=?, resolved_by=?, resolve_log=?
                            WHERE id=?''',
                         (datetime.now().isoformat(), current_user.id, resolve_log, error_id))
            conn.commit()

        log_activity(current_user.id, 'auto_solve_vps_error', 'vps_error', str(error_id),
                     {'container': container, 'error_type': error_type})

        return jsonify({'success': True, 'steps': steps_log})

    except Exception as e:
        steps_log.append(f'Auto-solve failed: {e}')
        logger.error(f"Auto-solve error {error_id}: {e}")
        return jsonify({'success': False, 'error': str(e), 'steps': steps_log}), 500


@app.route('/admin/error-solver/<int:error_id>/dismiss', methods=['POST'])
@login_required
@admin_required
def admin_dismiss_error(error_id):
    """Dismiss (mark resolved) an error without running auto-fix."""
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('''UPDATE vps_errors SET resolved=1, resolved_at=?, resolved_by=?, resolve_log=?
                        WHERE id=?''',
                     (datetime.now().isoformat(), current_user.id, 'Dismissed by admin', error_id))
        conn.commit()
    return jsonify({'success': True})


def generate_error_solution(error):
    """Generate detailed solution information for an error"""
    error_type = error.get('error_type', 'general_error')
    error_message = error.get('error_message', '')
    
    solutions = {
        'start_failed': {
            'title': 'Container Start Failure',
            'description': 'The container failed to start properly. This could be due to resource conflicts, configuration issues, or corrupted state.',
            'diagnosis_steps': [
                'Check container configuration',
                'Verify resource availability', 
                'Check for conflicting processes',
                'Validate container state'
            ],
            'solution_steps': [
                'Force stop any running processes',
                'Clear container state',
                'Restart with clean configuration',
                'Verify successful startup'
            ],
            'commands': [
                'lxc stop {container} --force',
                'lxc start {container}',
                'lxc info {container}'
            ],
            'severity': 'high',
            'auto_fixable': True
        },
        'stop_failed': {
            'title': 'Container Stop Failure',
            'description': 'The container could not be stopped gracefully. This may indicate hung processes or resource locks.',
            'diagnosis_steps': [
                'Check for hung processes',
                'Verify container responsiveness',
                'Check resource locks',
                'Examine container logs'
            ],
            'solution_steps': [
                'Attempt graceful shutdown',
                'Force terminate if necessary',
                'Clean up resources',
                'Verify complete shutdown'
            ],
            'commands': [
                'lxc stop {container}',
                'lxc stop {container} --force',
                'lxc info {container}'
            ],
            'severity': 'medium',
            'auto_fixable': True
        },
        'restart_failed': {
            'title': 'Container Restart Failure',
            'description': 'The container restart operation failed. This combines stop and start issues.',
            'diagnosis_steps': [
                'Check stop operation status',
                'Verify start prerequisites',
                'Check resource availability',
                'Validate configuration'
            ],
            'solution_steps': [
                'Force stop container',
                'Clear any locks or state',
                'Restart with fresh state',
                'Monitor startup process'
            ],
            'commands': [
                'lxc stop {container} --force',
                'sleep 2',
                'lxc start {container}',
                'lxc info {container}'
            ],
            'severity': 'high',
            'auto_fixable': True
        },
        'timeout': {
            'title': 'Operation Timeout',
            'description': 'The operation exceeded the maximum allowed time. This indicates performance issues or deadlocks.',
            'diagnosis_steps': [
                'Check system load',
                'Verify network connectivity',
                'Check for deadlocks',
                'Monitor resource usage'
            ],
            'solution_steps': [
                'Terminate hung operation',
                'Clear system resources',
                'Restart with optimized settings',
                'Monitor performance'
            ],
            'commands': [
                'lxc stop {container} --force',
                'lxc start {container}',
                'lxc exec {container} -- systemctl status'
            ],
            'severity': 'medium',
            'auto_fixable': True
        }
    }
    
    # Get solution info or default
    solution = solutions.get(error_type, {
        'title': 'General Error',
        'description': 'An unspecified error occurred during VPS operation.',
        'diagnosis_steps': [
            'Check container status',
            'Review error logs',
            'Verify system resources',
            'Check configuration'
        ],
        'solution_steps': [
            'Restart container services',
            'Clear temporary files',
            'Reset container state',
            'Monitor for recurrence'
        ],
        'commands': [
            'lxc stop {container} --force',
            'lxc start {container}'
        ],
        'severity': 'medium',
        'auto_fixable': True
    })
    
    # Replace container placeholder in commands
    container_name = error.get('container_name', 'unknown')
    solution['commands'] = [cmd.format(container=container_name) for cmd in solution['commands']]
    
    # Add specific error analysis
    if 'permission denied' in error_message.lower():
        solution['specific_issue'] = 'Permission Denied'
        solution['specific_fix'] = 'Check file permissions and user privileges'
    elif 'no space left' in error_message.lower():
        solution['specific_issue'] = 'Disk Space Full'
        solution['specific_fix'] = 'Clean up disk space or expand storage'
    elif 'network' in error_message.lower():
        solution['specific_issue'] = 'Network Connectivity'
        solution['specific_fix'] = 'Check network configuration and connectivity'
    elif 'memory' in error_message.lower() or 'oom' in error_message.lower():
        solution['specific_issue'] = 'Memory Issues'
        solution['specific_fix'] = 'Increase memory allocation or optimize usage'
    
    return solution


@app.route('/admin/error-solver/solution/<int:error_id>', methods=['GET'])
@login_required
@admin_required
def get_error_solution(error_id):
    """Get detailed solution information for a specific error"""
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('''SELECT e.*, v.container_name AS cname
                       FROM vps_errors e
                       LEFT JOIN vps v ON e.vps_id = v.id
                       WHERE e.id = ?''', (error_id,))
        err = cur.fetchone()

    if not err:
        return jsonify({'success': False, 'error': 'Error record not found'}), 404

    err = dict(err)
    if not err.get('container_name'):
        err['container_name'] = err.get('cname', 'unknown')
    
    solution = generate_error_solution(err)
    
    return jsonify({
        'success': True,
        'error': err,
        'solution': solution
    })


@app.route('/admin/error-solver/enhanced-solve/<int:error_id>', methods=['POST'])
@login_required
@admin_required
def admin_enhanced_solve_error(error_id):
    """Enhanced auto-solve with detailed logging and smart recovery"""
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('''SELECT e.*, v.node_id, v.container_name AS cname
                       FROM vps_errors e
                       LEFT JOIN vps v ON e.vps_id = v.id
                       WHERE e.id = ?''', (error_id,))
        err = cur.fetchone()

    if not err:
        return jsonify({'success': False, 'error': 'Error record not found'}), 404

    err = dict(err)
    container = err.get('container_name') or err.get('cname')
    node_id = err.get('node_id')
    error_type = err['error_type']
    
    # Enhanced logging with phases
    solve_log = {
        'phases': [],
        'commands_executed': [],
        'diagnostics': {},
        'success': False,
        'error': None
    }
    
    def log_phase(phase_name, description):
        solve_log['phases'].append({
            'name': phase_name,
            'description': description,
            'timestamp': datetime.now().isoformat(),
            'status': 'running'
        })
        return len(solve_log['phases']) - 1
    
    def complete_phase(phase_index, status='completed', details=None):
        if phase_index < len(solve_log['phases']):
            solve_log['phases'][phase_index]['status'] = status
            solve_log['phases'][phase_index]['completed_at'] = datetime.now().isoformat()
            if details:
                solve_log['phases'][phase_index]['details'] = details
    
    def execute_command(cmd, description, timeout=30):
        solve_log['commands_executed'].append({
            'command': cmd,
            'description': description,
            'timestamp': datetime.now().isoformat()
        })
        try:
            result = run_sync(execute_lxc(container, cmd, node_id=node_id, timeout=timeout))
            if isinstance(result, bool):
                result = 'Command completed successfully' if result else 'Command failed'
            solve_log['commands_executed'][-1]['result'] = result
            solve_log['commands_executed'][-1]['success'] = True
            return result
        except Exception as e:
            solve_log['commands_executed'][-1]['result'] = str(e)
            solve_log['commands_executed'][-1]['success'] = False
            raise

    try:
        import time
        
        # Phase 1: Diagnosis
        phase_idx = log_phase('diagnosis', 'Analyzing container state and identifying issues')
        
        try:
            info_result = execute_command(f"info {container}", "Get container information")
            solve_log['diagnostics']['container_info'] = info_result
        except Exception as e:
            solve_log['diagnostics']['container_info'] = f"Failed to get info: {e}"
        
        complete_phase(phase_idx, 'completed')
        
        # Phase 2: Recovery based on error type
        phase_idx = log_phase('recovery', f'Executing recovery strategy for {error_type}')
        
        if error_type == 'start_failed':
            execute_command(f"stop {container} --force", "Force stop container")
            time.sleep(2)
            execute_command(f"start {container}", "Start container with clean state")
        elif error_type == 'stop_failed':
            execute_command(f"stop {container} --force", "Force stop container")
        elif error_type == 'restart_failed':
            execute_command(f"stop {container} --force", "Force stop container")
            time.sleep(2)
            execute_command(f"start {container}", "Start container")
        else:
            # Generic recovery
            execute_command(f"stop {container} --force", "Force stop container")
            time.sleep(2)
            execute_command(f"start {container}", "Start container")
        
        complete_phase(phase_idx, 'completed')
        
        # Phase 3: Verification
        phase_idx = log_phase('verification', 'Verifying recovery success')
        
        final_info = execute_command(f"info {container}", "Verify final container state")
        solve_log['diagnostics']['final_state'] = final_info
        
        # Update VPS status in database
        if 'Status: Running' in final_info or 'Status: RUNNING' in final_info:
            with get_db() as conn:
                conn.execute("UPDATE vps SET status='running', last_started=? WHERE container_name=?",
                           (datetime.now().isoformat(), container))
                conn.commit()
            solve_log['diagnostics']['vps_status_updated'] = 'running'
        
        complete_phase(phase_idx, 'completed')
        solve_log['success'] = True
        
        # Mark error as resolved
        resolve_summary = f"Enhanced auto-solve completed successfully\nPhases: {len(solve_log['phases'])}\nCommands: {len(solve_log['commands_executed'])}"
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('''UPDATE vps_errors
                            SET resolved=1, resolved_at=?, resolved_by=?, resolve_log=?
                            WHERE id=?''',
                         (datetime.now().isoformat(), current_user.id, resolve_summary, error_id))
            conn.commit()

        return jsonify({
            'success': True,
            'solve_log': solve_log,
            'summary': f"Successfully resolved {error_type} for {container}"
        })

    except Exception as e:
        if solve_log['phases']:
            complete_phase(len(solve_log['phases']) - 1, 'failed', str(e))
        
        solve_log['success'] = False
        solve_log['error'] = str(e)
        
        logger.error(f"Enhanced auto-solve error {error_id}: {e}")
        return jsonify({
            'success': False,
            'error': str(e),
            'solve_log': solve_log
        }), 500


@app.route('/admin/glow', methods=['GET', 'POST'])
@login_required
@admin_required
def admin_glow():
    if request.method == 'POST':
        data = request.form
        set_setting('glow_enabled',       '1' if 'glow_enabled' in data else '0')
        set_setting('glow_color_primary',  data.get('glow_color_primary', '#4f9af5'))
        set_setting('glow_color_secondary', data.get('glow_color_secondary', '#a78bfa'))
        set_setting('glow_intensity',      data.get('glow_intensity', 'medium'))
        set_setting('glow_cards',          '1' if 'glow_cards' in data else '0')
        set_setting('glow_sidebar',        '1' if 'glow_sidebar' in data else '0')
        set_setting('glow_buttons',        '1' if 'glow_buttons' in data else '0')
        set_setting('glow_pulse',          '1' if 'glow_pulse' in data else '0')
        log_activity(current_user.id, 'update_glow_settings', 'settings')
        flash('Glow settings saved successfully', 'success')
        return redirect(url_for('admin_glow'))

    glow_keys = [
        'glow_enabled', 'glow_color_primary', 'glow_color_secondary',
        'glow_intensity', 'glow_cards', 'glow_sidebar', 'glow_buttons', 'glow_pulse'
    ]
    settings = {k: get_setting(k, '') for k in glow_keys}
    # Defaults for first run
    if not settings['glow_color_primary']:  settings['glow_color_primary']  = '#4f9af5'
    if not settings['glow_color_secondary']: settings['glow_color_secondary'] = '#a78bfa'
    if not settings['glow_intensity']:       settings['glow_intensity']       = 'medium'
    if settings['glow_enabled']  == '': settings['glow_enabled']  = '1'
    if settings['glow_cards']    == '': settings['glow_cards']    = '1'
    if settings['glow_sidebar']  == '': settings['glow_sidebar']  = '1'
    if settings['glow_buttons']  == '': settings['glow_buttons']  = '1'
    if settings['glow_pulse']    == '': settings['glow_pulse']    = '1'

    return render_template('admin/glow.html',
                           panel_name=get_setting('site_name', 'AVM PANEL'),
                           settings=settings)


# ============================================================================
# VPS Auto-Backup Toggle Route
# ============================================================================
@app.route('/admin/vps/<int:vps_id>/autobackup', methods=['POST'])
@login_required
@admin_required
def admin_vps_toggle_autobackup(vps_id):
    """Toggle auto-backup on/off for a specific VPS"""
    try:
        data = request.get_json() or {}
        enabled = bool(data.get('enabled', False))
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT id, container_name FROM vps WHERE id = ?', (vps_id,))
            vps = cur.fetchone()
            if not vps:
                return jsonify({'success': False, 'error': 'VPS not found'}), 404
            cur.execute('UPDATE vps SET auto_backup_enabled = ?, updated_at = ? WHERE id = ?',
                       (1 if enabled else 0, datetime.now().isoformat(), vps_id))
            conn.commit()
        state = 'enabled' if enabled else 'disabled'
        log_activity(current_user.id, f'autobackup_{state}', 'vps', str(vps_id))
        create_notification(current_user.id, 'success', 'Auto-Backup Updated',
                           f'Auto-backup {state} for VPS {vps["container_name"]}.')
        return jsonify({'success': True, 'enabled': enabled})
    except Exception as e:
        logger.error(f"Auto-backup toggle error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/active-theme')
def get_active_theme():
    """Returns active theme CSS variables as JSON — cached for 30s."""
    try:
        cache    = getattr(app, '_theme_cache', None)
        cache_ts = getattr(app, '_theme_cache_ts', 0.0)
        # Serve from cache only if it's fresh and not explicitly busted (ts > 0)
        if cache is not None and cache_ts > 0 and (time.time() - cache_ts) < 30.0:
            resp = make_response(jsonify(cache))
            resp.headers['Cache-Control'] = 'no-store'
            return resp
        # Fetch fresh from DB
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT * FROM themes WHERE is_active = 1 LIMIT 1')
            theme = cur.fetchone()
        cache = {'success': True, 'theme': dict(theme) if theme else None}
        app._theme_cache    = cache
        app._theme_cache_ts = time.time()
        resp = make_response(jsonify(cache))
        resp.headers['Cache-Control'] = 'no-store'
        return resp
    except Exception as e:
        logger.error(f"active-theme error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


# ============================================================================
# VPS Protection API Routes
# ============================================================================
@app.route('/api/admin/protection/events')
@login_required
@admin_required
def protection_events():
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('''SELECT pe.*, v.container_name, v.hostname FROM protection_events pe
                      LEFT JOIN vps v ON pe.vps_id = v.id
                      ORDER BY pe.created_at DESC LIMIT 100''')
        events = [dict(r) for r in cur.fetchall()]
    return jsonify({'success': True, 'events': events})



@app.route('/admin/backup', methods=['POST'])
@login_required
@admin_required
def admin_backup():
    backup_name = f"avm_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
    
    try:
        os.makedirs('backups', exist_ok=True)
        backup_path = os.path.join('backups', backup_name)
        
        shutil.copy(DATABASE_PATH, backup_path)
        
        if os.path.exists(f"{DATABASE_PATH}-wal"):
            shutil.copy(f"{DATABASE_PATH}-wal", f"{backup_path}-wal")
        if os.path.exists(f"{DATABASE_PATH}-shm"):
            shutil.copy(f"{DATABASE_PATH}-shm", f"{backup_path}-shm")
        
        log_activity(current_user.id, 'create_backup', 'system', None, {'name': backup_name})
        create_notification(current_user.id, 'success', 'Backup Created', f'Database backup {backup_name} created.')
        return send_file(backup_path, as_attachment=True, download_name=backup_name)
    except Exception as e:
        flash(f'Backup failed: {e}', 'danger')
        return redirect(url_for('admin_maintenance'))

@app.route('/admin/backup/list')
@login_required
@admin_required
def admin_backup_list():
    backups = []
    backup_dir = 'backups'
    if os.path.exists(backup_dir):
        for file in os.listdir(backup_dir):
            if file.endswith('.db'):
                path = os.path.join(backup_dir, file)
                backups.append({
                    'name': file,
                    'size': os.path.getsize(path),
                    'modified': datetime.fromtimestamp(os.path.getmtime(path)).isoformat()
                })
    
    backups.sort(key=lambda x: x['modified'], reverse=True)
    
    return render_template('admin/backup_list.html',
                          panel_name=get_setting('site_name', 'AVM PANEL'),
                          backups=backups)

@app.route('/admin/backup/restore/<filename>', methods=['POST'])
@login_required
@admin_required
def admin_backup_restore(filename):
    backup_path = os.path.join('backups', filename)
    
    if not os.path.exists(backup_path):
        return jsonify({'success': False, 'error': 'Backup not found'}), 404
    
    try:
        current_backup = f"avm_pre_restore_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
        shutil.copy(DATABASE_PATH, os.path.join('backups', current_backup))
        
        shutil.copy(backup_path, DATABASE_PATH)
        
        log_activity(current_user.id, 'restore_backup', 'system', None, {'name': filename})
        create_notification(current_user.id, 'success', 'Backup Restored', f'Database restored from {filename}')
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/admin/backup/download/<filename>')
@login_required
@admin_required
def admin_backup_download(filename):
    backup_path = os.path.join('backups', filename)
    
    if not os.path.exists(backup_path):
        flash('Backup not found', 'danger')
        return redirect(url_for('admin_backup_list'))
    
    try:
        return send_file(backup_path, as_attachment=True, download_name=filename)
    except Exception as e:
        flash(f'Failed to download backup: {str(e)}', 'danger')
        return redirect(url_for('admin_backup_list'))

@app.route('/admin/backup/delete/<filename>', methods=['POST'])
@login_required
@admin_required
def admin_backup_delete(filename):
    backup_path = os.path.join('backups', filename)
    
    if not os.path.exists(backup_path):
        return jsonify({'success': False, 'error': 'Backup not found'}), 404
    
    try:
        os.remove(backup_path)
        log_activity(current_user.id, 'delete_backup', 'system', None, {'name': filename})
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/admin/swap-isolation/apply-all', methods=['POST'])
@login_required
@admin_required
def admin_swap_isolation_apply_all():
    """Apply the 5-layer swap isolation stack to every VPS in the database."""
    try:
        summary = run_sync(apply_swap_isolation_to_all())
        if summary.get('success', 0) == summary.get('total', 0) and summary.get('total', 0) > 0:
            flash(f'5-layer swap isolation applied to all {summary["total"]} containers.', 'success')
        elif summary.get('total', 0) == 0:
            flash('No VPS containers to apply swap isolation to.', 'info')
        else:
            flash(
                f'Swap isolation: {summary["success"]} full, {summary["partial"]} partial, '
                f'{summary["failed"]} failed (of {summary["total"]} total).',
                'warning'
            )
        log_activity(current_user.id, 'swap_isolation_apply_all', 'system', None,
                     {'total': summary.get('total'), 'success': summary.get('success'),
                      'partial': summary.get('partial'), 'failed': summary.get('failed')})
        return jsonify({'success': True, 'summary': summary})
    except Exception as e:
        logger.error(f"[swap-iso bulk] {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/admin/vps/<int:vps_id>/swap-isolation/apply', methods=['POST'])
@login_required
@admin_required
def admin_vps_swap_isolation_apply(vps_id):
    """Apply the 5-layer swap isolation stack to a single VPS."""
    try:
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT id, container_name, node_id FROM vps WHERE id = ?', (vps_id,))
            vps = cur.fetchone()
        if not vps:
            return jsonify({'success': False, 'error': 'VPS not found'}), 404
        result = run_sync(apply_swap_isolation(vps['container_name'], vps['node_id']))
        applied = sum(1 for k in ['L1_lxd_limit', 'L2_cgroup_v2', 'L3_swapoff', 'L4_proc_swaps', 'L5_meminfo_patch'] if result.get(k))
        log_activity(current_user.id, 'swap_isolation_apply', 'vps', str(vps_id),
                     {'container': vps['container_name'], 'applied': applied, 'total': 5})
        return jsonify({
            'success': applied > 0,
            'applied': applied,
            'total': 5,
            'result': result
        })
    except Exception as e:
        logger.error(f"[swap-iso single] vps {vps_id}: {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/admin/resource-limits/apply-all', methods=['POST'])
@login_required
@admin_required
def admin_resource_limits_apply_all():
    """Apply Proxmox-Grade Resource Limits to every VPS in the database."""
    try:
        summary = run_sync(apply_proxmox_resource_limits_to_all())
        if summary.get('success', 0) == summary.get('total', 0) and summary.get('total', 0) > 0:
            flash(f'Proxmox-Grade Resource Limits applied to all {summary["total"]} containers.', 'success')
        elif summary.get('total', 0) == 0:
            flash('No VPS containers to apply resource limits to.', 'info')
        else:
            flash(
                f'Resource limits: {summary["success"]} full, {summary["partial"]} partial, '
                f'{summary["failed"]} failed (of {summary["total"]} total).',
                'warning'
            )
        log_activity(current_user.id, 'resource_limits_apply_all', 'system', None,
                     {'total': summary.get('total'), 'success': summary.get('success'),
                      'partial': summary.get('partial'), 'failed': summary.get('failed')})
        return jsonify({'success': True, 'summary': summary})
    except Exception as e:
        logger.error(f"[resource-limits bulk] {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/admin/vps/<int:vps_id>/resource-limits/apply', methods=['POST'])
@login_required
@admin_required
def admin_vps_resource_limits_apply(vps_id):
    """Apply Proxmox-Grade Resource Limits to a single VPS."""
    try:
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT id, container_name, node_id, ram, cpu, storage FROM vps WHERE id = ?', (vps_id,))
            vps = cur.fetchone()
        if not vps:
            return jsonify({'success': False, 'error': 'VPS not found'}), 404
        ram_mb = None
        cpu_count = None
        disk_gb = None
        try:
            if vps['ram']: ram_mb = int(str(vps['ram']).replace('GB', '').strip()) * 1024
        except Exception: pass
        try:
            if vps['cpu']: cpu_count = int(str(vps['cpu']).strip())
        except Exception: pass
        try:
            if vps['storage']: disk_gb = int(str(vps['storage']).replace('GB', '').strip())
        except Exception: pass
        result = run_sync(apply_proxmox_resource_limits(
            vps['container_name'], vps['node_id'], ram_mb, cpu_count, disk_gb))
        applied = sum(1 for k in result if k.startswith('L') and k[1:].split('_')[0].isdigit() and result.get(k))
        log_activity(current_user.id, 'resource_limits_apply', 'vps', str(vps_id),
                     {'container': vps['container_name'], 'applied': applied, 'total': 11})
        return jsonify({
            'success': applied > 0,
            'applied': applied,
            'total': 11,
            'result': result
        })
    except Exception as e:
        logger.error(f"[resource-limits single] vps {vps_id}: {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/admin/snapshot-policy/apply-all', methods=['POST'])
@login_required
@admin_required
def admin_snapshot_policy_apply_all():
    """Apply snapshot/backup policy to every VPS in the database."""
    try:
        schedule = request.json.get('schedule') if request.json else None
        retention = request.json.get('retention') if request.json else None
        if retention is not None:
            try: retention = int(retention)
            except Exception: retention = None
        summary = run_sync(apply_snapshot_policy_to_all(schedule=schedule, retention=retention))
        if summary.get('success', 0) == summary.get('total', 0) and summary.get('total', 0) > 0:
            flash(f'Snapshot policy applied to all {summary["total"]} containers.', 'success')
        elif summary.get('total', 0) == 0:
            flash('No VPS containers to apply snapshot policy to.', 'info')
        else:
            flash(
                f'Snapshot policy: {summary["success"]} full, {summary["partial"]} partial, '
                f'{summary["failed"]} failed (of {summary["total"]} total).',
                'warning'
            )
        log_activity(current_user.id, 'snapshot_policy_apply_all', 'system', None,
                     {'total': summary.get('total'), 'success': summary.get('success'),
                      'partial': summary.get('partial'), 'failed': summary.get('failed')})
        return jsonify({'success': True, 'summary': summary})
    except Exception as e:
        logger.error(f"[snapshot-policy bulk] {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/admin/vps/<int:vps_id>/snapshot-policy/apply', methods=['POST'])
@login_required
@admin_required
def admin_vps_snapshot_policy_apply(vps_id):
    """Apply snapshot/backup policy to a single VPS."""
    try:
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT id, container_name, node_id FROM vps WHERE id = ?', (vps_id,))
            vps = cur.fetchone()
        if not vps:
            return jsonify({'success': False, 'error': 'VPS not found'}), 404
        result = run_sync(apply_snapshot_policy(vps_id, vps['container_name'], vps['node_id'],
                                                create_baseline=True))
        applied = sum(1 for k in result if k.startswith('L') and k[1:].split('_')[0].isdigit() and result.get(k))
        log_activity(current_user.id, 'snapshot_policy_apply', 'vps', str(vps_id),
                     {'container': vps['container_name'], 'applied': applied, 'total': 5})
        return jsonify({
            'success': applied > 0,
            'applied': applied,
            'total': 5,
            'result': result
        })
    except Exception as e:
        logger.error(f"[snapshot-policy single] vps {vps_id}: {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/admin/bandwidth-quota/apply-all', methods=['POST'])
@login_required
@admin_required
def admin_bandwidth_quota_apply_all():
    """Apply bandwidth quota to every VPS container."""
    try:
        quota_mb = request.json.get('quota_mb') if request.is_json else None
        if quota_mb is not None:
            try:
                quota_mb = int(quota_mb)
                if quota_mb <= 0:
                    quota_mb = None
            except (ValueError, TypeError):
                quota_mb = None
        summary = run_sync(apply_bandwidth_quota_to_all(quota_mb=quota_mb))
        log_activity(current_user.id, 'bandwidth_quota_apply_all', 'vps', 'all',
                     {'total': summary.get('total'), 'success': summary.get('success'),
                      'partial': summary.get('partial'), 'failed': summary.get('failed'),
                      'quota_mb': quota_mb})
        flash(f"Bandwidth Quota bulk apply: {summary.get('success')}/{summary.get('total')} VPS at {quota_mb or '100GB default'}", 'success')
        return jsonify({'success': True, 'summary': summary})
    except Exception as e:
        logger.error(f"[bw-quota bulk] {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/admin/vps/<int:vps_id>/bandwidth-quota/apply', methods=['POST'])
@login_required
@admin_required
def admin_vps_bandwidth_quota_apply(vps_id):
    """Apply bandwidth quota to a single VPS."""
    try:
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT id, container_name, node_id FROM vps WHERE id = ?', (vps_id,))
            vps = cur.fetchone()
        if not vps:
            return jsonify({'success': False, 'error': 'VPS not found'}), 404
        quota_mb = None
        if request.is_json:
            try:
                qm = request.json.get('quota_mb')
                if qm is not None and int(qm) > 0:
                    quota_mb = int(qm)
            except (ValueError, TypeError):
                pass
        result = run_sync(apply_bandwidth_quota(vps_id, vps['container_name'], vps['node_id'],
                                                quota_mb=quota_mb))
        applied = sum(1 for k in ('L1_db_quota', 'L2_chain', 'L3_rules', 'L4_reset_at', 'L5_suspend_rule') if result.get(k))
        log_activity(current_user.id, 'bandwidth_quota_apply', 'vps', str(vps_id),
                     {'container': vps['container_name'], 'applied': applied, 'total': 5,
                      'quota_mb': result.get('quota_mb')})
        return jsonify({
            'success': applied > 0,
            'applied': applied,
            'total': 5,
            'result': result
        })
    except Exception as e:
        logger.error(f"[bw-quota single] vps {vps_id}: {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/admin/vps/<int:vps_id>/bandwidth-quota/reset', methods=['POST'])
@login_required
@admin_required
def admin_vps_bandwidth_quota_reset(vps_id):
    """Manually reset a VPS's bandwidth counter to zero."""
    try:
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('''UPDATE vps
                           SET bandwidth_used_mb = 0,
                               bandwidth_reset_at = ?,
                               bandwidth_last_poll = ?,
                               updated_at = ?,
                               suspended = CASE WHEN suspended = 1 AND COALESCE(suspended_reason,'') LIKE 'Bandwidth quota exceeded%' THEN 0 ELSE suspended END,
                               suspended_reason = CASE WHEN suspended = 1 AND COALESCE(suspended_reason,'') LIKE 'Bandwidth quota exceeded%' THEN NULL ELSE suspended_reason END
                           WHERE id = ?''',
                        (get_next_month_start(), datetime.now().isoformat(),
                         datetime.now().isoformat(), vps_id))
            conn.commit()
            cur.execute('SELECT container_name, user_id FROM vps WHERE id = ?', (vps_id,))
            vps = cur.fetchone()
        if vps:
            try:
                create_notification(vps['user_id'], 'info', 'Bandwidth Reset',
                    f'Your bandwidth counter for {vps["container_name"]} has been reset by an administrator.')
            except Exception:
                pass
        log_activity(current_user.id, 'bandwidth_quota_reset', 'vps', str(vps_id), {})
        return jsonify({'success': True})
    except Exception as e:
        logger.error(f"[bw-quota reset] vps {vps_id}: {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/admin/vps/<int:vps_id>/bandwidth-quota/override', methods=['POST'])
@login_required
@admin_required
def admin_vps_bandwidth_quota_override(vps_id):
    """Set or clear an admin-override quota for a VPS."""
    try:
        data = request.get_json() or {}
        new_quota = data.get('quota_mb')
        note = data.get('note', '')
        with get_db() as conn:
            cur = conn.cursor()
            if new_quota in (None, 0, ''):
                cur.execute('''UPDATE vps
                               SET bandwidth_override_mb = NULL,
                                   bandwidth_override_user = NULL,
                                   bandwidth_override_note = NULL,
                                   bandwidth_quota_mb = COALESCE(NULLIF(bandwidth_override_mb, 0), bandwidth_quota_mb),
                                   updated_at = ?
                               WHERE id = ?''',
                            (datetime.now().isoformat(), vps_id))
            else:
                new_quota = int(new_quota)
                cur.execute('''UPDATE vps
                               SET bandwidth_override_mb = ?,
                                   bandwidth_override_user = ?,
                                   bandwidth_override_note = ?,
                                   bandwidth_quota_mb = ?,
                                   updated_at = ?
                               WHERE id = ?''',
                            (new_quota, current_user.id, note, new_quota,
                             datetime.now().isoformat(), vps_id))
            conn.commit()
        log_activity(current_user.id, 'bandwidth_quota_override', 'vps', str(vps_id),
                     {'quota_mb': new_quota, 'note': note})
        return jsonify({'success': True, 'quota_mb': new_quota})
    except Exception as e:
        logger.error(f"[bw-quota override] vps {vps_id}: {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/admin/resource-check', methods=['POST'])
@login_required
@admin_required
def admin_resource_check():
    cpu_threshold = int(get_setting('cpu_threshold', 90))
    ram_threshold = int(get_setting('ram_threshold', 90))
    
    suspended_count = 0
    vps_list = get_all_vps()
    
    for vps in vps_list:
        if vps['status'] == 'running' and not vps['suspended'] and not vps['whitelisted']:
            try:
                stats = run_sync(get_container_stats(vps['container_name'], vps['node_id']))
                cpu = stats['cpu']
                ram = stats['ram']['pct']
                
                if cpu > cpu_threshold or ram > ram_threshold:
                    reason = f"High resource usage: CPU {cpu:.1f}%, RAM {ram:.1f}%"
                    
                    run_sync(execute_lxc(vps['container_name'], f"stop {vps['container_name']} --force", node_id=vps['node_id']))
                    
                    history = vps['suspension_history']
                    history.append({
                        'time': datetime.now().isoformat(),
                        'reason': reason,
                        'by': 'Auto Resource Check'
                    })
                    
                    update_vps(vps['id'], suspended=1, status='stopped', suspension_history=history, suspended_reason=reason)
                    suspended_count += 1
                    log_activity(None, 'auto_suspend', 'vps', str(vps['id']), {'reason': reason})
                    create_notification(vps['user_id'], 'warning', 'VPS Auto-Suspended', 
                                      f'Your VPS {vps["container_name"]} has been suspended due to high resource usage.')
                    
                    if socketio:
                        socketio.emit('vps_suspended', {
                            'vps_id': vps['id'],
                            'reason': reason
                        }, room=f'vps_{vps["id"]}')
                        
            except Exception as e:
                logger.error(f"Resource check error for {vps['container_name']}: {e}")
    
    return jsonify({'success': True, 'suspended': suspended_count})

@app.route('/admin/system-info')
@login_required
@admin_required
def admin_system_info():
    """Comprehensive system information page"""
    import platform
    
    try:
        import psutil
        PSUTIL_AVAILABLE = True
    except ImportError:
        PSUTIL_AVAILABLE = False
        psutil = None
    
    # If it's an AJAX request, return JSON
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest' or request.args.get('format') == 'json':
        return get_system_info_json()
    
    # Regular page view - get all system info
    system_info = get_system_info_dict()
    
    return render_template('admin/system_info.html',
                         panel_name=get_setting('site_name', 'AVM PANEL'),
                         system_info=system_info,
                         psutil_available=PSUTIL_AVAILABLE)

def get_system_info_json():
    """Return system info as JSON for AJAX requests"""
    import platform
    
    try:
        lxc_version = subprocess.run(['lxc', '--version'], capture_output=True, text=True, timeout=5).stdout.strip()
    except:
        lxc_version = None
    
    try:
        python_version = platform.python_version()
    except:
        python_version = None
    
    disk_usage = {}
    for path in ['/', '/var', '/home']:
        if os.path.exists(path):
            try:
                usage = shutil.disk_usage(path)
                disk_usage[path] = {
                    'total': usage.total // (1024**3),
                    'used': usage.used // (1024**3),
                    'free': usage.free // (1024**3)
                }
            except:
                pass
    
    return jsonify({
        'hostname': platform.node(),
        'platform': platform.platform(),
        'python': python_version,
        'uptime': get_host_uptime(),
        'cpu_cores': os.cpu_count(),
        'cpu_percent': get_host_cpu_usage(),
        'memory': get_host_ram_usage(),
        'disk': get_host_disk_usage(),
        'disk_detailed': disk_usage,
        'lxc_version': lxc_version,
        'database_size': os.path.getsize(DATABASE_PATH) // (1024 * 1024) if os.path.exists(DATABASE_PATH) else 0
    })

def get_system_info_dict():
    """Get comprehensive system information as dictionary"""
    import platform
    
    try:
        import psutil
        PSUTIL_AVAILABLE = True
    except ImportError:
        PSUTIL_AVAILABLE = False
        psutil = None
    
    system_info = {}
    
    # Basic system information
    try:
        system_info['hostname'] = platform.node()
        system_info['platform'] = platform.platform()
        system_info['system'] = platform.system()
        system_info['release'] = platform.release()
        system_info['version'] = platform.version()
        system_info['machine'] = platform.machine()
        system_info['processor'] = platform.processor()
        system_info['python_version'] = platform.python_version()
        system_info['python_implementation'] = platform.python_implementation()
    except Exception as e:
        logger.error(f"Error getting basic system info: {e}")
    
    # Uptime
    try:
        system_info['uptime'] = get_host_uptime()
    except:
        system_info['uptime'] = 'Unknown'
    
    # CPU information
    try:
        system_info['cpu_count'] = os.cpu_count()
        system_info['cpu_usage'] = get_host_cpu_usage()
        
        # Try to get detailed CPU info
        if platform.system() == 'Linux':
            try:
                cpu_info_cmd = subprocess.run(['lscpu'], capture_output=True, text=True, timeout=5)
                if cpu_info_cmd.returncode == 0:
                    cpu_lines = cpu_info_cmd.stdout.strip().split('\n')
                    cpu_details = {}
                    for line in cpu_lines:
                        if ':' in line:
                            key, value = line.split(':', 1)
                            cpu_details[key.strip()] = value.strip()
                    system_info['cpu_details'] = cpu_details
            except:
                pass
    except Exception as e:
        logger.error(f"Error getting CPU info: {e}")
    
    # Memory information
    try:
        ram = get_host_ram_usage()
        system_info['memory'] = ram
        
        # Get swap info if available
        if PSUTIL_AVAILABLE:
            swap = psutil.swap_memory()
            system_info['swap'] = {
                'total': swap.total // (1024**2),
                'used': swap.used // (1024**2),
                'free': swap.free // (1024**2),
                'percent': swap.percent
            }
    except Exception as e:
        logger.error(f"Error getting memory info: {e}")
    
    # Disk information
    try:
        system_info['disk'] = get_host_disk_usage()
        
        # Detailed disk usage for multiple paths
        disk_usage = {}
        for path in ['/', '/var', '/home', '/tmp']:
            if os.path.exists(path):
                try:
                    usage = shutil.disk_usage(path)
                    disk_usage[path] = {
                        'total': usage.total // (1024**3),
                        'used': usage.used // (1024**3),
                        'free': usage.free // (1024**3),
                        'percent': (usage.used / usage.total * 100) if usage.total > 0 else 0
                    }
                except:
                    pass
        system_info['disk_detailed'] = disk_usage
        
        # Get disk partitions if psutil available
        if PSUTIL_AVAILABLE:
            partitions = []
            for partition in psutil.disk_partitions():
                try:
                    usage = psutil.disk_usage(partition.mountpoint)
                    partitions.append({
                        'device': partition.device,
                        'mountpoint': partition.mountpoint,
                        'fstype': partition.fstype,
                        'total': usage.total // (1024**3),
                        'used': usage.used // (1024**3),
                        'free': usage.free // (1024**3),
                        'percent': usage.percent
                    })
                except:
                    pass
            system_info['partitions'] = partitions
    except Exception as e:
        logger.error(f"Error getting disk info: {e}")
    
    # Network information
    try:
        if PSUTIL_AVAILABLE:
            net_if_addrs = psutil.net_if_addrs()
            network_interfaces = {}
            for interface, addrs in net_if_addrs.items():
                network_interfaces[interface] = []
                for addr in addrs:
                    network_interfaces[interface].append({
                        'family': str(addr.family),
                        'address': addr.address,
                        'netmask': addr.netmask,
                        'broadcast': addr.broadcast
                    })
            system_info['network_interfaces'] = network_interfaces
    except Exception as e:
        logger.error(f"Error getting network info: {e}")
    
    # LXC/LXD information
    try:
        lxc_version = subprocess.run(['lxc', '--version'], capture_output=True, text=True, timeout=5)
        system_info['lxc_version'] = lxc_version.stdout.strip() if lxc_version.returncode == 0 else 'Not installed'
        
        # Get LXC storage pools
        try:
            pools_cmd = subprocess.run(['lxc', 'storage', 'list', '--format', 'json'], 
                                      capture_output=True, text=True, timeout=10)
            if pools_cmd.returncode == 0:
                system_info['lxc_pools'] = json.loads(pools_cmd.stdout)
        except:
            pass
        
        # Get LXC networks
        try:
            networks_cmd = subprocess.run(['lxc', 'network', 'list', '--format', 'json'], 
                                         capture_output=True, text=True, timeout=10)
            if networks_cmd.returncode == 0:
                system_info['lxc_networks'] = json.loads(networks_cmd.stdout)
        except:
            pass
    except:
        system_info['lxc_version'] = 'Not installed'
    
    # OS information
    try:
        if platform.system() == 'Linux' and os.path.exists('/etc/os-release'):
            with open('/etc/os-release', 'r') as f:
                os_release = {}
                for line in f:
                    if '=' in line:
                        key, value = line.strip().split('=', 1)
                        os_release[key] = value.strip('"')
                system_info['os_release'] = os_release
    except Exception as e:
        logger.error(f"Error getting OS info: {e}")
    
    # Database information
    try:
        db_size = os.path.getsize(DATABASE_PATH) // (1024 * 1024) if os.path.exists(DATABASE_PATH) else 0
        system_info['database'] = {
            'path': DATABASE_PATH,
            'size_mb': db_size,
            'exists': os.path.exists(DATABASE_PATH)
        }
        
        # Get database stats
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute("SELECT COUNT(*) FROM users")
            user_count = cur.fetchone()[0]
            cur.execute("SELECT COUNT(*) FROM vps")
            vps_count = cur.fetchone()[0]
            cur.execute("SELECT COUNT(*) FROM nodes")
            node_count = cur.fetchone()[0]
            
            system_info['database']['stats'] = {
                'users': user_count,
                'vps': vps_count,
                'nodes': node_count
            }
    except Exception as e:
        logger.error(f"Error getting database info: {e}")
    
    # Flask/Application information
    try:
        system_info['app'] = {
            'version': PANEL_VERSION,
            'flask_version': flask.__version__,
            'debug_mode': app.debug,
            'testing_mode': app.testing
        }
    except Exception as e:
        logger.error(f"Error getting app info: {e}")
    
    # Process information
    try:
        if PSUTIL_AVAILABLE:
            process = psutil.Process()
            system_info['process'] = {
                'pid': process.pid,
                'memory_mb': process.memory_info().rss // (1024**2),
                'cpu_percent': process.cpu_percent(interval=0.1),
                'threads': process.num_threads(),
                'create_time': datetime.fromtimestamp(process.create_time()).strftime('%Y-%m-%d %H:%M:%S')
            }
    except Exception as e:
        logger.error(f"Error getting process info: {e}")
    
    # Environment Variables
    try:
        env_vars = {
            'PANEL_NAME': PANEL_NAME,
            'PANEL_VERSION': PANEL_VERSION,
            'PANEL_DEVELOPER': PANEL_DEVELOPER,
            'DATABASE_PATH': DATABASE_PATH,
            'HOST': HOST,
            'PORT': PORT,
            'MAIN_ADMIN_USERNAME': os.getenv('MAIN_ADMIN_USERNAME', 'admin'),
            'MAIN_ADMIN_EMAIL': os.getenv('MAIN_ADMIN_EMAIL', 'admin@localhost'),
            'YOUR_SERVER_IP': YOUR_SERVER_IP,
            'DEFAULT_STORAGE_POOL': DEFAULT_STORAGE_POOL,
            'DEBUG_MODE': os.getenv('DEBUG_MODE', 'False'),
            'AUTO_BACKUP_INTERVAL': os.getenv('AUTO_BACKUP_INTERVAL', '3600'),
            'STATS_UPDATE_INTERVAL': os.getenv('STATS_UPDATE_INTERVAL', '5'),
            'PYTHON_VERSION': platform.python_version(),
            'PYTHONPATH': os.getenv('PYTHONPATH', 'Not set'),
            'PATH': os.getenv('PATH', 'Not set')[:200] + '...' if os.getenv('PATH') and len(os.getenv('PATH', '')) > 200 else os.getenv('PATH', 'Not set'),
            'HOME': os.getenv('HOME', 'Not set'),
            'USER': os.getenv('USER', 'Not set'),
            'SHELL': os.getenv('SHELL', 'Not set'),
            'LANG': os.getenv('LANG', 'Not set'),
            'TZ': os.getenv('TZ', 'Not set')
        }
        
        # Add current working directory
        env_vars['CURRENT_DIRECTORY'] = os.getcwd()
        
        # Add Python executable path
        env_vars['PYTHON_EXECUTABLE'] = sys.executable
        
        system_info['environment'] = env_vars
    except Exception as e:
        logger.error(f"Error getting environment variables: {e}")
        system_info['environment'] = {}
    
    return system_info

@app.route('/admin/vacuum', methods=['POST'])
@login_required
@admin_required
def admin_vacuum():
    try:
        with get_db() as conn:
            conn.execute("VACUUM")
        log_activity(current_user.id, 'vacuum_db', 'system')
        create_notification(current_user.id, 'success', 'Database Vacuumed', 'Database has been optimized.')
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/admin/logs')
@login_required
@admin_required
def admin_logs():
    """Comprehensive log viewer page"""
    log_type = request.args.get('type', 'avm')
    lines = int(request.args.get('lines', 100))
    download = request.args.get('download', 'false') == 'true'
    
    log_files = {
        'avm': 'avm.log',
        'lxc': '/var/log/lxc/lxc.log',
        'system': '/var/log/syslog',
        'auth': '/var/log/auth.log',
        'kern': '/var/log/kern.log',
        'panel': 'avm.log'
    }
    
    log_file = log_files.get(log_type, 'avm.log')
    
    # If it's an AJAX request for log content
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest' or download:
        try:
            if os.path.exists(log_file):
                with open(log_file, 'r', encoding='utf-8', errors='ignore') as f:
                    all_lines = f.readlines()
                    last_lines = all_lines[-lines:] if lines > 0 else all_lines
                    log_content = ''.join(last_lines)
                    
                    if download:
                        from datetime import datetime
                        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                        filename = f"{log_type}_logs_{timestamp}.log"
                        response = make_response(log_content)
                        response.headers['Content-Type'] = 'text/plain'
                        response.headers['Content-Disposition'] = f'attachment; filename={filename}'
                        return response
                    
                    return jsonify({
                        'success': True, 
                        'logs': log_content,
                        'file': log_file,
                        'size': os.path.getsize(log_file),
                        'lines_total': len(all_lines),
                        'lines_shown': len(last_lines)
                    })
            else:
                return jsonify({'success': False, 'error': f'Log file not found: {log_file}'})
        except Exception as e:
            logger.error(f"Error reading log file: {e}")
            return jsonify({'success': False, 'error': str(e)})
    
    # Regular page view
    # Get available log files with their info
    available_logs = []
    for name, path in log_files.items():
        if os.path.exists(path):
            try:
                stat = os.stat(path)
                available_logs.append({
                    'name': name,
                    'path': path,
                    'size': stat.st_size,
                    'size_mb': stat.st_size / (1024 * 1024),
                    'modified': datetime.fromtimestamp(stat.st_mtime).strftime('%Y-%m-%d %H:%M:%S')
                })
            except:
                pass
    
    return render_template('admin/logs.html',
                         panel_name=get_setting('site_name', 'AVM PANEL'),
                         available_logs=available_logs,
                         current_log=log_type)

# ============================================================================
# Admin - API Management
# ============================================================================

@app.route('/admin/api')
@login_required
@admin_required
def admin_api():
    """API management page"""
    with get_db() as conn:
        cur = conn.cursor()
        
        # Get all API keys
        if current_user.is_main_admin:
            cur.execute('''SELECT ak.*, u.username, u.email 
                          FROM api_keys ak
                          JOIN users u ON ak.user_id = u.id
                          ORDER BY ak.created_at DESC''')
        else:
            cur.execute('''SELECT ak.*, u.username, u.email 
                          FROM api_keys ak
                          JOIN users u ON ak.user_id = u.id
                          WHERE ak.user_id = ?
                          ORDER BY ak.created_at DESC''', (current_user.id,))
        
        api_keys = [dict(row) for row in cur.fetchall()]
        
        # Get users for dropdown (admin only)
        users = []
        if current_user.is_admin:
            cur.execute('SELECT id, username, email FROM users ORDER BY username')
            users = [dict(row) for row in cur.fetchall()]
    
    return render_template('admin/api.html',
                         panel_name=get_setting('site_name', 'AVM PANEL'),
                         api_keys=api_keys,
                         users=users)

@app.route('/admin/api/create', methods=['POST'])
@login_required
@admin_required
def admin_api_create():
    """Create new API key"""
    try:
        data = request.get_json() if request.is_json else request.form
        
        name = data.get('name')
        description = data.get('description', '')
        user_id = int(data.get('user_id', current_user.id))
        expires_days = data.get('expires_days')
        
        if not name:
            return jsonify({'success': False, 'error': 'API key name is required'}), 400
        
        # Only admins can create keys for other users
        if not current_user.is_admin and user_id != current_user.id:
            return jsonify({'success': False, 'error': 'Permission denied'}), 403
        
        # Generate API key
        api_key = f"avmpanel_{secrets.token_urlsafe(48)}"
        
        # Calculate expiration
        expires_at = None
        if expires_days:
            expires_at = (datetime.now() + timedelta(days=int(expires_days))).isoformat()
        
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('''INSERT INTO api_keys 
                          (user_id, key, name, description, is_active, created_at, expires_at)
                          VALUES (?, ?, ?, ?, ?, ?, ?)''',
                       (user_id, api_key, name, description, 1, datetime.now().isoformat(), expires_at))
            conn.commit()
            key_id = cur.lastrowid
        
        log_activity(current_user.id, 'create_api_key', 'api_key', str(key_id), {'name': name})
        
        return jsonify({
            'success': True,
            'message': 'API key created successfully',
            'api_key': api_key,
            'key_id': key_id
        })
    except Exception as e:
        logger.error(f"Error creating API key: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/admin/api/<int:key_id>/toggle', methods=['POST'])
@login_required
@admin_required
def admin_api_toggle(key_id):
    """Toggle API key active status"""
    try:
        with get_db() as conn:
            cur = conn.cursor()
            
            # Check ownership
            cur.execute('SELECT user_id, is_active FROM api_keys WHERE id = ?', (key_id,))
            result = cur.fetchone()
            
            if not result:
                return jsonify({'success': False, 'error': 'API key not found'}), 404
            
            if not current_user.is_admin and result['user_id'] != current_user.id:
                return jsonify({'success': False, 'error': 'Permission denied'}), 403
            
            new_status = 0 if result['is_active'] else 1
            cur.execute('UPDATE api_keys SET is_active = ? WHERE id = ?', (new_status, key_id))
            conn.commit()
        
        log_activity(current_user.id, 'toggle_api_key', 'api_key', str(key_id), 
                    {'status': 'active' if new_status else 'inactive'})
        
        return jsonify({
            'success': True,
            'message': f'API key {"activated" if new_status else "deactivated"}',
            'is_active': new_status
        })
    except Exception as e:
        logger.error(f"Error toggling API key: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/admin/api/<int:key_id>/delete', methods=['POST', 'DELETE'])
@login_required
@admin_required
def admin_api_delete(key_id):
    """Delete API key"""
    try:
        with get_db() as conn:
            cur = conn.cursor()
            
            # Check ownership
            cur.execute('SELECT user_id FROM api_keys WHERE id = ?', (key_id,))
            result = cur.fetchone()
            
            if not result:
                return jsonify({'success': False, 'error': 'API key not found'}), 404
            
            if not current_user.is_admin and result['user_id'] != current_user.id:
                return jsonify({'success': False, 'error': 'Permission denied'}), 403
            
            cur.execute('DELETE FROM api_keys WHERE id = ?', (key_id,))
            conn.commit()
        
        log_activity(current_user.id, 'delete_api_key', 'api_key', str(key_id))
        
        return jsonify({
            'success': True,
            'message': 'API key deleted successfully'
        })
    except Exception as e:
        logger.error(f"Error deleting API key: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/admin/activity/clear', methods=['POST'])
@login_required
@admin_required
def admin_activity_clear():
    """Clear all activity log entries."""
    try:
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT COUNT(*) FROM activity_logs')
            count = cur.fetchone()[0] or 0
            cur.execute('DELETE FROM activity_logs')
            conn.commit()
        log_activity(current_user.id, 'activity_clear', 'activity_logs', None,
                     {'cleared_count': count, 'message': f'Cleared {count} activity log entries'})
        return jsonify({'success': True, 'message': f'Cleared {count} activity entries', 'cleared': count})
    except Exception as e:
        logger.error(f"Error clearing activity log: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/admin/activity/delete/<int:entry_id>', methods=['POST'])
@login_required
@admin_required
def admin_activity_delete(entry_id):
    """Delete a single activity log entry."""
    try:
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT id, action, user_id FROM activity_logs WHERE id = ?', (entry_id,))
            row = cur.fetchone()
            if not row:
                return jsonify({'success': False, 'error': 'Entry not found'}), 404
            cur.execute('DELETE FROM activity_logs WHERE id = ?', (entry_id,))
            conn.commit()
        log_activity(current_user.id, 'activity_delete', 'activity_logs', str(entry_id),
                     {'entry_id': entry_id, 'deleted_action': row['action']})
        return jsonify({'success': True, 'message': 'Entry removed'})
    except Exception as e:
        logger.error(f"Error deleting activity entry: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/admin/emergency-stop-all', methods=['POST'])
@login_required
@admin_required
def admin_emergency_stop_all():
    """
    Force-stop EVERY VPS on every node regardless of status or suspension.
    Runs stops in parallel threads for speed and returns per-VPS results.
    """
    import concurrent.futures

    vps_list = get_all_vps()
    results  = []
    stopped  = 0
    failed   = 0

    def _stop_one(vps):
        try:
            run_sync(execute_lxc(
                vps['container_name'],
                f"stop {vps['container_name']} --force",
                node_id=vps['node_id'],
                timeout=30
            ))
            update_vps(vps['id'], status='stopped',
                       last_stopped=datetime.now().isoformat())
            return {'container': vps['container_name'],
                    'owner':     vps.get('username', str(vps['user_id'])),
                    'success':   True}
        except Exception as e:
            logger.error(f"Emergency stop failed for {vps['container_name']}: {e}")
            # Still mark as stopped in DB so UI reflects it
            try:
                update_vps(vps['id'], status='stopped')
            except Exception:
                pass
            return {'container': vps['container_name'],
                    'owner':     vps.get('username', str(vps['user_id'])),
                    'success':   False,
                    'error':     str(e)}

    # Enrich vps_list with owner usernames
    user_map = {}
    try:
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT id, username FROM users')
            user_map = {r['id']: r['username'] for r in cur.fetchall()}
    except Exception:
        pass
    for vps in vps_list:
        vps['username'] = user_map.get(vps['user_id'], str(vps['user_id']))

    # Run all stops in parallel (max 10 at a time to avoid overwhelming nodes)
    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
        futures = {executor.submit(_stop_one, vps): vps for vps in vps_list}
        for future in concurrent.futures.as_completed(futures):
            res = future.result()
            results.append(res)
            if res['success']:
                stopped += 1
            else:
                failed += 1

    log_activity(current_user.id, 'emergency_stop_all', 'system', None,
                 {'stopped': stopped, 'failed': failed, 'total': len(vps_list)})
    create_notification(
        current_user.id, 'warning', 'Emergency Stop',
        f'Emergency stop completed. {stopped}/{len(vps_list)} VPS stopped.'
        + (f' {failed} failed.' if failed else '')
    )

    # Emit SocketIO update for all stopped VPS
    if socketio:
        for res in results:
            if res['success']:
                socketio.emit('vps_status_change',
                              {'status': 'stopped'},
                              room=f"vps_container_{res['container']}")

    return jsonify({
        'success':  True,
        'total':    len(vps_list),
        'stopped':  stopped,
        'failed':   failed,
        'results':  results
    })

@app.route('/admin/emergency-reboot-all', methods=['POST'])
@login_required
@admin_required
def admin_emergency_reboot_all():
    rebooted = 0
    vps_list = get_all_vps()
    
    for vps in vps_list:
        if vps['status'] == 'running' and not vps['suspended']:
            try:
                run_sync(execute_lxc(vps['container_name'], f"restart {vps['container_name']}", node_id=vps['node_id']))
                rebooted += 1
            except Exception as e:
                logger.error(f"Emergency reboot failed for {vps['container_name']}: {e}")
    
    log_activity(current_user.id, 'emergency_reboot_all', 'system', None, {'rebooted': rebooted})
    create_notification(current_user.id, 'warning', 'Emergency Reboot', f'Emergency reboot completed. {rebooted} VPS rebooted.')
    return jsonify({'success': True, 'rebooted': rebooted})

@app.route('/admin/clear-suspensions', methods=['POST'])
@login_required
@admin_required
def admin_clear_suspensions():
    cleared = 0
    vps_list = get_all_vps()
    
    for vps in vps_list:
        if vps['suspended']:
            history = vps.get('suspension_history', [])
            history.append({
                'time': datetime.now().isoformat(),
                'reason': 'Suspension cleared by admin',
                'by': current_user.username
            })
            update_vps(vps['id'], suspended=0, status='stopped', suspended_reason=None, suspension_history=history)
            cleared += 1
            create_notification(vps['user_id'], 'success', 'VPS Unsuspended', f'Your VPS {vps["container_name"]} has been unsuspended.')
    
    log_activity(current_user.id, 'clear_suspensions', 'system', None, {'cleared': cleared})
    return jsonify({'success': True, 'cleared': cleared})

@app.route('/admin/reset-ports', methods=['POST'])
@login_required
@admin_required
def admin_reset_ports():
    recreated = 0
    vps_list = get_all_vps()
    
    for vps in vps_list:
        try:
            count = run_sync(recreate_port_forwards(vps['container_name']))
            recreated += count
        except Exception as e:
            logger.error(f"Port reset failed for {vps['container_name']}: {e}")
    
    log_activity(current_user.id, 'reset_ports', 'system', None, {'recreated': recreated})
    return jsonify({'success': True, 'recreated': recreated})

@app.route('/admin/node/<int:node_id>')
@login_required
@admin_required
def admin_node_get(node_id):
    node = get_node(node_id)
    if not node:
        return jsonify({'error': 'Node not found'}), 404
    
    return jsonify(node)

@app.route('/admin/nodes/<int:node_id>/check')
@login_required
@admin_required
def admin_node_check(node_id):
    try:
        node = get_node(node_id)
        if not node:
            return jsonify({'success': False, 'error': 'Node not found'}), 404
        
        logger.info(f"Checking node {node_id}: {node['name']}")
        
        # Get node status
        try:
            status = run_sync(get_node_status(node_id))
            logger.info(f"Node {node_id} status: {status.get('status', 'unknown')}")
        except Exception as e:
            logger.error(f"Failed to get status for node {node_id}: {e}")
            status = {'status': 'Error', 'online': False}
        
        # Get host stats
        try:
            stats = run_sync(get_host_stats(node_id))
            logger.info(f"Node {node_id} stats retrieved successfully")
        except Exception as e:
            logger.error(f"Failed to get stats for node {node_id}: {e}")
            stats = {"cpu": 0.0, "ram": {'percent': 0.0}, "disk": {'percent': 'Unknown'}, "uptime": "Unknown"}
        
        # Get VPS count
        try:
            vps_count = get_current_vps_count(node_id)
        except Exception as e:
            logger.error(f"Failed to get VPS count for node {node_id}: {e}")
            vps_count = 0
        
        # Get storage pools
        try:
            pools = run_sync(execute_lxc("", "storage list", node_id=node_id, timeout=10))
        except Exception as e:
            logger.debug(f"Failed to get storage pools for node {node_id}: {e}")
            pools = None
        
        # Get networks
        try:
            networks = run_sync(execute_lxc("", "network list", node_id=node_id, timeout=10))
        except Exception as e:
            logger.debug(f"Failed to get networks for node {node_id}: {e}")
            networks = None
        
        return jsonify({
            'success': True,
            'id': node['id'],
            'name': node['name'],
            'status': status,
            'online': status.get('online', False),
            'stats': stats,
            'vps_count': vps_count,
            'total_vps': node['total_vps'],
            'pools': pools,
            'networks': networks,
            'ip_addresses': node.get('ip_addresses', []),
            'ip_aliases': node.get('ip_aliases', [])
        })
    
    except Exception as e:
        logger.error(f"Error checking node {node_id}: {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/admin/nodes/<int:node_id>/view')
@login_required
@admin_required
def admin_node_view(node_id):
    """Detailed node view with comprehensive system information"""
    try:
        node = get_node(node_id)
        if not node:
            flash('Node not found', 'danger')
            return redirect(url_for('admin_nodes'))
        
        # Get node status
        status = run_sync(get_node_status(node_id))
        
        # Get basic stats
        stats = run_sync(get_host_stats(node_id))
        
        # Get VPS count
        vps_count = get_current_vps_count(node_id)
        
        # Get detailed system information
        system_info = {}
        
        if node['is_local']:
            # Local node - get detailed info directly
            try:
                # CPU info
                cpu_info_cmd = "lscpu | grep -E 'Model name|CPU\\(s\\)|Thread|Core|Socket|MHz'"
                cpu_info = subprocess.run(cpu_info_cmd, shell=True, capture_output=True, text=True, timeout=5)
                system_info['cpu_details'] = cpu_info.stdout if cpu_info.returncode == 0 else "N/A"
                
                # Memory info
                mem_info_cmd = "free -h | grep -E 'Mem|Swap'"
                mem_info = subprocess.run(mem_info_cmd, shell=True, capture_output=True, text=True, timeout=5)
                system_info['memory_details'] = mem_info.stdout if mem_info.returncode == 0 else "N/A"
                
                # OS info
                os_info_cmd = "cat /etc/os-release | grep -E 'PRETTY_NAME|VERSION'"
                os_info = subprocess.run(os_info_cmd, shell=True, capture_output=True, text=True, timeout=5)
                system_info['os_details'] = os_info.stdout if os_info.returncode == 0 else "N/A"
                
                # Kernel info
                kernel_cmd = "uname -r"
                kernel_info = subprocess.run(kernel_cmd, shell=True, capture_output=True, text=True, timeout=5)
                system_info['kernel'] = kernel_info.stdout.strip() if kernel_info.returncode == 0 else "N/A"
                
                # Disk info
                disk_cmd = "df -h | grep -E '^/dev/'"
                disk_info = subprocess.run(disk_cmd, shell=True, capture_output=True, text=True, timeout=5)
                system_info['disk_details'] = disk_info.stdout if disk_info.returncode == 0 else "N/A"
                
            except Exception as e:
                logger.error(f"Error getting local system info: {e}")
        else:
            # Remote node - get info via API
            try:
                import requests
                headers = {"X-API-Key": node["api_key"]}
                verify_ssl = bool(node.get('verify_ssl', 1))
                
                # Get system info from node agent
                response = requests.get(f"{node['url']}/api/info", headers=headers, timeout=10, verify=verify_ssl)
                if response.status_code == 200:
                    info = response.json()
                    system_info['version'] = info.get('version', 'N/A')
                    system_info['python_version'] = info.get('python_version', 'N/A')
                
                # Try to get detailed info via execute
                try:
                    cpu_details = run_sync(execute_lxc("", "exec -- lscpu | grep -E 'Model name|CPU\\(s\\)|Thread|Core|Socket|MHz'", node_id=node_id, timeout=10))
                    system_info['cpu_details'] = cpu_details
                except:
                    system_info['cpu_details'] = "N/A"
                
                try:
                    os_details = run_sync(execute_lxc("", "exec -- cat /etc/os-release | grep -E 'PRETTY_NAME|VERSION'", node_id=node_id, timeout=10))
                    system_info['os_details'] = os_details
                except:
                    system_info['os_details'] = "N/A"
                
                try:
                    kernel = run_sync(execute_lxc("", "exec -- uname -r", node_id=node_id, timeout=10))
                    system_info['kernel'] = kernel.strip()
                except:
                    system_info['kernel'] = "N/A"
                    
            except Exception as e:
                logger.error(f"Error getting remote system info: {e}")
        
        # Get storage pools
        try:
            pools = run_sync(execute_lxc("", "storage list", node_id=node_id, timeout=10))
        except:
            pools = None
        
        # Get networks
        try:
            networks = run_sync(execute_lxc("", "network list", node_id=node_id, timeout=10))
        except:
            networks = None
        
        # Get list of VPS on this node
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT * FROM vps WHERE node_id = ? ORDER BY created_at DESC', (node_id,))
            vps_list = [dict(row) for row in cur.fetchall()]
        
        return render_template('admin/node_view.html',
                             panel_name=get_setting('site_name', 'AVM PANEL'),
                             node=node,
                             status=status,
                             stats=stats,
                             vps_count=vps_count,
                             vps_list=vps_list,
                             system_info=system_info,
                             pools=pools,
                             networks=networks)
    
    except Exception as e:
        logger.error(f"Error viewing node {node_id}: {e}", exc_info=True)
        flash(f'Error loading node details: {str(e)}', 'danger')
        return redirect(url_for('admin_nodes'))

@app.route('/admin/user/create', methods=['POST'])
@login_required
@admin_required
def admin_user_create():
    # Accept both JSON and form data
    if request.is_json:
        data = request.get_json() or {}
    else:
        data = request.form

    username = data.get('username', '').strip()
    email = data.get('email', '').strip()
    password = data.get('password', '')
    is_admin = str(data.get('is_admin', 'false')).lower() in ('true', '1', 'on')
    port_quota = int(data.get('port_quota', 5) or 5)

    if not username or not email or not password:
        return jsonify({'success': False, 'error': 'Missing fields'}), 400

    if User.get_by_username(username):
        return jsonify({'success': False, 'error': 'Username already exists'}), 400

    if User.get_by_email(email):
        return jsonify({'success': False, 'error': 'Email already exists'}), 400

    password_hash = generate_password_hash(password)
    api_key = generate_api_key()
    now = datetime.now().isoformat()

    try:
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('''INSERT INTO users
                (username, email, password_hash, is_admin, created_at, last_login, api_key, preferences)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)''',
                (username, email, password_hash, 1 if is_admin else 0, now, now, api_key, '{}'))
            user_id = cur.lastrowid

            if port_quota > 0:
                cur.execute('INSERT OR IGNORE INTO port_allocations (user_id, allocated_ports, used_ports, updated_at) VALUES (?, ?, ?, ?)',
                           (user_id, port_quota, 0, now))

            conn.commit()

        log_activity(current_user.id, 'create_user', 'user', str(user_id), {'username': username})
        create_notification(user_id, 'success', 'Welcome!', f'Your account has been created by an administrator.')
        return jsonify({'success': True, 'user_id': user_id})
    except Exception as e:
        logger.error(f"User creation error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/admin/user/<int:user_id>/regenerate-api', methods=['POST'])
@login_required
@admin_required
def admin_user_regenerate_api(user_id):
    new_key = generate_api_key()
    
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('UPDATE users SET api_key = ? WHERE id = ?', (new_key, user_id))
        conn.commit()
    
    log_activity(current_user.id, 'regenerate_user_api', 'user', str(user_id))
    create_notification(user_id, 'warning', 'API Key Regenerated', 'Your API key has been regenerated by an administrator.')
    return jsonify({'success': True, 'api_key': new_key})

@app.route('/admin/users/<int:user_id>/reset-password', methods=['POST'])
@login_required
@admin_required
def admin_user_reset_password(user_id):
    password = request.form.get('password')
    
    if not password or len(password) < 8:
        return jsonify({'success': False, 'error': 'Invalid password'}), 400
    
    password_hash = generate_password_hash(password)
    
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('UPDATE users SET password_hash = ? WHERE id = ?', (password_hash, user_id))
        conn.commit()
    
    log_activity(current_user.id, 'reset_user_password', 'user', str(user_id))
    create_notification(user_id, 'warning', 'Password Reset', 'Your password has been reset by an administrator.')
    return jsonify({'success': True})

@app.route('/share/vps/<int:vps_id>', methods=['POST'])
@login_required
def share_vps(vps_id):
    """Share VPS access with another user"""
    try:
        logger.info(f"=== Share VPS Request: VPS ID {vps_id}, User {current_user.id} ===")
        
        vps = get_vps_by_id(vps_id)
        if not vps:
            logger.error(f"VPS {vps_id} not found")
            return jsonify({'success': False, 'error': 'VPS not found'}), 404
            
        if vps['user_id'] != current_user.id:
            logger.error(f"Access denied: VPS owner is {vps['user_id']}, requester is {current_user.id}")
            return jsonify({'success': False, 'error': 'Access denied - you are not the owner'}), 403
        
        # Get username from form data or JSON
        username = request.form.get('username') or (request.json.get('username') if request.is_json else None)
        if not username:
            logger.error("No username provided")
            return jsonify({'success': False, 'error': 'Username required'}), 400
        
        logger.info(f"Attempting to share with username: {username}")
        
        # Find user by username
        user = User.get_by_username(username)
        if not user:
            logger.error(f"User '{username}' not found")
            return jsonify({'success': False, 'error': f'User "{username}" not found'}), 404
        
        logger.info(f"Found user: {user.username} (ID: {user.id})")
        
        # Check if trying to share with self
        if user.id == current_user.id:
            logger.error("Attempted to share with self")
            return jsonify({'success': False, 'error': 'Cannot share with yourself'}), 400
        
        # Get current shared_with list
        shared_with = vps.get('shared_with', []) or []
        if not isinstance(shared_with, list):
            shared_with = []
        
        logger.info(f"Current shared_with list: {shared_with}")
        
        # Check if already shared
        if str(user.id) in [str(uid) for uid in shared_with]:
            logger.warning(f"VPS already shared with user {user.id}")
            return jsonify({'success': False, 'error': f'VPS already shared with {username}'}), 400
        
        # Add user to shared list
        shared_with.append(str(user.id))
        logger.info(f"New shared_with list: {shared_with}")
        
        # Update VPS
        logger.info(f"Calling update_vps with shared_with={shared_with}")
        update_vps(vps_id, shared_with=shared_with)
        
        # Verify the update
        updated_vps = get_vps_by_id(vps_id)
        logger.info(f"After update, shared_with in DB: {updated_vps.get('shared_with', [])}")
        
        # Log and notify
        log_activity(current_user.id, 'share_vps', 'vps', str(vps_id), {'shared_with': user.id, 'username': username})
        create_notification(user.id, 'info', 'VPS Shared', f'{current_user.username} shared VPS {vps["container_name"]} with you.')
        
        logger.info(f"Successfully shared VPS {vps_id} with user {user.id} ({username})")
        return jsonify({'success': True, 'message': f'VPS shared with {username}'})
        
    except Exception as e:
        logger.error(f"Error sharing VPS {vps_id}: {e}", exc_info=True)
        return jsonify({'success': False, 'error': f'Failed to share VPS: {str(e)}'}), 500

@app.route('/unshare/vps/<int:vps_id>', methods=['POST'])
@login_required
def unshare_vps(vps_id):
    """Remove VPS access from a user"""
    try:
        vps = get_vps_by_id(vps_id)
        if not vps:
            return jsonify({'success': False, 'error': 'VPS not found'}), 404
            
        if vps['user_id'] != current_user.id:
            return jsonify({'success': False, 'error': 'Access denied - you are not the owner'}), 403
        
        # Get user_id from form data or JSON
        user_id = request.form.get('user_id') or request.json.get('user_id') if request.is_json else None
        if not user_id:
            return jsonify({'success': False, 'error': 'User ID required'}), 400
        
        # Get current shared_with list
        shared_with = vps.get('shared_with', []) or []
        if not isinstance(shared_with, list):
            shared_with = []
        
        # Convert to string for comparison
        user_id_str = str(user_id)
        
        # Check if user is in shared list
        if user_id_str not in [str(uid) for uid in shared_with]:
            return jsonify({'success': False, 'error': 'VPS not shared with this user'}), 400
        
        # Remove user from shared list
        shared_with = [uid for uid in shared_with if str(uid) != user_id_str]
        update_vps(vps_id, shared_with=shared_with)
        
        # Log and notify
        log_activity(current_user.id, 'unshare_vps', 'vps', str(vps_id), {'unshared': user_id})
        create_notification(int(user_id), 'info', 'VPS Unshared', f'{current_user.username} removed your access to VPS {vps["container_name"]}.')
        
        logger.info(f"VPS {vps_id} unshared from user {user_id} by {current_user.id}")
        return jsonify({'success': True, 'message': 'Access removed successfully'})
        
    except Exception as e:
        logger.error(f"Error unsharing VPS {vps_id}: {e}", exc_info=True)
        return jsonify({'success': False, 'error': f'Failed to remove access: {str(e)}'}), 500

# ============================================================================
# API Routes
# ============================================================================
@app.route('/api/ping', methods=['GET'])
def api_ping():
    api_key = request.args.get('api_key')
    if not api_key:
        return jsonify({'error': 'API key required'}), 401
    
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT id FROM nodes WHERE api_key = ?', (api_key,))
        node = cur.fetchone()
    
    if not node:
        return jsonify({'error': 'Invalid API key'}), 401
    
    return jsonify({'status': 'ok', 'time': datetime.now().isoformat()})

@app.route('/api/execute', methods=['POST'])
def api_execute():
    api_key = request.args.get('api_key')
    if not api_key:
        return jsonify({'error': 'API key required'}), 401
    
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT id FROM nodes WHERE api_key = ?', (api_key,))
        node = cur.fetchone()
    
    if not node:
        return jsonify({'error': 'Invalid API key'}), 401
    
    data = request.get_json()
    command = data.get('command')
    
    if not command:
        return jsonify({'error': 'Command required'}), 400
    
    try:
        cmd = shlex.split(command)
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        
        return jsonify({
            'stdout': proc.stdout,
            'stderr': proc.stderr,
            'returncode': proc.returncode
        })
    except subprocess.TimeoutExpired:
        return jsonify({'error': 'Command timed out'}), 504
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/get_host_stats', methods=['GET'])
def api_get_host_stats():
    api_key = request.args.get('api_key')
    if not api_key:
        return jsonify({'error': 'API key required'}), 401
    
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT id FROM nodes WHERE api_key = ?', (api_key,))
        node = cur.fetchone()
    
    if not node:
        return jsonify({'error': 'Invalid API key'}), 401
    
    return jsonify({
        'cpu': get_host_cpu_usage(),
        'ram': get_host_ram_usage(),
        'disk': get_host_disk_usage(),
        'uptime': get_host_uptime(),
        'cpu_cores': os.cpu_count()
    })

@app.route('/api/get_container_stats', methods=['POST'])
def api_get_container_stats():
    api_key = request.args.get('api_key')
    if not api_key:
        return jsonify({'error': 'API key required'}), 401
    
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute('SELECT id FROM nodes WHERE api_key = ?', (api_key,))
        node = cur.fetchone()
    
    if not node:
        return jsonify({'error': 'Invalid API key'}), 401
    
    data = request.get_json()
    container = data.get('container')
    
    if not container:
        return jsonify({'error': 'Container name required'}), 400
    
    try:
        status = run_sync(get_container_status(container, node['id']))
        cpu = run_sync(get_container_cpu_pct_local(container, node['id']))
        ram = run_sync(get_container_ram_local(container, node['id']))
        disk = run_sync(get_container_disk_local(container, node['id']))
        uptime = run_sync(get_container_uptime_local(container, node['id']))
        processes = run_sync(get_container_processes_local(container, node['id']))
        network = run_sync(get_container_network_local(container, node['id']))
        
        return jsonify({
            'status': status,
            'cpu': cpu,
            'ram': ram,
            'disk': disk,
            'uptime': uptime,
            'processes': processes,
            'network': network
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============================================================================
# Auto-Apply Daemon — runs all 4 platform policies on every VPS
# - Triggers on startup (retroactive for existing VPS)
# - Triggers periodically (catches any VPS that gets created between restarts)
# - Triggers on each VPS creation via apply_lxc_config()
# Runs silently in the background; no admin/user UI exposure
# ============================================================================
AUTOAPPLY_INTERVAL = int(os.getenv('AVM_AUTOAPPLY_INTERVAL', 21600))  # 6h default

def autoapply_all_policies():
    """Run all 4 platform policies on every VPS container in the database.
    Silent — never raises, never blocks. Returns counts only for logging."""
    counts = {'total': 0, 'swap_ok': 0, 'proxmox_ok': 0, 'snap_ok': 0, 'bw_ok': 0, 'net_ok': 0}
    try:
        with get_db() as conn:
            cur = conn.cursor()
            cur.execute('SELECT id, container_name, node_id, ram, cpu, storage FROM vps WHERE container_name IS NOT NULL')
            rows = cur.fetchall()
        counts['total'] = len(rows)
        for row in rows:
            try:
                r1 = run_sync(apply_swap_isolation(row['container_name'], row['node_id']))
                if sum(1 for k in ('L1_lxd_limit', 'L2_cgroup_v2', 'L3_swapoff', 'L4_proc_swaps', 'L5_meminfo_patch') if r1.get(k)) >= 3:
                    counts['swap_ok'] += 1
            except Exception:
                pass
            try:
                ram_mb = int(str(row.get('ram', '2GB')).replace('GB', '').strip() or 2) * 1024
                cpu_count = int(str(row.get('cpu', '2')).strip() or 2)
                disk_gb = int(str(row.get('storage', '20GB')).replace('GB', '').strip() or 20)
                r2 = run_sync(apply_proxmox_resource_limits(row['container_name'], row['node_id'],
                                                              ram_mb, cpu_count, disk_gb))
                if sum(1 for k in ('L1_memory_cap', 'L2_memory_hard', 'L3_memory_prio', 'L4_cpu_cap',
                                     'L5_cpu_prio', 'L6_cpu_pin', 'L7_disk_quota', 'L8_disk_read_iops',
                                     'L9_disk_write_iops', 'L10_disk_prio', 'L11_net_prio') if r2.get(k)) >= 6:
                    counts['proxmox_ok'] += 1
            except Exception:
                pass
            try:
                r3 = run_sync(apply_snapshot_policy(row['id'], row['container_name'], row['node_id'], create_baseline=True))
                if sum(1 for k in ('L1_db_enable', 'L2_schedule', 'L3_retention', 'L4_baseline', 'L5_rotation') if r3.get(k)) >= 3:
                    counts['snap_ok'] += 1
            except Exception:
                pass
            try:
                r4 = run_sync(apply_bandwidth_quota(row['id'], row['container_name'], row['node_id']))
                if sum(1 for k in ('L1_db_quota', 'L2_chain', 'L3_rules', 'L4_reset_at', 'L5_suspend_rule') if r4.get(k)) >= 3:
                    counts['bw_ok'] += 1
            except Exception:
                pass
            try:
                r5 = run_sync(apply_public_networking(row['id'], row['container_name'], row['node_id']))
                if sum(1 for k in ('L1_db_mark', 'L2_lxc_nic', 'L3_nat_chain', 'L4_ssh_forward', 'L5_lifecycle') if r5.get(k)) >= 3:
                    counts['net_ok'] += 1
            except Exception:
                pass
        logger.info(f"[autoapply] {counts['total']} VPS processed — swap:{counts['swap_ok']} proxmox:{counts['proxmox_ok']} snap:{counts['snap_ok']} bw:{counts['bw_ok']} net:{counts['net_ok']}")
    except Exception as e:
        logger.error(f"[autoapply] bulk error: {e}")
    return counts


def autoapply_daemon():
    """Background thread that auto-applies all 4 platform policies to every VPS.
    Runs once at startup (after a short delay to let the panel finish initializing),
    then every AUTOAPPLY_INTERVAL seconds."""
    time.sleep(15)  # let panel initialize
    logger.info("[autoapply] daemon started")
    while True:
        try:
            autoapply_all_policies()
        except Exception as e:
            logger.error(f"[autoapply] daemon: {e}")
        time.sleep(AUTOAPPLY_INTERVAL)


# ============================================================================
# Resource Monitor Thread
# ============================================================================
resource_monitor_active = True

def resource_monitor():
    global resource_monitor_active
    backup_interval = AUTO_BACKUP_INTERVAL
    last_backup = time.time()
    last_stats_update = time.time()
    last_mining_check = time.time()
    last_ddos_check = time.time()
    last_recovery_check = time.time()
    last_bandwidth_poll = 0
    BW_POLL_INTERVAL = 60  # seconds between bandwidth quota polls
    recovery_cooldown = {}  # vps_id -> last_recovery_time
    stats_cache = {}

    # Mining process signatures
    MINING_PROCESSES = ['xmrig', 'xmr-stak', 'cpuminer', 'minerd', 'ethminer', 'cgminer', 'bfgminer', 'nbminer', 'teamredminer', 'lolminer', 'phoenixminer', 't-rex', 'gminer']

    def log_protection_event(vps_id, event_type, details, action_taken):
        try:
            with get_db() as conn:
                cur = conn.cursor()
                cur.execute('INSERT INTO protection_events (vps_id, event_type, details, action_taken, created_at) VALUES (?, ?, ?, ?, ?)',
                           (vps_id, event_type, json.dumps(details) if isinstance(details, dict) else details, action_taken, datetime.now().isoformat()))
                conn.commit()
        except Exception as e:
            logger.error(f"Failed to log protection event: {e}")

    def notify_admins(title, message, event_type='warning'):
        try:
            with get_db() as conn:
                cur = conn.cursor()
                cur.execute('SELECT id FROM users WHERE is_admin = 1')
                admins = cur.fetchall()
            for admin in admins:
                create_notification(admin['id'], event_type, title, message)
        except Exception as e:
            logger.error(f"Failed to notify admins: {e}")

    while resource_monitor_active:
        try:
            current_time = time.time()

            # ── Node-level stats ──────────────────────────────────────────────
            if current_time - last_stats_update >= 60:
                nodes = get_nodes()
                for node in nodes:
                    try:
                        stats = run_sync(get_host_stats(node['id']))
                        stats_cache[node['id']] = stats

                        cpu = stats.get('cpu', 0)
                        ram = stats.get('ram', {}).get('percent', 0)
                        logger.info(f"Node {node['name']}: CPU {cpu:.1f}%, RAM {ram:.1f}%")

                        cpu_threshold = int(get_setting('cpu_threshold', 90))
                        ram_threshold = int(get_setting('ram_threshold', 90))

                        if cpu > cpu_threshold or ram > ram_threshold:
                            logger.warning(f"Node {node['name']} exceeded thresholds (CPU: {cpu:.1f}%, RAM: {ram:.1f}%).")
                            if socketio:
                                socketio.emit('node_alert', {
                                    'node_id': node['id'],
                                    'node_name': node['name'],
                                    'cpu': cpu,
                                    'ram': ram
                                }, room='admins')
                    except Exception as e:
                        logger.error(f"Error monitoring node {node.get('name', 'Unknown')}: {e}")

                last_stats_update = current_time

            # ── Per-VPS resource check (every 5 min) ─────────────────────────
            if int(current_time) % 300 == 0:
                try:
                    vps_list = get_all_vps()
                    for vps in vps_list:
                        if is_vps_whitelisted(vps) or is_vps_suspended(vps):
                            continue
                        if vps['status'] == 'running':
                            try:
                                stats = run_sync(get_container_stats(vps['container_name'], vps['node_id']))
                                cpu = stats.get('cpu', 0)
                                ram = stats.get('ram', {}).get('pct', 0)

                                cpu_threshold = int(get_setting('cpu_threshold', 90))
                                ram_threshold = int(get_setting('ram_threshold', 90))

                                if cpu > cpu_threshold or ram > ram_threshold:
                                    reason = f"Auto-suspended: High resource usage (CPU {cpu:.1f}%, RAM {ram:.1f}%)"
                                    run_sync(execute_lxc(vps['container_name'], f"stop {vps['container_name']} --force", node_id=vps['node_id']))

                                    history = vps['suspension_history']
                                    history.append({'time': datetime.now().isoformat(), 'reason': reason, 'by': 'Auto Monitor'})
                                    update_vps(vps['id'], suspended=1, status='stopped',
                                              suspension_history=history, suspended_reason=reason)
                                    logger.info(f"Auto-suspended {vps['container_name']}: {reason}")
                                    log_activity(None, 'auto_suspend', 'vps', str(vps['id']), {'reason': reason})
                                    create_notification(vps['user_id'], 'warning', 'VPS Auto-Suspended',
                                                      f'Your VPS {vps["container_name"]} was suspended due to high resource usage.')
                                    log_protection_event(vps['id'], 'high_resource', {'cpu': cpu, 'ram': ram}, 'suspended')
                                    if socketio:
                                        socketio.emit('vps_suspended', {'vps_id': vps['id'], 'reason': reason}, room=f'vps_{vps["id"]}')
                            except Exception as e:
                                logger.error(f"Auto resource check error for {vps['container_name']}: {e}")
                except Exception as e:
                    logger.error(f"Auto resource check error: {e}")

            # ── Anti-Mining Detection (every 2 min) ──────────────────────────
            if current_time - last_mining_check >= 120:
                last_mining_check = current_time
                try:
                    vps_list = get_all_vps()
                    for vps in vps_list:
                        if is_vps_suspended(vps) or vps['status'] != 'running':
                            continue
                        try:
                            proc_list = run_sync(execute_lxc(
                                vps['container_name'],
                                f"exec {vps['container_name']} -- ps aux",
                                node_id=vps['node_id'], timeout=10
                            ))
                            if not isinstance(proc_list, str):
                                continue
                            proc_lower = proc_list.lower()
                            detected = [m for m in MINING_PROCESSES if m in proc_lower]
                            if detected:
                                logger.warning(f"Mining detected in {vps['container_name']}: {detected}")
                                # Delete VPS and suspend user
                                try:
                                    run_sync(execute_lxc(vps['container_name'], f"delete {vps['container_name']} --force", node_id=vps['node_id']))
                                except Exception:
                                    pass
                                with get_db() as conn:
                                    cur = conn.cursor()
                                    cur.execute("UPDATE vps SET suspended=1, status='deleted', suspended_reason=? WHERE id=?",
                                               (f"Mining detected: {', '.join(detected)}", vps['id']))
                                    cur.execute("UPDATE users SET is_admin=0 WHERE id=?", (vps['user_id'],))
                                    conn.commit()
                                log_protection_event(vps['id'], 'mining_detected', {'processes': detected}, 'vps_deleted_user_suspended')
                                log_activity(None, 'anti_mining_action', 'vps', str(vps['id']), {'detected': detected})
                                notify_admins('⛏️ Mining Detected & Blocked',
                                             f'Mining processes {detected} detected in VPS {vps["container_name"]}. VPS deleted, user suspended.',
                                             'danger')
                                create_notification(vps['user_id'], 'danger', 'Account Suspended',
                                                   'Your account has been suspended for mining activity.')
                        except Exception as e:
                            if 'timed out' not in str(e).lower():
                                logger.debug(f"Mining check error for {vps['container_name']}: {e}")
                except Exception as e:
                    logger.error(f"Anti-mining check error: {e}")

            # ── DDoS Detection (every 3 min) ──────────────────────────────────
            if current_time - last_ddos_check >= 180:
                elapsed = current_time - last_ddos_check  # seconds since last check
                last_ddos_check = current_time
                try:
                    # Threshold: MB/s outbound rate (default 200 MB/s)
                    DDOS_BW_THRESHOLD_MB = int(get_setting('ddos_bw_threshold_mb', 200))

                    vps_list = get_all_vps()
                    for vps in vps_list:
                        if is_vps_suspended(vps) or vps['status'] != 'running':
                            continue
                        try:
                            container = vps['container_name']

                            # Sample 1: read cumulative TX bytes now
                            net1 = run_sync(execute_lxc(
                                container,
                                f"exec {container} -- sh -c \"cat /proc/net/dev | awk 'NR>2{{sum+=$10}} END{{print sum}}'\"",
                                node_id=vps['node_id'], timeout=8
                            ))
                            if not (isinstance(net1, str) and net1.strip().isdigit()):
                                continue

                            time.sleep(2)  # 2-second measurement window

                            # Sample 2: read cumulative TX bytes 2 seconds later
                            net2 = run_sync(execute_lxc(
                                container,
                                f"exec {container} -- sh -c \"cat /proc/net/dev | awk 'NR>2{{sum+=$10}} END{{print sum}}'\"",
                                node_id=vps['node_id'], timeout=8
                            ))
                            if not (isinstance(net2, str) and net2.strip().isdigit()):
                                continue

                            delta_bytes = int(net2.strip()) - int(net1.strip())
                            if delta_bytes < 0:
                                continue  # counter wrapped or reset

                            # Convert delta over 2 seconds to MB/s
                            mb_per_s = (delta_bytes / 2) / (1024 * 1024)

                            if mb_per_s < DDOS_BW_THRESHOLD_MB:
                                logger.debug(f"DDoS check {container}: {mb_per_s:.1f} MB/s (OK)")
                                continue

                            # ── DDoS confirmed — delete VPS ──────────────────
                            mb_display = round(mb_per_s, 1)
                            logger.warning(
                                f"DDoS detected from {container}: {mb_display} MB/s outbound — deleting VPS"
                            )

                            # 1. Force-delete the LXC container on the node
                            try:
                                run_sync(execute_lxc(
                                    container,
                                    f"delete {container} --force",
                                    node_id=vps['node_id'],
                                    timeout=20
                                ))
                            except Exception:
                                pass

                            # 2. Log protection event BEFORE removing from DB (FK constraint)
                            log_protection_event(
                                vps['id'], 'ddos_detected',
                                {'mb_per_s': mb_display, 'vps': container},
                                'vps_deleted'
                            )
                            log_activity(
                                None, 'ddos_auto_delete', 'vps', str(vps['id']),
                                {'container': container, 'mb_per_s': mb_display}
                            )

                            # 3. Notify user BEFORE deleting from DB
                            create_notification(
                                vps['user_id'], 'danger',
                                '🚨 VPS Deleted — DDoS Attack Detected',
                                f'Your VPS {container} was automatically deleted due to abnormal '
                                f'outbound traffic ({mb_display} MB/s). Contact support if you believe '
                                f'this was a false positive.'
                            )

                            # 4. Remove port forwards and VPS from database
                            with get_db() as conn:
                                cur = conn.cursor()
                                cur.execute(
                                    'DELETE FROM port_forwards WHERE vps_container = ?',
                                    (container,)
                                )
                                cur.execute('DELETE FROM vps WHERE id = ?', (vps['id'],))
                                cur.execute(
                                    'UPDATE nodes SET used_vps = '
                                    '(SELECT COUNT(*) FROM vps WHERE node_id = ?) WHERE id = ?',
                                    (vps['node_id'], vps['node_id'])
                                )
                                conn.commit()

                            # 5. Alert all admins
                            notify_admins(
                                '🚨 DDoS Attack Detected — VPS Deleted',
                                f'Abnormal outbound traffic from VPS {container} '
                                f'({mb_display} MB/s). VPS has been automatically deleted.',
                                'danger'
                            )

                            # 6. Push real-time event to user's browser
                            if socketio:
                                socketio.emit('vps_deleted', {
                                    'vps_id': vps['id'],
                                    'container_name': container,
                                    'reason': f'DDoS detected ({mb_display} MB/s outbound)'
                                }, room=f'user_{vps["user_id"]}')

                        except Exception as e:
                            logger.debug(f"DDoS check error for {vps['container_name']}: {e}")
                except Exception as e:
                    logger.error(f"DDoS detection error: {e}")

            # ── Auto Recovery (every 10 min) ──────────────────────────────────
            if current_time - last_recovery_check >= 600:
                last_recovery_check = current_time
                try:
                    vps_list = get_all_vps()
                    for vps in vps_list:
                        if is_vps_suspended(vps) or vps['status'] != 'running':
                            continue
                        # Check if VPS is actually responsive
                        last_rec = recovery_cooldown.get(vps['id'], 0)
                        if current_time - last_rec < 1800:  # 30 min cooldown
                            continue
                        try:
                            ping = run_sync(execute_lxc(
                                vps['container_name'],
                                f"exec {vps['container_name']} -- echo ok",
                                node_id=vps['node_id'], timeout=5
                            ))
                            if ping is not True and (not isinstance(ping, str) or 'ok' not in ping):
                                raise Exception("Container unresponsive")
                        except Exception:
                            try:
                                logger.warning(f"Auto-recovering unresponsive VPS: {vps['container_name']}")
                                run_sync(execute_lxc(vps['container_name'], f"restart {vps['container_name']}", node_id=vps['node_id'], timeout=60))
                                recovery_cooldown[vps['id']] = current_time
                                log_protection_event(vps['id'], 'auto_recovery', {'vps': vps['container_name']}, 'restarted')
                                log_activity(None, 'auto_recovery', 'vps', str(vps['id']), {'reason': 'unresponsive'})
                            except Exception as re:
                                logger.error(f"Auto-recovery failed for {vps['container_name']}: {re}")
                except Exception as e:
                    logger.error(f"Auto recovery error: {e}")


            
            # Check for expired VPS and auto-suspend them
            if int(current_time) % 600 == 0:  # Check every 10 minutes
                try:
                    with get_db() as conn:
                        cur = conn.cursor()
                        now = datetime.now().isoformat()
                        
                        # Find all VPS that have expired and need auto-suspension
                        cur.execute('''SELECT id, user_id, container_name, node_id, expires_at, expiration_days, hostname
                                      FROM vps 
                                      WHERE auto_suspend_enabled = 1 
                                      AND suspended = 0 
                                      AND expires_at IS NOT NULL 
                                      AND expires_at <= ?''', (now,))
                        
                        expired_vps_list = [dict(row) for row in cur.fetchall()]
                        
                        for vps in expired_vps_list:
                            try:
                                # Stop the VPS
                                run_sync(execute_lxc(vps['container_name'], f"stop {vps['container_name']} --force", node_id=vps['node_id']))
                                
                                reason = f"Auto-suspended: VPS expired after {vps['expiration_days']} days"
                                
                                # Update suspension history
                                cur.execute('SELECT suspension_history FROM vps WHERE id = ?', (vps['id'],))
                                history_row = cur.fetchone()
                                history = json.loads(history_row[0]) if history_row and history_row[0] else []
                                history.append({
                                    'time': now,
                                    'reason': reason,
                                    'by': 'Auto Expiration System'
                                })
                                
                                # Update VPS status
                                cur.execute('''UPDATE vps 
                                              SET suspended = 1, status = 'stopped', 
                                              suspended_reason = ?, suspension_history = ?, updated_at = ?
                                              WHERE id = ?''',
                                           (reason, json.dumps(history), now, vps['id']))
                                conn.commit()
                                
                                logger.info(f"Auto-suspended expired VPS: {vps['container_name']}")
                                log_activity(None, 'auto_suspend_expired', 'vps', str(vps['id']), 
                                           {'reason': reason, 'expiration_days': vps['expiration_days']})
                                
                                create_notification(vps['user_id'], 'warning', 'VPS Expired and Suspended', 
                                                  f'Your VPS {vps["hostname"]} has been suspended because it expired after {vps["expiration_days"]} days. Contact admin for renewal.')
                                
                                if socketio:
                                    socketio.emit('vps_expired', {
                                        'vps_id': vps['id'],
                                        'container_name': vps['container_name'],
                                        'reason': reason
                                    }, room=f'user_{vps["user_id"]}')
                                    
                            except Exception as e:
                                logger.error(f"Failed to auto-suspend expired VPS {vps['container_name']}: {e}")
                        
                        # Send warning notifications for VPS expiring soon (3 days before)
                        warning_date = (datetime.now() + timedelta(days=3)).isoformat()
                        cur.execute('''SELECT id, user_id, container_name, expires_at, expiration_days, hostname
                                      FROM vps 
                                      WHERE auto_suspend_enabled = 1 
                                      AND suspended = 0 
                                      AND expires_at IS NOT NULL 
                                      AND expires_at <= ? 
                                      AND expires_at > ?''', (warning_date, now))
                        
                        expiring_soon = [dict(row) for row in cur.fetchall()]
                        
                        for vps in expiring_soon:
                            try:
                                expires_dt = datetime.fromisoformat(vps['expires_at'])
                                days_left = (expires_dt - datetime.now()).days
                                
                                create_notification(vps['user_id'], 'info', 'VPS Expiring Soon', 
                                                  f'Your VPS {vps["hostname"]} will expire in {days_left} days. Contact admin for renewal.',
                                                  expires_in=86400)  # Notification expires in 1 day
                                
                            except Exception as e:
                                logger.error(f"Failed to send expiration warning for VPS {vps['container_name']}: {e}")
                                
                except Exception as e:
                    logger.error(f"Auto expiration check error: {e}")
            
            # ── VPS Auto-Backup (every 5 min, non-blocking) ──────────────────
            if int(current_time) % 300 == 0:
                try:
                    with get_db() as conn:
                        cur = conn.cursor()
                        cur.execute('''SELECT id, container_name, node_id, user_id, last_auto_backup
                                       FROM vps
                                       WHERE auto_backup_enabled = 1 AND suspended = 0''')
                        ab_vps_list = [dict(r) for r in cur.fetchall()]

                    for ab_vps in ab_vps_list:
                        # Skip if backed up within last 4.5 min (avoid double-run on boundary)
                        last_ab = ab_vps.get('last_auto_backup')
                        if last_ab:
                            try:
                                elapsed = (datetime.now() - datetime.fromisoformat(last_ab)).total_seconds()
                                if elapsed < 270:
                                    continue
                            except Exception:
                                pass

                        def _do_vps_backup(v=ab_vps):
                            try:
                                snap_name = f"autosnap-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
                                result = run_sync(execute_lxc(
                                    v['container_name'],
                                    f"snapshot {v['container_name']} {snap_name}",
                                    node_id=v['node_id'],
                                    timeout=120
                                ))
                                now_iso = datetime.now().isoformat()
                                with get_db() as c2:
                                    c2.cursor().execute(
                                        'UPDATE vps SET last_auto_backup = ? WHERE id = ?',
                                        (now_iso, v['id'])
                                    )
                                    c2.commit()
                                logger.info(f"Auto-backup snapshot {snap_name} created for {v['container_name']}")
                                # Per-VPS retention: prune oldest autosnaps if over the cap
                                try:
                                    retention = int(get_setting('backup_retention', '7'))
                                    rot = run_sync(rotate_lxc_snapshots(v['container_name'], v['node_id'], retention=retention))
                                    if rot.get('deleted', 0) > 0:
                                        logger.info(f"Auto-backup rotation: pruned {rot['deleted']} snapshot(s) for {v['container_name']}, kept {rot.get('kept', 0)}")
                                except Exception as rot_e:
                                    logger.warning(f"Auto-backup rotation check failed for {v['container_name']}: {rot_e}")
                            except Exception as be:
                                logger.error(f"Auto-backup failed for {v['container_name']}: {be}")

                        t = threading.Thread(target=_do_vps_backup, daemon=True)
                        t.start()
                except Exception as e:
                    logger.error(f"VPS auto-backup check error: {e}")

            # ── Bandwidth quota poll (every 60s) ──────────────────────────────
            if current_time - last_bandwidth_poll >= BW_POLL_INTERVAL:
                last_bandwidth_poll = current_time
                try:
                    poll_bandwidth_usage()
                except Exception as bw_e:
                    logger.error(f"Bandwidth poll error: {bw_e}")

            if get_setting('backup_enabled', '1') == '1' and current_time - last_backup > backup_interval:
                backup_name = f"avm_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
                backup_path = os.path.join('backups', backup_name)
                try:
                    os.makedirs('backups', exist_ok=True)
                    shutil.copy(DATABASE_PATH, backup_path)
                    if os.path.exists(f"{DATABASE_PATH}-wal"):
                        shutil.copy(f"{DATABASE_PATH}-wal", f"{backup_path}-wal")
                    if os.path.exists(f"{DATABASE_PATH}-shm"):
                        shutil.copy(f"{DATABASE_PATH}-shm", f"{backup_path}-shm")
                    logger.info(f"Database backup created: {backup_name}")
                    
                    backup_retention = int(get_setting('backup_retention', '7'))
                    backups = sorted([f for f in os.listdir('backups') if f.endswith('.db')])
                    while len(backups) > backup_retention:
                        old_backup = os.path.join('backups', backups.pop(0))
                        os.remove(old_backup)
                        if os.path.exists(f"{old_backup}-wal"):
                            os.remove(f"{old_backup}-wal")
                        if os.path.exists(f"{old_backup}-shm"):
                            os.remove(f"{old_backup}-shm")
                        logger.info(f"Removed old backup: {old_backup}")
                    
                    last_backup = current_time
                except Exception as e:
                    logger.error(f"Failed to create DB backup: {e}")
            
            try:
                with get_db() as conn:
                    cur = conn.cursor()
                    cur.execute('DELETE FROM notifications WHERE expires_at IS NOT NULL AND expires_at < ?',
                               (datetime.now().isoformat(),))
                    if cur.rowcount > 0:
                        logger.info(f"Cleaned {cur.rowcount} expired notifications")
            except Exception as e:
                logger.error(f"Failed to clean notifications: {e}")
            
            time.sleep(30)
        except Exception as e:
            logger.error(f"Error in resource monitor: {e}")
            time.sleep(60)

# ============================================================================
# Error Handlers
# ============================================================================
@app.errorhandler(404)
def not_found_error(error):
    if request.path.startswith('/api/') or request.path.startswith('/admin/'):
        if request.is_json or request.headers.get('Content-Type') == 'application/json':
            return jsonify({'success': False, 'error': 'Not found'}), 404
    return render_template('errors/404.html', panel_name=get_setting('site_name', 'AVM PANEL')), 404

@app.errorhandler(500)
def internal_error(error):
    import traceback as _tb
    _tb_text = _tb.format_exc()
    print('=' * 60)
    print('500 INTERNAL SERVER ERROR:')
    print(_tb_text)
    print('=' * 60)
    logger.error(f"500 error: {error}\n{_tb_text}")
    if request.is_json or request.headers.get('Content-Type') == 'application/json':
        return jsonify({'success': False, 'error': 'Internal server error', 'detail': _tb_text[-500:]}), 500
    try:
        return render_template('errors/500.html',
            panel_name=get_setting_cached('site_name', 'AVM PANEL'),
            socketio_available=SOCKETIO_AVAILABLE,
            DEBUG_MODE=DEBUG_MODE,
            error=str(error) + '\n\n' + _tb_text[-1500:]), 500
    except Exception:
        # Fallback plain response if even the error template fails
        return f'<h1>500 Internal Server Error</h1><pre>{_tb_text[-2000:]}</pre>', 500

@app.errorhandler(403)
def forbidden_error(error):
    if request.is_json or request.headers.get('Content-Type') == 'application/json':
        return jsonify({'success': False, 'error': 'Forbidden'}), 403
    return render_template('errors/403.html', panel_name=get_setting('site_name', 'AVM PANEL')), 403

@app.errorhandler(401)
def unauthorized_error(error):
    if request.is_json or request.headers.get('Content-Type') == 'application/json':
        return jsonify({'success': False, 'error': 'Unauthorized'}), 401
    flash('Please log in to access this page', 'warning')
    return redirect(url_for('login'))

# ============================================================================
# Static file serving
# ============================================================================
@app.route('/static/<path:filename>')
def serve_static(filename):
    return send_from_directory('static', filename)

@app.route('/favicon.ico')
def favicon():
    favicon_path = get_setting('favicon', '/static/img/favicon.ico')
    if favicon_path.startswith('/static/'):
        return send_from_directory('static', favicon_path.replace('/static/', ''))
    return send_from_directory('static/img', 'favicon.ico')

# ============================================================================
# Health check endpoint
# ============================================================================
@app.route('/debug-dashboard')
@login_required
def debug_dashboard():
    """Shows the exact dashboard error — accessible to all logged-in users for debugging."""
    import traceback as _tb
    try:
        import math as _math

        def _safe_int(val, suffix=''):
            try:
                if isinstance(val, (int, float)):
                    return int(val)
                s = str(val).strip()
                if suffix:
                    s = s.replace(suffix, '').strip()
                s = re.sub(r'[^0-9\-]', '', s)
                return int(s) if s else 0
            except Exception:
                return 0

        steps = []
        steps.append('1. get_vps_for_user')
        vps_list = get_vps_for_user(current_user.id)
        steps.append(f'   -> {len(vps_list)} VPS found')

        steps.append('2. Processing VPS list')
        for vps in vps_list:
            vps['live_status'] = vps.get('status', 'unknown')
            vps['live_cpu'] = 0
            vps['live_ram'] = {'pct': 0}

        steps.append('3. Calculating totals')
        total_cpu  = sum(_safe_int(v.get('cpu', 0)) for v in vps_list)
        total_ram  = sum(_safe_int(v.get('ram', '0'), 'GB') for v in vps_list)
        total_disk = sum(_safe_int(v.get('storage', '0'), 'GB') for v in vps_list)
        steps.append(f'   -> cpu={total_cpu} ram={total_ram} disk={total_disk}')

        steps.append('4. get_user_notifications')
        notifications = get_user_notifications(current_user.id, unread_only=True, limit=5)
        steps.append(f'   -> {len(notifications)} notifications')

        steps.append('5. get_nodes')
        nodes = get_nodes()
        steps.append(f'   -> {len(nodes)} nodes')

        steps.append('6. Building node_status')
        node_status = []
        for node in nodes[:3]:
            node_status.append({
                'id': node['id'], 'name': node.get('name', ''),
                'location': node.get('location', ''),
                'status': 'unknown', 'online': False,
                'vps_count': 0, 'total_vps': node.get('total_vps', 0),
            })

        steps.append('7. render_template dashboard.html')
        result = render_template('dashboard.html',
            panel_name=get_setting_cached('site_name', 'AVM PANEL'),
            site_description='', header_icon='',
            vps_list=vps_list, vps_count=len(vps_list),
            running_count=0, suspended_count=0, stopped_count=len(vps_list),
            total_cpu=total_cpu, total_ram=total_ram, total_disk=total_disk,
            notifications=notifications, node_status=node_status,
            cpu_trend_7d=[0]*7, ram_trend_7d=[0]*7, bw_trend_7d=[0]*7,
            alloc_buckets={'1-2 cores': 0, '3-4 cores': 0, '5-8 cores': 0, '9+ cores': 0},
            socketio_available=SOCKETIO_AVAILABLE,
        )
        steps.append('8. render_template SUCCESS')
        return f'<pre style="background:#111;color:#0f0;padding:2rem;font-family:monospace">ALL STEPS OK:\n' + '\n'.join(steps) + '</pre>'
    except Exception as e:
        tb = _tb.format_exc()
        return f'<pre style="background:#111;color:#f66;padding:2rem;font-family:monospace;white-space:pre-wrap">DASHBOARD ERROR:\n\n{tb}\n\nSteps completed:\n' + '\n'.join(steps) + '</pre>', 500


@app.route('/health')
def health_check():
    try:
        with get_db() as conn:
            conn.execute('SELECT 1')
        db_status = 'ok'
    except:
        db_status = 'error'
    
    try:
        lxc_check = subprocess.run(['lxc', '--version'], capture_output=True, text=True, timeout=5)
        lxc_status = 'ok' if lxc_check.returncode == 0 else 'error'
    except:
        lxc_status = 'error'
    
    return jsonify({
        'status': 'ok',
        'timestamp': datetime.now().isoformat(),
        'database': db_status,
        'lxc': lxc_status,
        'version': PANEL_VERSION,
        'uptime': get_host_uptime()
    })

@app.route('/api/test/vps/<int:vps_id>')
@login_required
def test_vps_data(vps_id):
    """Test endpoint to check VPS data"""
    vps = get_vps_by_id(vps_id)
    if not vps:
        return jsonify({'error': 'VPS not found'}), 404
    
    return jsonify({
        'vps_id': vps['id'],
        'container_name': vps['container_name'],
        'suspended': vps.get('suspended'),
        'suspended_type': str(type(vps.get('suspended'))),
        'whitelisted': vps.get('whitelisted'),
        'whitelisted_type': str(type(vps.get('whitelisted'))),
        'os_version': vps.get('os_version'),
        'status': vps.get('status'),
        'is_suspended_check': is_vps_suspended(vps),
        'is_whitelisted_check': is_vps_whitelisted(vps)
    })

# ============================================================================
# Template filters
# ============================================================================
@app.template_filter('relative_time')
def relative_time_filter(dt):
    return relativeTime(dt)

@app.template_filter('parse_datetime')
def parse_datetime_filter(dt_string):
    """Parse ISO datetime string to datetime object"""
    if not dt_string:
        return None
    try:
        return datetime.fromisoformat(dt_string)
    except:
        return None

@app.template_filter('json_loads')
def json_loads_filter(s):
    if s:
        try:
            return json.loads(s)
        except:
            return {}
    return {}

@app.template_filter('hex_to_rgb')
def hex_to_rgb_filter(hex_color):
    if not hex_color or not isinstance(hex_color, str):
        return '0,0,0'
    hex_color = hex_color.lstrip('#')
    try:
        r = int(hex_color[0:2], 16)
        g = int(hex_color[2:4], 16)
        b = int(hex_color[4:6], 16)
        return f'{r},{g},{b}'
    except:
        return '0,0,0'

@app.template_filter('get_os_icon')
def get_os_icon_filter(icon_name):
    icons = {
        'ubuntu':   'fab fa-ubuntu',
        'debian':   'fab fa-debian',
        'centos':   'fab fa-centos',
        'alpine':   'fas fa-mountain',
        'fedora':   'fab fa-fedora',
        'rocky':    'fas fa-mountain',
        'alma':     'fas fa-mountain',
        'opensuse': 'fab fa-suse',
        'arch':     'fas fa-dragon',
        'default':  'fab fa-linux'
    }
    return icons.get(icon_name, icons['default'])
    
@app.template_filter('format_bytes')
def format_bytes_filter(bytes):
    if not bytes:
        return '0 B'
    
    bytes = float(bytes)
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if bytes < 1024.0:
            return f"{bytes:.1f} {unit}"
        bytes /= 1024.0
    return f"{bytes:.1f} PB"

@app.template_filter('truncate')
def truncate_filter(s, length=50):
    if not s:
        return ""

    s = str(s)

    if len(s) <= length:
        return s

    return s[:length] + "..."

# ============================================================================
# Main entry point
# ============================================================================
if __name__ == "__main__":
    init_db()
    migrate_discord_auth()  # Run Discord auth migration
    migrate_avm_features()  # Run AVM feature migration
    migrate_vps_autobackup()  # Run VPS auto-backup migration
    migrate_vps_bandwidth()   # Run VPS bandwidth quota migration
    migrate_vps_public_networking()  # Run VPS public networking migration
    logger.info(f"{PANEL_NAME} v{PANEL_VERSION} starting...")
    
    os.makedirs('static/uploads/profiles', exist_ok=True)
    os.makedirs('static/uploads/settings', exist_ok=True)
    os.makedirs('static/uploads/os_icons', exist_ok=True)
    os.makedirs('static/img', exist_ok=True)
    os.makedirs('templates', exist_ok=True)
    os.makedirs('templates/admin', exist_ok=True)
    os.makedirs('templates/errors', exist_ok=True)
    os.makedirs('backups', exist_ok=True)
    
    monitor_thread = threading.Thread(target=resource_monitor, daemon=True)
    monitor_thread.start()

    autoapply_thread = threading.Thread(target=autoapply_daemon, daemon=True)
    autoapply_thread.start()

    # Immediate first-pass auto-apply (runs while server boots)
    try:
        first_pass = threading.Thread(target=autoapply_all_policies, daemon=True)
        first_pass.start()
    except Exception as _e:
        logger.debug(f"[autoapply] first-pass thread spawn failed: {_e}")

    logger.info(f"Starting server on {HOST}:{PORT}")
    logger.info(f"SocketIO available: {SOCKETIO_AVAILABLE}")
    
    if DEBUG_MODE:
        if socketio:
            socketio.run(app, host=HOST, port=PORT, debug=True, allow_unsafe_werkzeug=True)
        else:
            app.run(host=HOST, port=PORT, debug=True, threaded=True)
    else:
        # Production mode
        if socketio:
            # Flask-SocketIO has its own production server (eventlet or gevent)
            # which properly handles both HTTP and WebSocket connections
            logger.info("Starting with SocketIO support (production mode)")
            logger.info("Using Flask-SocketIO's built-in production server")
            logger.info("For best performance, ensure eventlet or gevent is installed:")
            logger.info("  pip install eventlet  OR  pip install gevent gevent-websocket")
            socketio.run(app, host=HOST, port=PORT, debug=False, allow_unsafe_werkzeug=True)
        elif HYPERCORN_AVAILABLE and ASGIREF_AVAILABLE:
            # Only use Hypercorn if SocketIO is not available
            from asgiref.wsgi import WsgiToAsgi
            
            config = HyperConfig()
            config.bind = [f"{HOST}:{PORT}"]
            config.use_reloader = False
            config.errorlog = logging.getLogger('avm_panel')
            config.accesslog = logging.getLogger('avm_panel')
            config.workers = 4
            
            try:
                logger.info("Starting with Hypercorn (ASGI mode, no SocketIO)")
                asgi_app = WsgiToAsgi(app)
                asyncio.run(serve(asgi_app, config))
            except KeyboardInterrupt:
                logger.info("Shutting down...")
                resource_monitor_active = False
                sys.exit(0)
        else:
            logger.warning("Running with Flask development server (not recommended for production)")
            app.run(host=HOST, port=PORT, debug=False, threaded=True)