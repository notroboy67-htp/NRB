#!/usr/bin/env python3
"""NRB VPS Hosting node agent. LXC-backed when LXC is installed."""
import os, sys, json, uuid, subprocess, secrets
from pathlib import Path
from flask import Flask, request, jsonify
from dotenv import load_dotenv

load_dotenv('/etc/nrb-node/.env')
load_dotenv('.env')
HOST=os.getenv('NODE_HOST','0.0.0.0'); PORT=int(os.getenv('NODE_PORT','7000')); API_KEY=os.getenv('NODE_API_KEY','CHANGE-ME')
app=Flask(__name__)

def auth(): return secrets.compare_digest(request.headers.get('Authorization',''), 'Bearer '+API_KEY)
def run(cmd,check=False): return subprocess.run(cmd,text=True,capture_output=True,check=check,timeout=120)
def lxc(): return subprocess.run(['shutil','which','lxc'],capture_output=True).returncode==0

def cmd_exists(x): return subprocess.run(['bash','-lc',f'command -v {x} >/dev/null 2>&1']).returncode==0

@app.before_request
def guard():
    if request.path!='/health' and not auth(): return jsonify(success=False,error='unauthorized'),401

@app.get('/health')
def health(): return jsonify(success=True,service='nrb-node',version='1.0',lxc=cmd_exists('lxc'))

@app.get('/v1/info')
def info(): return jsonify(success=True,hostname=os.uname().nodename,lxc=cmd_exists('lxc'))

@app.post('/v1/vps')
def create():
    d=request.get_json(force=True); name=d.get('name','').strip(); image=d.get('os','ubuntu:24.04')
    if image.startswith('debian:'): image='images:debian/'+image.split(':',1)[1]
    if not name: return jsonify(success=False,error='name required'),400
    if not cmd_exists('lxc'): return jsonify(success=False,error='LXC is not installed on this node'),503
    safe='nrb-'+''.join(c if c.isalnum() or c in '-_' else '-' for c in name.lower())+'-'+uuid.uuid4().hex[:6]
    r=run(['lxc','launch',image,safe])
    if r.returncode!=0: return jsonify(success=False,error=r.stderr.strip() or 'LXC launch failed'),500
    limits=[('limits.cpu',str(max(1,int(d.get('vcpu',1))))),('limits.memory',str(max(128,int(d.get('ram_mb',1024))))+'MiB'),('limits.root',str(max(1,int(d.get('storage_gb',20))))+'GiB')]
    for key,val in limits: run(['lxc','config','set',safe,key,val])
    return jsonify(success=True,id=safe,ipv4=get_ipv4(safe),status='running')

def get_ipv4(name):
    r=run(['lxc','list',name,'-c','4','--format','csv'])
    return r.stdout.strip().split()[0] if r.returncode==0 and r.stdout.strip() else ''

@app.post('/v1/vps/<name>/<action>')
def action(name,action):
    if action not in ('start','stop','restart','delete'): return jsonify(success=False,error='invalid action'),400
    if not cmd_exists('lxc'): return jsonify(success=False,error='LXC not installed'),503
    act={'start':['start'],'stop':['stop'],'restart':['restart'],'delete':['delete']}[action]
    r=run(['lxc',*act,name])
    return jsonify(success=r.returncode==0,error=r.stderr.strip() if r.returncode else '',status='deleted' if action=='delete' else action)

@app.post('/v1/vps/<name>/exec')
def exec_cmd(name):
    command=request.get_json(force=True).get('command','')
    if not command: return jsonify(success=False,error='command required'),400
    if not cmd_exists('lxc'): return jsonify(success=False,error='LXC not installed'),503
    r=run(['lxc','exec',name,'--','bash','-lc',command])
    return jsonify(success=r.returncode==0,stdout=r.stdout,stderr=r.stderr,code=r.returncode)

def install():
    if os.geteuid()!=0: raise SystemExit('Run as root.')
    target=Path('/etc/nrb-node'); target.mkdir(parents=True,exist_ok=True)
    key=secrets.token_urlsafe(40)
    (target/'.env').write_text(f'NODE_API_KEY={key}\nNODE_HOST=0.0.0.0\nNODE_PORT=7000\n')
    script=Path(__file__).resolve(); unit=f"""[Unit]\nDescription=NRB VPS Hosting Node Agent\nAfter=network-online.target\nWants=network-online.target\n\n[Service]\nType=simple\nUser=root\nWorkingDirectory={script.parent}\nEnvironmentFile=/etc/nrb-node/.env\nExecStart={sys.executable} {script} --run\nRestart=always\nRestartSec=3\n\n[Install]\nWantedBy=multi-user.target\n"""
    Path('/etc/systemd/system/nrb-node.service').write_text(unit)
    subprocess.run(['systemctl','daemon-reload']); subprocess.run(['systemctl','enable','--now','nrb-node.service'])
    print('NRB node installed. API key:',key)

if __name__=='__main__':
    if '--install' in sys.argv: install()
    else: app.run(host=HOST,port=PORT)
