# NRB Panel V1

Rebranded build based on the supplied HVM 5.1 project.

## Start

```bash
cd /root/NRB_PANEL_V1
chmod +x install.sh start.sh
./install.sh
./start.sh
```

The application entry point is `nrb.py` and the database is `nrb.db`.

## Notes

- Internal server-management routes and database tables are retained for compatibility.
- User-facing branding is NRB Panel V1.
- User-facing "VPS" labels were changed to "Server".
- The original project database was preserved and its branding settings were updated.
