# NRB Panel V2

NRB Panel V2 is a Docker-based VPS/container management panel.

## Runtime
- Default panel port: `3000` (override with the `PORT` environment variable).
- Docker Engine is the only container runtime.
- No legacy container runtime installation is required.
- Ubuntu and Debian images are supported through Docker Hub.
- `start.sh` launches `nrb.py`.
- `install.sh` installs Docker, Compose support, socat, and Python dependencies.

## Background
The dashboard uses the bundled `static/images/videos/minecraft-snowy-campfire.mp4` as a looping full-screen background.
