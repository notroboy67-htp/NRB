# NRB VPS Hosting

A new VPS hosting panel built from the structure of the supplied project, but implemented as a clean NRB application.

## Components
- `app.py` — web panel, authentication, customer/admin separation, plans, nodes, VPS lifecycle
- `api.py` — REST API
- `node.py` — node agent for LXC provisioning/control
- `templates/` — customer/admin UI
- `static/` — CSS/JS/assets

## Quick start
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
Open `http://SERVER_IP:5000`.

Default admin is created from `.env` on first start. Change it before production.

## Node
On a VPS node with LXC installed:
```bash
python3 node.py --install
```
Then add the node from **Admin → Nodes** using the generated API key.

For production, put the panel behind HTTPS and use a firewall/security group.
