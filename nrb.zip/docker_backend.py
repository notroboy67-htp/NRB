"""Docker runtime for NRB Panel V2 (no LXD required)."""
import os, shlex, subprocess, json

DOCKER_BIN=os.getenv("DOCKER_BIN","docker")

def run_docker(args, timeout=120, check=True):
    p=subprocess.run([DOCKER_BIN,*args],capture_output=True,text=True,timeout=timeout)
    if check and p.returncode!=0:
        raise RuntimeError((p.stderr or p.stdout or "Docker command failed").strip())
    return p.stdout.strip()

def docker_available():
    try:
        r=subprocess.run([DOCKER_BIN,"version","--format","{{.Server.Version}}"],capture_output=True,text=True,timeout=10)
        return r.returncode==0, (r.stdout or r.stderr).strip()
    except Exception as e: return False,str(e)

def ensure_image(image):
    try: run_docker(["image","inspect",image],timeout=20)
    except Exception: run_docker(["pull",image],timeout=600)

def create_container(name,image,ram_mb,cpu,disk_gb):
    ensure_image(image)
    base=["run","-d","--name",name,"--hostname",name,"--restart","unless-stopped",
          "--memory",f"{int(ram_mb)}m","--cpus",str(max(.1,float(cpu)))]
    try: return run_docker(base+["--storage-opt",f"size={int(disk_gb)}G",image,"sleep","infinity"],timeout=180)
    except Exception: return run_docker(base+[image,"sleep","infinity"],timeout=180)

def status(name):
    try:
        s=run_docker(["inspect","-f","{{.State.Status}}",name],timeout=10)
        return {"running":"running","paused":"frozen","restarting":"running","exited":"stopped","created":"stopped","dead":"stopped"}.get(s,s)
    except Exception: return "stopped"

def ip_address(name):
    try: return run_docker(["inspect","-f","{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}",name],timeout=10) or "N/A"
    except Exception: return "N/A"

def control(name,action):
    run_docker([{"start":"start","stop":"stop","restart":"restart","freeze":"pause","unfreeze":"unpause"}[action],name],timeout=120)
    return True

def delete(name):
    run_docker(["rm","-f",name],timeout=120,check=False); return True

def exec_cmd(name,command,timeout=120):
    parts=shlex.split(command)
    if parts and parts[0]=="exec": parts=parts[1:]
    if parts and parts[0]==name: parts=parts[1:]
    if parts and parts[0]=="--": parts=parts[1:]
    return run_docker(["exec",name,*parts],timeout=timeout)

class Attr:
    def __init__(self,d):
        self.filename=d["name"]; self.st_mode=d["mode"]; self.st_size=d["size"]; self.st_mtime=d["mtime"]; self.st_uid=d["uid"]; self.st_gid=d["gid"]

class DockerSFTP:
    def __init__(self,name): self.name=name
    def listdir_attr(self,path):
        # Do not require Python inside the VPS image. Minimal Ubuntu/Debian
        # images commonly have find/stat but no python3.
        qpath = shlex.quote(path)
        cmd = (
            f"find {qpath} -mindepth 1 -maxdepth 1 "
            "-printf '%f\t%y\t%s\t%T@\t%u\t%g\n' 2>/dev/null"
        )
        out = run_docker(["exec", self.name, "sh", "-lc", cmd], timeout=60)
        import stat as _stat
        items=[]
        for line in out.splitlines():
            parts=line.split("\t")
            if len(parts) < 6: continue
            name, typ, size, mtime, uid, gid = parts[:6]
            try: mode = 0o040755 if typ == 'd' else (0o120777 if typ == 'l' else 0o100644)
            except Exception: mode = 0o100644
            items.append(Attr({"name":name,"mode":mode,"size":int(float(size or 0)),"mtime":float(mtime or 0),"uid":int(uid or 0),"gid":int(gid or 0)}))
        return items
    def put(self,local,remote): run_docker(["cp",local,f"{self.name}:{remote}"],timeout=600)
    def get(self,remote,local): run_docker(["cp",f"{self.name}:{remote}",local],timeout=600)
    def remove(self,path): exec_cmd(self.name,f"rm -f -- {shlex.quote(path)}")
    def rmdir(self,path): exec_cmd(self.name,f"rmdir -- {shlex.quote(path)}")
    def mkdir(self,path): exec_cmd(self.name,f"mkdir -p -- {shlex.quote(path)}")
    def rename(self,old,new): exec_cmd(self.name,f"mv -- {shlex.quote(old)} {shlex.quote(new)}")
    def close(self): pass

class DummySSH:
    def close(self): pass

def docker_sftp(name): return DockerSFTP(name)
