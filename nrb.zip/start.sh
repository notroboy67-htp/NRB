#!/bin/bash
set -e
cd "$(dirname "$0")"

# NRB Panel V2 uses Docker only. No LXD/LXC initialization is required.
if ! command -v docker >/dev/null 2>&1; then
  echo "[NRB] Docker not found. Installing Docker..."
  apt-get update
  apt-get install -y docker.io
fi
systemctl enable --now docker 2>/dev/null || service docker start 2>/dev/null || true

if [ ! -d "venv" ]; then
  python3 -m venv venv
fi
source venv/bin/activate
python3 -m pip install -r requirements.txt
chmod +x nrb-tool.sh 2>/dev/null || true

echo "[NRB] Docker runtime ready."
echo "[NRB] Starting NRB Panel V2..."
exec python3 nrb.py
