#!/bin/bash
set -e
cd "$(dirname "$0")"

apt-get update
apt-get install -y python3 python3-pip python3-venv docker.io
systemctl enable --now docker 2>/dev/null || service docker start 2>/dev/null || true

python3 -m venv venv
source venv/bin/activate
python3 -m pip install --upgrade pip
python3 -m pip install -r requirements.txt
chmod +x start.sh nrb-tool.sh

echo ""
echo "========================================"
echo " NRB PANEL V2 - DOCKER RUNTIME"
echo "========================================"
echo "LXD/LXC is NOT required."
echo "Docker is installed and enabled."
echo "Start with: ./start.sh"
echo "========================================"
