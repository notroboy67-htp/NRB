#!/usr/bin/env bash
set -Eeuo pipefail
trap 'echo "ERROR: installation failed at line $LINENO. No success message was emitted." >&2' ERR
[[ $EUID -eq 0 ]] || { echo "Run as root: sudo bash install-docker.sh" >&2; exit 1; }
command -v apt-get >/dev/null || { echo "Supported hosts: Ubuntu/Debian using apt." >&2; exit 1; }
. /etc/os-release
case "${ID:-}" in ubuntu|debian) ;; *) echo "Unsupported OS: ${PRETTY_NAME:-unknown}. Use Ubuntu/Debian." >&2; exit 1;; esac
DIR="$(cd "$(dirname "$0")" && pwd)"
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y ca-certificates curl gnupg git python3 python3-venv python3-pip openssl
# Install Docker Engine and Compose plugin from Docker's official apt repository.
install -m 0755 -d /etc/apt/keyrings
curl -fsSL "https://download.docker.com/linux/${ID}/gpg" -o /etc/apt/keyrings/docker.asc
chmod a+r /etc/apt/keyrings/docker.asc
ARCH="$(dpkg --print-architecture)"
CODENAME="${VERSION_CODENAME:-}"
[[ -n "$CODENAME" ]] || { echo "Could not determine OS codename" >&2; exit 1; }
echo "deb [arch=${ARCH} signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/${ID} ${CODENAME} stable" >/etc/apt/sources.list.d/docker.list
apt-get update
apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
systemctl enable --now docker
docker --version
docker compose version
docker info >/dev/null
cd "$DIR"
[[ -f Dockerfile && -f compose.yaml && -f requirements.txt && -f nrb.py ]] || { echo "Required NRB files missing" >&2; exit 1; }
if [[ ! -f .env ]]; then
  cp .env.example .env
  SECRET="$(openssl rand -hex 32)"
  sed -i "s/CHANGE_ME_TO_A_RANDOM_SECRET_AT_LEAST_32_CHARACTERS/${SECRET}/" .env
  chmod 600 .env
fi
mkdir -p backups
# Verify config before build/start.
docker compose config -q
docker compose build --pull
docker compose up -d
sleep 5
STATE="$(docker inspect -f '{{.State.Status}}' nrb-panel)"
[[ "$STATE" == running ]] || { docker compose logs --tail=100; echo "NRB container is not running" >&2; exit 1; }
HEALTH="$(docker inspect -f '{{if .State.Health}}{{.State.Health.Status}}{{else}}no-healthcheck{{end}}' nrb-panel)"
if [[ "$HEALTH" == unhealthy ]]; then docker compose logs --tail=100; echo "NRB healthcheck failed" >&2; exit 1; fi
echo "NRB Panel Docker deployment started. Container status: $STATE; health: $HEALTH"
echo "Open http://YOUR_SERVER_IP:${PORT:-5000} after confirming firewall rules."
echo "Logs: cd '$DIR' && docker compose logs -f"
