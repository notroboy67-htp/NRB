#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
[[ -x venv/bin/python ]] || { echo "Virtual environment missing. Run sudo bash install-no-docker.sh" >&2; exit 1; }
exec venv/bin/python nrb.py
