# NRB Panel deployment modes

Visible product name remains **NRB Panel**. Choose one panel-runtime mode:

## Docker mode (recommended for repeatable deployments)
1. On Ubuntu/Debian VPS with root access, upload/extract this folder.
2. Run `sudo bash install-docker.sh`. This installs Docker Engine + Compose from Docker's official apt repository, validates Docker, builds the image, starts the service, and checks the container state.
3. Open `http://SERVER_IP:5000` only after setting firewall rules appropriately. Use a reverse proxy with TLS for public production access.
4. Logs: `docker compose logs -f`; restart: `docker compose restart`; update: `docker compose build --pull && docker compose up -d`.

## Non-Docker mode
Run `sudo bash install-no-docker.sh`. This creates a Python virtual environment and a systemd service. Manage it with `systemctl status nrb-panel`, `journalctl -u nrb-panel -f`, and `systemctl restart nrb-panel`.

## Important architecture note
These modes containerize/run the **panel application**. The supplied legacy application still contains LXC/LXD-oriented VPS lifecycle calls. Docker Engine being installed does **not** automatically convert VPS provisioning into Docker containers. A dedicated Docker VPS backend must be integrated and tested against the application's create/start/stop/restart/delete/console/file-manager flows before claiming full Docker-based VPS hosting. Do not mount `/var/run/docker.sock` into the web panel until strict authorization and isolation are implemented; Docker socket access is effectively host-root access.

## Validation and security
- Installer uses strict shell mode and stops on errors; no false-success message on failed steps.
- Docker mode uses a non-root app user, persistent named volume, healthcheck, dropped Linux capabilities, and no-new-privileges.
- Set a strong `SECRET_KEY`; `.env` is excluded from Docker build context.
- Put public traffic behind HTTPS, restrict inbound ports, keep the host and images patched, and back up the database/volume.
- Python 3.12 is used in the Docker image. Non-Docker mode uses the host's supported Python.
