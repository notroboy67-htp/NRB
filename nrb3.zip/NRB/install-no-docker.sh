#!/usr/bin/env bash
set -Eeuo pipefail
trap 'echo "ERROR: installation failed at line $LINENO. No success message was emitted." >&2' ERR
[[ $EUID -eq 0 ]] || { echo "Run as root: sudo bash install-no-docker.sh" >&2; exit 1; }
command -v apt-get >/dev/null || { echo "Supported hosts: Ubuntu/Debian using apt." >&2; exit 1; }
. /etc/os-release
case "${ID:-}" in ubuntu|debian) ;; *) echo "Unsupported OS: ${PRETTY_NAME:-unknown}. Use Ubuntu/Debian." >&2; exit 1;; esac
DIR="$(cd "$(dirname "$0")" && pwd)"
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y python3 python3-venv python3-pip build-essential python3-dev libffi-dev libssl-dev curl
cd "$DIR"
[[ -f nrb.py && -f requirements.txt ]] || { echo "nrb.py or requirements.txt missing" >&2; exit 1; }
python3 -m venv venv
./venv/bin/python -m pip install --upgrade pip setuptools wheel
./venv/bin/pip install --requirement requirements.txt
./venv/bin/python -m compileall -q nrb.py api.py node.py
cat > /etc/systemd/system/nrb-panel.service <<EOF
[Unit]
Description=NRB Panel
After=network-online.target
Wants=network-online.target
[Service]
Type=simple
WorkingDirectory=$DIR
Environment=HOST=0.0.0.0
Environment=PORT=3000
ExecStart=$DIR/venv/bin/python $DIR/nrb.py
Restart=on-failure
RestartSec=5
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=full
ReadWritePaths=$DIR
[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable --now nrb-panel
sleep 3
systemctl is-active --quiet nrb-panel || { systemctl --no-pager --full status nrb-panel; journalctl -u nrb-panel -n 80 --no-pager; exit 1; }
echo "NRB Panel non-Docker service is active. Check: systemctl status nrb-panel"
echo "Logs: journalctl -u nrb-panel -f"
